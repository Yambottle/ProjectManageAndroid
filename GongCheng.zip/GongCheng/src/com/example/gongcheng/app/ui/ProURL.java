package com.example.gongcheng.app.ui;

public class ProURL {
	//public final static String url = "http://192.168.199.159:8888/xxgc/";
	public final static String url = "http://115.28.244.50/xxgc/";//---
	//public final static String url = "http://223.81.81.147:8888/xxgc/";
	//public final static String url = "http://169.254.102.49:8888/xxgc/";
}
