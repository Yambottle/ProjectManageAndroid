package com.example.gongcheng.app.activity;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.example.gongcheng.R;
import com.example.gongcheng.app.entity.User;
import com.example.gongcheng.app.thread.NetworkThread;
import com.example.gongcheng.app.ui.ProURL;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class UserApplicationActivity extends Activity implements OnClickListener{
	
	private Button ret;
	private RelativeLayout addinfo;
	private int top;
	private NetworkThread thread;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.user_application);
		initView();
		initEvent();

	}
	
	public void initView(){
		ret = (Button) findViewById(R.id.UA_button_ret);
		addinfo = (RelativeLayout) findViewById(R.id.UA_RLayout);
		
		
		
		List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
		nameValuePairs.add(new BasicNameValuePair("userId",User.getId() ));

		String url = ProURL.url+"project.do?method=checkaddproject";				
		Handler handler = new Handler(){
			@Override
			public void handleMessage(Message msg) {

				switch(msg.what){
					case 1:
						JSONObject json = thread.getJSONObject();
						
						try {

						String code  = json.getString("code");
						if(code.equals("00000")){
							String data = json.getString("data");
							JSONObject pro = new JSONObject(data);
							String project = pro.getString("projects");
							JSONArray arr = new JSONArray(project);
							for (int j = 0; j < arr.length(); j++) {  
								JSONArray item = new JSONArray(arr.getString(j));
								String nameid = item.getString(0);
								String name = item.getString(1);
								String proid = item.getString(2);
								String proname = item.getString(3);
								buildView(name,nameid,proname,proid);
							}
							
							
							
							} else{
								Toast.makeText(getApplicationContext(), json.getString("msg"),
									     Toast.LENGTH_SHORT).show();
							} 
					} catch (JSONException e) {
					// TODO 自动生成的 catch 块
						e.printStackTrace();
					}
						break;
					case 2:
						Toast.makeText(getApplicationContext(), "连接超时，请重试。",
							     Toast.LENGTH_SHORT).show();
						break;
					default:
						break;
				}
			}
		};
        thread= new NetworkThread(url, nameValuePairs,handler);
        thread.start();
//		buildView("王经理","1", "项目一","1");
//		buildView("王经理","1", "项目一","1");
//		buildView("王经理","1", "项目一","1");
//		buildView("王经理","1", "项目一","1");
//		buildView("王经理","1", "项目一","1");
		
		
		
	}
	public void initEvent(){
		ret.setOnClickListener(this);
		
	}

	@Override
	public void onClick(View v) {
		// TODO 自动生成的方法存根
		switch (v.getId()) {
		case R.id.UA_button_ret:
			UserApplicationActivity.this.finish();
			
			break;

		default:
			break;
		}
	}
	
	
public void buildView(String name,final String nameid, String item,final String itemid){
		
		RelativeLayout view = new RelativeLayout(this);
	//	view.setId(Integer.parseInt(id));
		//RelativeLayout.LayoutParams lp1;
		//lp1=  (LayoutParams) view.getLayoutParams();
	//	RelativeLayout.LayoutParams father = (LayoutParams) additem.getParent();
		RelativeLayout.LayoutParams lp1 = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		lp1.width = ViewGroup.LayoutParams.WRAP_CONTENT;//father.width;
		lp1.height= 200;
		
		lp1.addRule(RelativeLayout.ALIGN_PARENT_TOP);
		lp1.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
		lp1.topMargin = top;
		top+=150;
		view.setLayoutParams(lp1);
		
		TextView info = new TextView(this);
		info.setText(name+"申请加入"+item);
		info.setTextSize(15);
		info.setGravity(Gravity.CENTER);
		//itemname.setBackgroundColor(android.graphics.Color.parseColor("#ffffff"));
		//RelativeLayout.LayoutParams lp2;
		//lp2 = (LayoutParams) itemname.getLayoutParams();;
		RelativeLayout.LayoutParams lp2 = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		//lp2.height=35;
		//lp2.width=50;
	
		lp2.addRule(RelativeLayout.CENTER_VERTICAL);
		lp2.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
		lp2.leftMargin=20;
		info.setLayoutParams(lp2);
		
		
		final Button agree = new Button(this);
		agree.setText("同意");
		agree.setTextSize(12);
		agree.setBackgroundDrawable(getResources().getDrawable(R.drawable.buttonback));
		//RelativeLayout.LayoutParams lp3;
		//lp3 = (LayoutParams) jinru.getLayoutParams();;
		RelativeLayout.LayoutParams lp3 = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		lp3.width  = 250;
		lp3.height = 110;
		lp3.addRule(RelativeLayout.CENTER_VERTICAL);
		lp3.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
		lp3.rightMargin=310;
		agree.setLayoutParams(lp3);
		agree.setOnClickListener(new Button.OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				// TODO 自动生成的方法存根
				Toast.makeText(getApplicationContext(),"同意信息已发送。",
					     Toast.LENGTH_SHORT).show();
				agree.setClickable(false);
				agree.setBackgroundDrawable(getResources().getDrawable(R.drawable.buttonshape2));
				List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
				nameValuePairs.add(new BasicNameValuePair("userId",nameid ));
				nameValuePairs.add(new BasicNameValuePair("projectId",itemid));
				String url = ProURL.url+"project.do?method=allow";				
				Handler handler = new Handler(){
					@Override
					public void handleMessage(Message msg) {

						switch(msg.what){
							case 1:
								JSONObject json = thread.getJSONObject();
								
								try {

								String code  = json.getString("code");
								if(code.equals("00000")){
									String data = json.getString("data");
									}  
							} catch (JSONException e) {
							// TODO 自动生成的 catch 块
								e.printStackTrace();
							}
								break;
							case 2:
								Toast.makeText(getApplicationContext(), "连接超时，请重试。",
									     Toast.LENGTH_SHORT).show();
								break;
							default:
								break;
						}
					}
				};
		        thread= new NetworkThread(url, nameValuePairs,handler);
		        thread.start();
			}
			
		});
		
		Button disagree = new Button(this);
		disagree.setTextSize(12);
		disagree.setBackgroundDrawable(getResources().getDrawable(R.drawable.buttonback));
		//RelativeLayout.LayoutParams lp4;
		//lp4 = (LayoutParams) pbtn.getLayoutParams();;
		RelativeLayout.LayoutParams lp4 = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		lp4.width  = 250;
		lp4.height = 110;
		lp4.addRule(RelativeLayout.CENTER_VERTICAL);
		lp4.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
		lp4.rightMargin=20;
		disagree.setLayoutParams(lp4);
		
		disagree.setText("拒绝");
		disagree.setOnClickListener(new Button.OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
			
					
			}
				
		});
		
		
		
		
		
		view.addView(info,lp2);
		view.addView(agree,lp3);
		view.addView(disagree,lp4);
		
		addinfo.addView(view,lp1);
		
		
	}

}
