package com.example.gongcheng.app.activity;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

import com.example.gongcheng.R;
import com.example.gongcheng.app.entity.User;
import com.example.gongcheng.app.thread.NetworkThread;
import com.example.gongcheng.app.ui.ProURL;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ChangeActivity extends Activity implements OnClickListener{

	private EditText zhanghao;
	private EditText pass;
	private EditText new1;
	private EditText new2;
	private Button password;
	private NetworkThread thread;
	private Button ret;
	
	private String zhanghaoValue,passValue,new1Value,new2Value,newnameValue; 
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.change_information);
		initView();
		initEvent();
		
		
	}
	
	
	private void initView(){
		zhanghao = (EditText) findViewById(R.id.XG_editText_zhanghao);
		pass = (EditText) findViewById(R.id.XG_editText_pass);
		new1 = (EditText) findViewById(R.id.XG_editText_newpass);
		new2 = (EditText) findViewById(R.id.XG_editText_passag);
		password = (Button) findViewById(R.id.XG_button_pass);
		ret = (Button) findViewById(R.id.XG_button_ret);
	}
	
	private void initEvent(){
		password.setOnClickListener(this);
		ret.setOnClickListener(this);
	}
	
	@Override
	public void onClick(View v) {
		// TODO �Զ����ɵķ������
		switch (v.getId()) {
		case R.id.XG_button_pass:
			zhanghaoValue = zhanghao.getText().toString();
			passValue = pass.getText().toString();
			new1Value = new1.getText().toString();
			new2Value = new2.getText().toString();
			if(new1Value.equals(new2Value)){
				
				
				
					List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
					nameValuePairs.add(new BasicNameValuePair("userName", zhanghaoValue));
					nameValuePairs.add(new BasicNameValuePair("userCurrentPwd", passValue));
					nameValuePairs.add(new BasicNameValuePair("newPwd",new1Value ));
					String url =ProURL.url+"user.do?method=updatePwd";
		            
					Handler handler = new Handler(){
						@Override
						public void handleMessage(Message msg) {

							switch(msg.what){
								case 1:
									JSONObject json = thread.getJSONObject();
									try {
										String code  = json.getString("code");
										if(code.equals("00000")){
											Toast.makeText(getApplicationContext(), "修改成功",
												     Toast.LENGTH_SHORT).show();
											zhanghao.setText("");
											pass.setText("");
											new1.setText("");
											new2.setText("");
			
										}else{
											Toast.makeText(getApplicationContext(), json.getString("msg"),
												     Toast.LENGTH_SHORT).show();
										}
									} catch (JSONException e) {
									// TODO 自动生成的 catch 块
										e.printStackTrace();
									}
									break;
								case 2:
									Toast.makeText(getApplicationContext(), "连接超时，请重试。",
										     Toast.LENGTH_SHORT).show();
									break;

			
			
								default:
										break;
							}
						}
					};
		            thread= new NetworkThread(url, nameValuePairs,handler);
		            thread.start();
					
			}else{
				
			}
			break;
		case R.id.XG_button_ret:
			ChangeActivity.this.finish();
			break;


		default:
			break;
		}
	}
	

}
