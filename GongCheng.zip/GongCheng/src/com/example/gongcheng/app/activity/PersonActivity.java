package com.example.gongcheng.app.activity;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.example.gongcheng.R;
import com.example.gongcheng.app.entity.User;
import com.example.gongcheng.app.thread.NetworkThread;
import com.example.gongcheng.app.ui.ProURL;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class PersonActivity extends Activity {

	private Button fanhui;
	
	private NetworkThread thread;
	private int width;
	
	private LinearLayout LG;
	private Intent intent;  
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.show_person);
		initView();
		initEvent();


	}

	

	private void initView() {
		// TODO 自动生成的方法存根
		WindowManager wm =this.getWindowManager();
		width = wm.getDefaultDisplay().getWidth();
		intent =  getIntent();
		fanhui = (Button)findViewById(R.id.SP_button_fanhui);
		fanhui.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				finish();
				
			}
		});
		
		LG = (LinearLayout)findViewById(R.id.SP_RLayout);
		
		List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
		
		
		nameValuePairs.add(new BasicNameValuePair("projectId", intent.getStringExtra("PROJECTID")));
		
		
		String url = ProURL.url+"project.do?method=loaduser";
		Handler handler = new Handler(){
		@SuppressWarnings("deprecation")
		@Override
		public void handleMessage(Message msg) {

			switch(msg.what){
				case 1:
					JSONObject json = thread.getJSONObject();
					try {
						String code  = json.getString("code");
						if(code.equals("00000")){
							JSONObject data =json.getJSONObject("data");
							JSONArray users = data.getJSONArray("users");
							for(int i=0;i<users.length();i++){
								JSONArray info = users.getJSONArray(i);
								if(info.getString(1).equals("1")){
									buildPersonView(1,info.getString(0),info.getString(2));
								}
							}
							for(int i=0;i<users.length();i++){
								JSONArray info = users.getJSONArray(i);
								if(info.getString(1).equals("2")){
									buildPersonView(2,info.getString(0),info.getString(2));
								}
								
							}
							for(int i=0;i<users.length();i++){
								JSONArray info = users.getJSONArray(i);
								if(info.getString(1).equals("0")){
									buildPersonView(0,info.getString(0),info.getString(2));
								}
								
							}
							
							
							
						}else{
							Toast.makeText(getApplicationContext(), json.getString("msg"),
								     Toast.LENGTH_SHORT).show();
						}
					} catch (JSONException e) {
					// TODO 自动生成的 catch 块
						e.printStackTrace();
					}
					
					break;
				case 2:
					Toast.makeText(getApplicationContext(), "连接超时，请重试。",
						     Toast.LENGTH_SHORT).show();
					break;
				default:
					break;
			}
		}
	};
    thread= new NetworkThread(url, nameValuePairs,handler);
    thread.start();
		
		
		
		
		
	}
	
	private void initEvent() {
		// TODO 自动生成的方法存根
		
	}
	
public void buildPersonView(int power,String name ,final String id){
		
		LinearLayout view = new LinearLayout(this);
		
	
		LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		lp1.width = ViewGroup.LayoutParams.FILL_PARENT;//father.width;

		view.setLayoutParams(lp1);
		
		TextView logTime = new TextView(this);
		if(power==1)
			logTime.setText("创建者 ");
		else if(power==2)
			logTime.setText("管理员");
		else if(power==0)
			logTime.setText("申请者");
		logTime.setTextSize(20);
		logTime.setGravity(Gravity.CENTER);
		logTime.setSingleLine(false);
		LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(width/3, ViewGroup.LayoutParams.FILL_PARENT);
		logTime.setLayoutParams(lp2);
		
		TextView logInfo = new TextView(this);
		
		logInfo.setText(name);
		logInfo.setTextSize(20);
		logInfo.setSingleLine(false);
		
		LinearLayout.LayoutParams lp3 = new LinearLayout.LayoutParams(width/3, ViewGroup.LayoutParams.WRAP_CONTENT);
		logInfo.setLayoutParams(lp3);
		view.addView(logTime,lp2);
		view.addView(logInfo,lp3);
		
		if(intent.getStringExtra("POWER").equals("1")&&power==2){
		
			final Button delet = new Button(this);
			delet.setText("移出");
			delet.setTextSize(15);
			delet.setBackgroundDrawable(getResources().getDrawable(R.drawable.buttonback));
			LinearLayout.LayoutParams lp4 = new LinearLayout.LayoutParams(width/3, width/9);
		
			delet.setLayoutParams(lp4);
			delet.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View arg0) {
					// TODO 自动生成的方法存根
					 Toast.makeText(getApplicationContext(),"请求已发送。",
						     Toast.LENGTH_SHORT).show();
					List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
					nameValuePairs.add(new BasicNameValuePair("projectId", intent.getStringExtra("PROJECTID")));
					nameValuePairs.add(new BasicNameValuePair("userId", User.getId()));
					nameValuePairs.add(new BasicNameValuePair("targeUserId", id));
					
					
					String url = ProURL.url+"project.do?method=deleteutp";
					Handler handler = new Handler(){
					@SuppressWarnings("deprecation")
					@Override
					public void handleMessage(Message msg) {

						switch(msg.what){
							case 1:
								JSONObject json = thread.getJSONObject();
								try {
									String code  = json.getString("code");
									if(code.equals("00000")){
										 Toast.makeText(getApplicationContext(),"移出成功。",
											     Toast.LENGTH_SHORT).show();
										delet.setClickable(false);
										delet.setBackgroundDrawable(getResources().getDrawable(R.drawable.buttonshape2));
									}
										
								} catch (JSONException e) {
								// TODO 自动生成的 catch 块
									e.printStackTrace();
								}
								
								break;
							case 2:
								Toast.makeText(getApplicationContext(), "连接超时，请重试。",
									     Toast.LENGTH_SHORT).show();
								break;
							default:
								break;
						}
					}
				};
			    thread= new NetworkThread(url, nameValuePairs,handler);
			    thread.start();
					
					
					
				}
			});
			view.addView(delet,lp4);
		
		}
		
		
		
		
		LG.addView(view,lp1);
		
		
	}

	
}
