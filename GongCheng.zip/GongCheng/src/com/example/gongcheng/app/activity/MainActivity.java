package com.example.gongcheng.app.activity;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.util.List;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.text.TextPaint;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.Window;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONStringer;


import com.example.gongcheng.R;
import com.example.gongcheng.draw.*;
import com.example.gongcheng.app.entity.Location;
import com.example.gongcheng.app.entity.User;
import com.example.gongcheng.app.thread.NetworkThread;
import com.example.gongcheng.app.ui.ProURL;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences.Editor;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

	public static int viewH;
	public static int viewW;
	public static String json="";
	static String PROJECTID;
	 private ViewPager mViewpager;
	 private PagerAdapter mAdapter;
	 private List<View> mViews;
	 private LayoutInflater mInflater;
	 private ShowView view;
	 private Dialog SDialog,LDialog;
	 private NetworkThread thread;
	 private JSONObject Subkey;
	 private View first,second;
	 private JSONArray img ;
	 private String CREATOR;
	 private Boolean Manager;
	 private Double GRYY,CLYY,QTYY;
	 private String CLimage,JXimage;
	 private int off ,lim;
	 private int logType = 0;
	 private Button TodayButton,UserButton;
	 private Boolean f5running = true;
	 
	 private int JXTPi;
	 private int CLTPi;
	 
	 private final String JXitems[]={"铲车","吊车","胶轮压路机","平地机","双钢轮压路机","摊铺机","挖掘机","铣刨机","震动压路机","自卸车","其他1","其他2","其他3","其他4","其他5"};
	 private final String CLitems[]={"m","㎡","m³","t","kg","个","件","套","片","对","次","项"};
     
	 private Double JXNUM;
	 
	 //int
	 private int top=0;
	 private int Intleft=0;
	 private int Intright=0;
	 private int omg = 0;
	 private int JX,GR,CL,QT,ADD,rH,rW;
	 
	 private int JX3_fatherid, JX3_id, JX3_newt, JX3_newl, JX3_s;
	 
	 private int GR3_fatherid, GR3_id, GR3_newt, GR3_newl, GR3_s;
	 
	 private int contractId;
	 //String
	 private String the_Type,CLNAME,CLPRICE;
	 private int fatherid;
	 
	 private float allcost,allJX,allGR,allCL,allQT;
	 private float Tcost,TJX,TGR,TCL,TQT;
	 private float addJX,addGR;
	
	 
	 //textView
	 
	 private TextView CLTPP;
	 private TextView topInfo; 
	 private TextView topPro;
	 
	 private TextView all,today;
	 
	 private TextView info02_ID;

	 private TextView info02_Name;
	 private TextView info02_BZ;
	 private TextView infoTextView1;
	 private TextView infoTextView2;
	 private TextView infoTextView3;
	 
	 private TextView JXinfo2Name,JXinfo2Price,JXinfo2BZ,JXinfo2ID;
	 private Button JXinfo2QD,JXinfo2QX;
	 
	 private TextView GRinfo2Name,GRinfo2Price,GRinfo2Num,GRinfo2ID,GRinfoGDBZ,CLinfoGDBZ,QTinfoGDBZ;
	 private EditText GRinfoUser,GRinfoBZ;
	 private Button GRinfo2QD,GRinfo2QX;
	 
	 
	 private TextView CLinfo2Name,CLinfo2Price,CLinfo2Num,CLinfo2ID;
	 private EditText CLinfoUser,CLinfoBZ;
	 private Button CLinfo2QD,CLinfo2QX;
	 
	 private TextView QTinfo2Name,QTinfo2Price,QTinfo2BZ,QTinfo2ID,QTinfo2Used;
	 private EditText QTinfoBZ,QTinfoPrice;
	 private Button QTinfo2QD,QTinfo2QX;
	 
	 
	 private TextView JXinfo3Name,JXinfo3Price,JXinfo3BZ,JXinfo3ID;
	 private Button JXinfo3QD,JXinfo3QX;
	 
	 private TextView GRinfo3Name,GRinfo3Price,GRinfo3Num,GRinfo3ID;
	 private Button GRinfo3QD,GRinfo3QX;
	 
	 
	 private RelativeLayout info01C;
	 private EditText info01_NameC;
	 private EditText info01_BZC;
	 private Button info01QDC,info01QXC;
	 
	 
	 
	 private RelativeLayout JXinfo01C;
	 private EditText JXinfo01_PC;
	 private EditText JXinfo01_NameC;
	 private EditText JXinfo01_BZC;
	 private Button JXinfo01QDC,JXinfo01QXC;
	 
	 private RelativeLayout GRinfo01C;
	 private EditText GRinfo01_PC;
	 private EditText GRinfo01_NameC;
	 private EditText GRinfo01_BZC;
	 private Button GRinfo01QDC,GRinfo01QXC;
	 
	 private RelativeLayout CLinfo01C;
	 private EditText CLinfo01_PC;
	 private EditText CLinfo01_NameC;
	 private EditText CLinfo01_BZC;
	 private Button CLinfo01QDC,CLinfo01QXC;
	 
	 
	 private RelativeLayout QTinfo01C;
	 private EditText QTinfo01_NameC;
	 private EditText QTinfo01_BZC;
	 private Button QTinfo01QDC,QTinfo01QXC;
	 
	 
	 
	 
	 
	 //EditText
	 private EditText info01_Name;
	 private EditText info01_BZ;
	 
	 private EditText JX_name,JX_price,JX_bz;
	 private Button JX_QD;
	 
	 private EditText GR_name,GR_price,GR_bz;
	 private Button GR_QD;
	 
	 private EditText CL_name,CL_price,CL_bz;
	 private Button CL_QD;
	 
	 private EditText QT_name,QT_bz;
	 private Button QT_QD;
	 
	 
	 
	 
	 private Button JXTP,CLTP;
	 private TextView JXTPTV,CLTPTV,CLinfoTP;
	 
	 
	 
	 private Button JXSC,GRSC;
	 private Button showPerson;
	 //button
	 private Button fanhui;
	 private Button log;
	 private Button f5;
	 private Button left;
	 private Button right;
	 private Button JXadd,GRadd,CLadd,QTadd;
	 private Button info01_QD,info01_QX;
	 private Button info02_QD,info02_XG,info02_SC;
	 private Button add;
	 private Button JXinfoQX,GRinfoQX,CLinfoQX,QTinfoQX;
	 private Button ShowQD,ShowQX;
	 
	 private Button JXLC,GRLC;
	 
	 //rela
	 private LinearLayout LG;
	 
	 private LinearLayout Show1;
	 private LinearLayout Show2;
	 
	 private RelativeLayout Jiazai;
	 private RelativeLayout leftRL;
	 private RelativeLayout rightRL;
	 private RelativeLayout info01;
	 private RelativeLayout info02;
	 private RelativeLayout addv;
	 private RelativeLayout wh;
	 private LinearLayout JXRL;
	 private LinearLayout GRRL;
	 private LinearLayout CLRL;
	 private LinearLayout QTRL;
	 private RelativeLayout JXinfo;
	 private RelativeLayout GRinfo;
	 private RelativeLayout CLinfo;
	 private RelativeLayout QTinfo;
	 private LinearLayout addRL;
	 
	 private RelativeLayout JXinfo02;
	 private RelativeLayout GRinfo02;
	 private RelativeLayout CLinfo02;
	 private RelativeLayout QTinfo02;
	 
	 private RelativeLayout JXinfo03;
	 private RelativeLayout GRinfo03;
	 
	 
		Timer timer = new Timer();
		Handler handler = new Handler(){
		  public void handleMessage (Message msg)  {
		    switch (msg.what) {
		        case 1:
		        	allJX+=addJX;
		        	TJX+=addJX;
		        	allGR+=addGR;
		        	TGR+=addGR;
		        	allcost = allJX+allGR+allCL+allQT;
					Tcost = TJX+TGR+TCL+TQT;
					DecimalFormat decimalFormat=new DecimalFormat(".0");
					
					
					all.setText("总成本="+decimalFormat.format(allcost)+"=机械("+decimalFormat.format(allJX)+")+人工("+decimalFormat.format(allGR)+")+材料("+decimalFormat.format(allCL)+")+其他("+decimalFormat.format(allQT)+")");
					today.setText("当日成本="+decimalFormat.format(Tcost)+"=机械("+decimalFormat.format(TJX)+")+人工("+decimalFormat.format(TGR)+")+材料("+decimalFormat.format(TCL)+")+其他("+decimalFormat.format(TQT)+")");
					all.invalidate();
		        	today.invalidate();
		        	System.out.print(all.getText().toString());
		           break;
		    }
		    super.handleMessage(msg);
		   }
		};  
		 
		TimerTask task = new TimerTask(){
		  public void run() {
			  Message message = new Message();
		   message.what = 1;
		   handler.sendMessage(message);
		   }
		};  
		 
		
		
	
	 
	 
	 @Override
	  protected void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    requestWindowFeature(Window.FEATURE_NO_TITLE);
	    setContentView(R.layout.view_main);
	    
	    initView();
	    
	   
	    
	    initEvent();

	   

	    
	  }

	@SuppressLint("CutPasteId")
	private void initView() {
		// TODO 自动生成的方法存根
		
		


		SDialog=new Dialog(	MainActivity.this);
		SDialog.setContentView(R.layout.show_view);
		LDialog = new Dialog(MainActivity.this);
		LDialog.setContentView(R.layout.log);
		
		
		
		
		
		
		mInflater = LayoutInflater.from(this);
	    mViewpager = (ViewPager) findViewById(R.id.id_mainpager);
	    
	    
	    
	    mViews = new ArrayList<View>();
		first = mInflater.inflate(R.layout.show_view, null);
		second = mInflater.inflate(R.layout.log, null);
		mViews.add(first);
		mViews.add(second);
		
		
		all = (TextView) first.findViewById(R.id.SD_textView_all);
		today =(TextView) first.findViewById(R.id.SD_textView_today);
		
		
		
		infoTextView1 = (TextView) first.findViewById(R.id.SD_textView_info01);
		infoTextView2 = (TextView) first.findViewById(R.id.SD_textView_info02);
		infoTextView3 = (TextView) first.findViewById(R.id.SD_textView_info03);
		
		info02_ID =  (TextView) first.findViewById(R.id.SD_textview_infoID);
		
		info02_Name = (TextView) first.findViewById(R.id.SD_textview_infoNAME);
		info02_BZ = (TextView) first.findViewById(R.id.SD_textview_infoBZ);
		
		JXinfo2ID = (TextView) first.findViewById(R.id.SD_textview_JXinfoID);
		JXinfo2Name = (TextView) first.findViewById(R.id.SD_textview_JXinfoName);
		JXinfo2Price = (TextView) first.findViewById(R.id.SD_textview_JXinfoprice);
		JXinfo2BZ = (TextView) first.findViewById(R.id.SD_textview_JXinfoBZ);
		
		GRinfo2ID = (TextView) first.findViewById(R.id.SD_textview_GRinfoID);
		GRinfo2Name = (TextView) first.findViewById(R.id.SD_textview_GRinfoName);
		GRinfo2Price = (TextView) first.findViewById(R.id.SD_textview_GRinfoprice);
		GRinfo2Num = (TextView) first.findViewById(R.id.SD_textview_GRinfoNumber);
		
		CLinfo2ID = (TextView) first.findViewById(R.id.SD_textview_CLinfoID);
		CLinfo2Name = (TextView) first.findViewById(R.id.SD_textview_CLinfoName);
		CLinfo2Price = (TextView) first.findViewById(R.id.SD_textview_CLinfoprice);
		CLinfo2Num = (TextView) first.findViewById(R.id.SD_textview_CLinfoNumber);
		CLinfoTP= (TextView) first.findViewById(R.id.SD_textview_CLinfoTP);
		
		QTinfo2ID = (TextView) first.findViewById(R.id.SD_textview_QTinfoID);
		QTinfo2Name = (TextView) first.findViewById(R.id.SD_textview_QTinfoName);
		QTinfo2Price = (TextView) first.findViewById(R.id.SD_textview_QTinfoprice);
		QTinfo2BZ = (TextView) first.findViewById(R.id.SD_textview_QTinfoBZ);
		
		JXinfo3ID = (TextView) first.findViewById(R.id.SD_textview_JXinfo3ID);
		JXinfo3Name = (TextView) first.findViewById(R.id.SD_textview_JXinfo3Name);
		JXinfo3Price = (TextView) first.findViewById(R.id.SD_textview_JXinfo3price);
		JXinfo3BZ = (TextView) first.findViewById(R.id.SD_textview_JXinfo3BZ);
		

		GRinfo3ID = (TextView) first.findViewById(R.id.SD_textview_GRinfo3ID);
		GRinfo3Name = (TextView) first.findViewById(R.id.SD_textview_GRinfo3Name);
		GRinfo3Price = (TextView) first.findViewById(R.id.SD_textview_GRinfo3price);
		GRinfo3Num = (TextView) first.findViewById(R.id.SD_textview_GRinfo3Num);
		

		info01_NameC = (EditText) first.findViewById(R.id.SD_editText_NameC);
		info01_BZC = (EditText) first.findViewById(R.id.SD_editText_BZC);
		

		info01_Name = (EditText) first.findViewById(R.id.SD_editText_Name);
		info01_BZ = (EditText) first.findViewById(R.id.SD_editText_BZ);
		
		
		JXinfo01_PC = (EditText) first.findViewById(R.id.SD_editText_JXpriceC);
		JXinfo01_NameC = (EditText) first.findViewById(R.id.SD_editText_JXNameC);
		JXinfo01_BZC = (EditText) first.findViewById(R.id.SD_editText_JXBZC);
		
		GRinfo01_PC = (EditText) first.findViewById(R.id.SD_editText_GRpriceC);
		GRinfo01_NameC = (EditText) first.findViewById(R.id.SD_editText_GRnameC);
		GRinfo01_BZC = (EditText) first.findViewById(R.id.SD_editText_GRBZC);
	
		
		JX_name = (EditText) first.findViewById(R.id.SD_editText_JXName);
		JX_price = (EditText) first.findViewById(R.id.SD_editText_JXprice);
		JX_bz = (EditText) first.findViewById(R.id.SD_editText_JXBZ);
		
		
		GR_name = (EditText) first.findViewById(R.id.SD_editText_GRname);
		GR_price = (EditText) first.findViewById(R.id.SD_editText_GRprice);
		GR_bz = (EditText) first.findViewById(R.id.SD_editText_GRBZ);
		
		
		CL_name = (EditText) first.findViewById(R.id.SD_editText_CLname);
		CL_price = (EditText) first.findViewById(R.id.SD_editText_CLprice);
		CL_bz = (EditText) first.findViewById(R.id.SD_editText_CLBZ);
		
		
		QT_name = (EditText) first.findViewById(R.id.SD_editText_QTType);
		
		QT_bz = (EditText) first.findViewById(R.id.SD_editText_QTBZ);
		
		
		CLTPP = (TextView) first.findViewById(R.id.SD_textview_CLinfoTP);
		GRinfoUser = (EditText) first.findViewById(R.id.SD_editText_GRinfoU);
		GRinfoBZ = (EditText) first.findViewById(R.id.SD_editText_GRinfoB);
		CLinfoUser = (EditText) first.findViewById(R.id.SD_editText_CLinfoU);
	
		QTinfoPrice = (EditText) first.findViewById(R.id.SD_editText_QTinfoP);
		QTinfoBZ = (EditText) first.findViewById(R.id.SD_editText_QTinfoB);
		QTinfo2Used = (TextView) first.findViewById(R.id.SD_textview_QTinfoUsed);
		
		
		Show1 = (LinearLayout) first.findViewById(R.id.SD_Llayout_show1);
		Show2 = (LinearLayout) first.findViewById(R.id.SD_Llayout_show2);
		
		leftRL =(RelativeLayout) first.findViewById(R.id.SD_Rlayout_left);
		rightRL =(RelativeLayout) first.findViewById(R.id.SD_Rlayout_Right);
		info01 = (RelativeLayout) first.findViewById(R.id.SD_RLayout_info01);
		info02 = (RelativeLayout) first.findViewById(R.id.SD_RLayout_info02);
		addv = (RelativeLayout) first.findViewById(R.id.SD_RLayout_v);
		wh = (RelativeLayout)first.findViewById(R.id.SD_imageview_background);
		JXRL = (LinearLayout) first.findViewById(R.id.SD_RLayout_JX);
		GRRL = (LinearLayout) first.findViewById(R.id.SD_RLayout_GR);
		CLRL = (LinearLayout) first.findViewById(R.id.SD_RLayout_CL);
		QTRL = (LinearLayout) first.findViewById(R.id.SD_RLayout_QT);
		JXinfo = (RelativeLayout) first.findViewById(R.id.SD_RLayout_JXinfo);
		GRinfo = (RelativeLayout) first.findViewById(R.id.SD_RLayout_GRinfo);
		CLinfo = (RelativeLayout) first.findViewById(R.id.SD_RLayout_CLinfo);
		QTinfo = (RelativeLayout) first.findViewById(R.id.SD_RLayout_QTinfo);
		addRL = (LinearLayout) first.findViewById(R.id.SD_RLayout_addRL);
		
		
		JXinfo02 = (RelativeLayout) first.findViewById(R.id.SD_RLayout_JXinfo02);
		GRinfo02 = (RelativeLayout) first.findViewById(R.id.SD_RLayout_GRinfo02);
		CLinfo02 = (RelativeLayout) first.findViewById(R.id.SD_RLayout_CLinfo02);
		QTinfo02 = (RelativeLayout) first.findViewById(R.id.SD_RLayout_QTinfo02);
		
		JXinfo03 = (RelativeLayout) first.findViewById(R.id.SD_RLayout_JXinfo03);
		GRinfo03 = (RelativeLayout) first.findViewById(R.id.SD_RLayout_GRinfo03);
		Jiazai = (RelativeLayout) first.findViewById(R.id.SD_imageview_background2);
		
		info01C = (RelativeLayout) first.findViewById(R.id.SD_RLayout_info01C);
		
		JXinfo01C =(RelativeLayout) first.findViewById(R.id.SD_RLayout_JXinfoC);
		
		GRinfo01C =(RelativeLayout) first.findViewById(R.id.SD_RLayout_GRinfoC);
		
		LG = (LinearLayout) second.findViewById(R.id.LG_RLayout);
		
		view = (ShowView) first.findViewById(R.id.SD_view);
		
		topInfo = (TextView) first.findViewById(R.id.SD_textView_Topuser);
		topPro= (TextView) first.findViewById(R.id.SD_textView_TopPro);
		
		
		
		
		
		 CLinfo01C = (RelativeLayout) first.findViewById(R.id.SD_RLayout_CLinfoC);
		 CLinfo01_PC = (EditText) first.findViewById(R.id.SD_editText_CLpriceC);
		 CLinfo01_NameC= (EditText) first.findViewById(R.id.SD_editText_CLnameC);
		 CLinfo01_BZC= (EditText) first.findViewById(R.id.SD_editText_CLBZC);
		 
		 QTinfo01C = (RelativeLayout) first.findViewById(R.id.SD_RLayout_QTinfoC);
		
		 QTinfo01_NameC= (EditText) first.findViewById(R.id.SD_editText_QTnameC);
		 QTinfo01_BZC= (EditText) first.findViewById(R.id.SD_editText_QTBZC);
		 
		 CLinfoBZ= (EditText) first.findViewById(R.id.SD_editText_CLinfoUserB);
		 
		 GRinfoGDBZ = (TextView) first.findViewById(R.id.SD_textview_GRinfoGDBZ);
		 CLinfoGDBZ = (TextView) first.findViewById(R.id.SD_textview_CLinfoGDBZ);
		 QTinfoGDBZ = (TextView) first.findViewById(R.id.SD_textview_QTinfoGDBZ);
		
		
		
		
		 ViewTreeObserver vto1 = view.getViewTreeObserver();   
		    vto1.addOnGlobalLayoutListener(new OnGlobalLayoutListener() {  
		        @Override   
		        public void onGlobalLayout() {  
		            view.getViewTreeObserver().removeGlobalOnLayoutListener(this);
		            viewH = view.getHeight();
		            viewW = view.getWidth();
		        }   
		    }); 
		

		 ViewTreeObserver vto2 = rightRL.getViewTreeObserver();   
		    vto2.addOnGlobalLayoutListener(new OnGlobalLayoutListener() {  
		        @Override   
		        public void onGlobalLayout() {  
		            rightRL.getViewTreeObserver().removeGlobalOnLayoutListener(this);  
		            rH = rightRL.getHeight();
		            rW = rightRL.getWidth();
		        }   
		    });  
		    
		      int w = View.MeasureSpec.makeMeasureSpec(0,View.MeasureSpec.UNSPECIFIED); 
		      int h = View.MeasureSpec.makeMeasureSpec(0,View.MeasureSpec.UNSPECIFIED); 
		      rightRL.measure(w, h); 
		      rH =rightRL.getMeasuredHeight();
		      rW =rightRL.getMeasuredWidth();

		
		
		int x = rightRL.getWidth();
		int y = leftRL.getWidth();
		
		left = (Button)first.findViewById(R.id.SD_button_left);
		left.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				switch (Intleft) {
				case 0:
					Intleft = 1;
					left.setBackgroundResource(R.drawable.left);
					leftRL.setVisibility(View.VISIBLE);
					break;
				case 1:
					Intleft = 0;
					left.setBackgroundResource(R.drawable.right);
					leftRL.setVisibility(View.GONE);
					break;

				default:
					break;
				}
				
			}
		});
		
		right = (Button)first.findViewById(R.id.SD_button_right);
		right.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				RelativeLayout.LayoutParams lp = (LayoutParams) right.getLayoutParams();
				
			
				switch (Intright) {
				
				
				case 0:
					Intright = 1;
					right.setBackgroundResource(R.drawable.right);
					rightRL.setVisibility(View.VISIBLE);
					int r = rightRL.getWidth();
					rightRL.setVisibility(View.GONE);
					rightRL.setVisibility(View.VISIBLE);
					
					lp.rightMargin = rightRL.getWidth();
					break;
					
					
				case 1:
					Intright = 0;
					right.setBackgroundResource(R.drawable.left);
					rightRL.setVisibility(View.GONE);
					lp.rightMargin =0;
					
					break;
			

				default:
					break;
				}
				right.setLayoutParams(lp);
				
			
			}
				
				
		});
		
		f5 = (Button)first.findViewById(R.id.SD_button_f5);
		f5.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				//onResume();
				if(f5running){
					f5running = false;
					removeall();
					buildall();
				}
				
			}
		});
		
		JXadd = (Button)first.findViewById(R.id.SD_Button_JXJX);
		JXadd.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO 自动生成的方法存根
				info01.setVisibility(View.VISIBLE);
				
				Showwh();
				the_Type = "machine";

				
			}
		});
		
		GRadd = (Button)first.findViewById(R.id.SD_Button_GRGR);
		GRadd.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				
				info01.setVisibility(View.VISIBLE);
				
				Showwh();
				the_Type = "people";
				
			}
		});

		CLadd = (Button)first.findViewById(R.id.SD_Button_CLCL);
		CLadd.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				info01.setVisibility(View.VISIBLE);
				
				Showwh();
				the_Type = "material";
				
			}
		});
		
		QTadd = (Button)first.findViewById(R.id.SD_Button_QTQT);
		QTadd.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				info01.setVisibility(View.VISIBLE);
				
				Showwh();
				the_Type = "other";
				
			}
		});
		
		add =  (Button)first.findViewById(R.id.SD_Button_add);
		add.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				info02.setVisibility(View.GONE);
				ShowView(the_Type);
				//buildsceond();
				
			}
		});
		
		info01_QD =(Button)first.findViewById(R.id.SD_Button_info01QD);
		
		
		info01_QX =(Button)first.findViewById(R.id.SD_Button_info01QX);
		info01_QX.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO 自动生成的方法存根
				info01_Name.setText("");
				info01_BZ.setText("");
				info01.setVisibility(View.GONE);
				Stopwh();
				
			}
		});
		
		info02_QD = (Button)first.findViewById(R.id.SD_Button_info02QD);
		info02_QD.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				
				info02_Name.setText("");
				info02_BZ.setText("");
				info02.setVisibility(View.GONE);
				removeView();
				Stopwh();
				
			}
		});
		
		info02_SC = (Button)first.findViewById(R.id.SD_Button_info02SC);
	
		info02_XG = (Button)first.findViewById(R.id.SD_Button_info02XG);
		info02_XG.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				info01C.setVisibility(View.VISIBLE);
				info02.setVisibility(View.GONE);
				info01_NameC.setText(info02_Name.getText().toString().subSequence(5, info02_Name.getText().toString().length()));
				info01_BZC.setText(info02_BZ.getText().toString().subSequence(5, info02_BZ.getText().toString().length()));
			}
		});
		
		JX_QD = (Button)first.findViewById(R.id.SD_Button_JXQD);
		JX_QD.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				String name = JX_name.getText().toString();
				String price = JX_price.getText().toString();
				String bz = JX_bz.getText().toString();
				postSceond(name,price,"1",String.valueOf(JXTPi),bz,fatherid,"machine");
				JXinfo.setVisibility(View.GONE);
				info02.setVisibility(View.GONE);
				Stopwh();
				
		
				
			}
		});
		
		JXinfoQX =(Button)first.findViewById(R.id.SD_Button_JXQX);
		JXinfoQX.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				JXinfo.setVisibility(View.GONE);
				info02.setVisibility(View.VISIBLE);
				
				
			
			}
		});
		
		GR_QD = (Button)first.findViewById(R.id.SD_Button_GRQD);
		GR_QD.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				String name = GR_name.getText().toString();
				String price = GR_price.getText().toString();
				String bz = GR_bz.getText().toString();
				String num = "999999";
				postSceond(name,price,num,"1",bz,fatherid,"people");
				GRinfo.setVisibility(View.GONE);
				info02.setVisibility(View.GONE);
				Stopwh();
				
			}
		});
		
		GRinfoQX =(Button)first.findViewById(R.id.SD_Button_GRQX);
		GRinfoQX.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				GRinfo.setVisibility(View.GONE);
				info02.setVisibility(View.VISIBLE);
			
			}
		});
		
		CL_QD = (Button)first.findViewById(R.id.SD_Button_CLQD);
		CL_QD.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				String name = CL_name.getText().toString();
				String price = CL_price.getText().toString();
				String bz = CL_bz.getText().toString();
				String num = "99999999.0";
				postSceond(name,price,num,CLitems[CLTPi],bz,fatherid,"material");
				CLinfo.setVisibility(View.GONE);
				info02.setVisibility(View.GONE);
				Stopwh();
				
				
			}
		});
		
		CLinfoQX =(Button)first.findViewById(R.id.SD_Button_CLQX);
		CLinfoQX.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				CLinfo.setVisibility(View.GONE);
				info02.setVisibility(View.VISIBLE);
			
			}
		});
		
		
		QT_QD = (Button)first.findViewById(R.id.SD_Button_QTQD);
		QT_QD.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				String name = QT_name.getText().toString();
				String bz = QT_bz.getText().toString();
				postSceond(name,"1","99999999.0","1",bz,fatherid,"other");
				QTinfo.setVisibility(View.GONE);
				info02.setVisibility(View.GONE);
				Stopwh();
			
				
			}
		});
		
		QTinfoQX =(Button)first.findViewById(R.id.SD_Button_QTQX);
		QTinfoQX.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				QTinfo.setVisibility(View.GONE);
				info02.setVisibility(View.VISIBLE);
			
			}
		});
		
		
		fanhui=(Button) second.findViewById(R.id.LG_button_ret);
		fanhui.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				MainActivity.this.finish();
			}
		});
		
		JXinfo2QD = (Button) first.findViewById(R.id.SD_Button_JXinfoQD);
		JXinfo2QD.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				postlocation("1", "0","");
				JXinfo02.setVisibility(View.GONE);
				//info02.setVisibility(View.VISIBLE);
				Stopwh();
				
			}
		});
		
		JXinfo2QX = (Button) first.findViewById(R.id.SD_Button_JXinfoQX);
		JXinfo2QX.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				JXinfo02.setVisibility(View.GONE);
				info02.setVisibility(View.VISIBLE);
			}
		});
		
		
		GRinfo2QD = (Button) first.findViewById(R.id.SD_Button_GRinfoQD);
		GRinfo2QD.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				postlocation(GRinfoUser.getText().toString(), "0",GRinfoBZ.getText().toString());
				GRinfo02.setVisibility(View.GONE);
				//info02.setVisibility(View.VISIBLE);
				Stopwh();
			}
		});
		
		GRinfo2QX = (Button) first.findViewById(R.id.SD_Button_GRinfoQX);
		GRinfo2QX.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				GRinfo02.setVisibility(View.GONE);
				info02.setVisibility(View.VISIBLE);
			}
		});
		
		
		CLinfo2QD = (Button) first.findViewById(R.id.SD_Button_CLinfoQD);
		CLinfo2QD.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				
				//updateproperty(CLNAME, CLPRICE, CLinfo2Num.getText().toString());
				updateCL();
				CLinfo02.setVisibility(View.GONE);
				Stopwh();
			}
		
		
		
		}
				
			
		);
		
		CLinfo2QX = (Button) first.findViewById(R.id.SD_Button_CLinfoQX);
		CLinfo2QX.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				CLinfo02.setVisibility(View.GONE);
				info02.setVisibility(View.VISIBLE);
			}
		});
		
		
		QTinfo2QD = (Button) first.findViewById(R.id.SD_Button_QTinfoQD);
		QTinfo2QD.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				updateQT();
				QTinfo02.setVisibility(View.GONE);
				Stopwh();
				
			}
		});
		
		QTinfo2QX = (Button) first.findViewById(R.id.SD_Button_QTinfoQX);
		QTinfo2QX.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				
				QTinfo02.setVisibility(View.GONE);
				info02.setVisibility(View.VISIBLE);
			}
		});
		
		
		JXinfo3QD = (Button) first.findViewById(R.id.SD_Button_JXinfo3QD);
		JXinfo3QD.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View V) {
				// TODO 自动生成的方法存根
				 LayoutInflater factory = LayoutInflater.from(MainActivity.this);
	                final View textEntryView = factory.inflate(R.layout.dia, null);
				if(JX3_s==0)
					new  AlertDialog.Builder(MainActivity.this)   
				.setTitle("开始施工" )  
				.setMessage("是否开始？" )
				.setView(textEntryView)
				.setPositiveButton("取消" , null)  
				 .setNegativeButton("确定", new DialogInterface.OnClickListener() {
					 public void onClick(DialogInterface dialog, int whichButton) {
						 EditText tex = (EditText) textEntryView.findViewById(R.id.username_edit);
						 updatelocation(JX3_id,JX3_fatherid, 1, JX3_newl, JX3_newt, 1,tex.getText().toString());
						 JXinfo03.setVisibility(View.GONE);
													}
					
							
					 }
				 )
				.show();
				
				else if (JX3_s==1)
					new  AlertDialog.Builder(MainActivity.this)   
				.setTitle("停止施工" )  
				.setMessage("是否停止？" )
				.setView(textEntryView)
				.setPositiveButton("取消" , null)  
				 .setNegativeButton("确定", new DialogInterface.OnClickListener() {
					 public void onClick(DialogInterface dialog, int whichButton) {
						 EditText tex = (EditText) textEntryView.findViewById(R.id.username_edit);
						 updatelocation(JX3_id,JX3_fatherid, 1, JX3_newl, JX3_newt, 0,tex.getText().toString());
						 JXinfo03.setVisibility(View.GONE);
						 
													}
					
							
					 }
				 )
				.show();
				
					
			}
		});
		
		JXinfo3QX = (Button) first.findViewById(R.id.SD_Button_JXinfo3QX);
		JXinfo3QX.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				JXinfo03.setVisibility(View.GONE);
			}
		});
		
		
		GRinfo3QD = (Button) first.findViewById(R.id.SD_Button_GRinfo3QD);
		GRinfo3QD.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View V) {
				// TODO 自动生成的方法存根
				 LayoutInflater factory = LayoutInflater.from(MainActivity.this);
	                final View textEntryView = factory.inflate(R.layout.dia, null);
				if(GR3_s==0)
					new  AlertDialog.Builder(MainActivity.this)   
				.setTitle("开始施工" )  
				.setMessage("是否开始？" )
				.setView(textEntryView)
				.setPositiveButton("取消" , null)  
				 .setNegativeButton("确定", new DialogInterface.OnClickListener() {
					 public void onClick(DialogInterface dialog, int whichButton) {
						 EditText tex = (EditText) textEntryView.findViewById(R.id.username_edit);
						 updatelocation(GR3_id,GR3_fatherid, 1, GR3_newl, GR3_newt, 1,tex.getText().toString());
						 GRinfo03.setVisibility(View.GONE);
													}
					
							
					 }
				 )
				.show();
				
				
				else if (GR3_s==1)
					new  AlertDialog.Builder(MainActivity.this)   
				.setTitle("停止施工" )  
				.setMessage("是否停止？" )
				.setView(textEntryView)
				.setPositiveButton("取消" , null)  
				 .setNegativeButton("确定", new DialogInterface.OnClickListener() {
					 public void onClick(DialogInterface dialog, int whichButton) {
						 EditText tex = (EditText) textEntryView.findViewById(R.id.username_edit);
						 updatelocation(GR3_id,GR3_fatherid, 1, GR3_newl, GR3_newt, 0,tex.getText().toString());
						 GRinfo03.setVisibility(View.GONE);
													}
					
							
					 }
				 )
				.show();
					
			}
		});
		
		GRinfo3QX = (Button) first.findViewById(R.id.SD_Button_GRinfo3QX);
		GRinfo3QX.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				GRinfo03.setVisibility(View.GONE);
			}
		});
		
		ShowQD = (Button) first.findViewById(R.id.SD_button_moveQD);
		ShowQD.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				updateImg();
				
			}
		});
		
		ShowQX = (Button) first.findViewById(R.id.SD_button_moveQX);
		ShowQX.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				//onResume();
				removeall();
				buildall();
				Show2.setVisibility(View.GONE);
			}
		});
		

		info01QDC = (Button) first.findViewById(R.id.SD_Button_info01QDC);
		info01QDC.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				if(Manager){
				new  AlertDialog.Builder(MainActivity.this)   
				.setTitle("修改合同" )  
				.setMessage("是否修改此合同内容？" )
				.setPositiveButton("取消" , null)  
				 .setNegativeButton("确定", new DialogInterface.OnClickListener() {
					 public void onClick(DialogInterface dialog, int whichButton) {
						 ChangeContract(String.valueOf(contractId), "1", info01_NameC.getText().toString(), info01_BZC.getText().toString());
												}
					
							
					 }
				 )
				.show();}else{
					Toast.makeText(getApplicationContext(), "权限不足，无法修改合同内容。",
						     Toast.LENGTH_SHORT).show();
				}
				
				
			}
		});
		
		info01QXC = (Button) first.findViewById(R.id.SD_Button_info01QXC);
		info01QXC.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				info01C.setVisibility(View.GONE);
				info01_BZC.setText("");
				info01_NameC.setText("");
				info02.setVisibility(View.VISIBLE);
	
				
			}
		});
		
		

		JXinfo01QDC = (Button) first.findViewById(R.id.SD_Button_JXQDC);
		JXinfo01QDC.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				if(Manager){
				new  AlertDialog.Builder(MainActivity.this)   
				.setTitle("修改合同项信息" )  
				.setMessage("是否修改此机械信息？" )
				.setPositiveButton("取消" , null)  
				 .setNegativeButton("确定", new DialogInterface.OnClickListener() {
					 public void onClick(DialogInterface dialog, int whichButton) {
						 ChangeP(String.valueOf(fatherid), JXinfo01_PC.getText().toString(), JXinfo01_NameC.getText().toString(), JXinfo01_BZC.getText().toString(),JXNUM.toString(),JXimage);
						 JXinfo01C.setVisibility(View.GONE);
						 info02.setVisibility(View.GONE);
						 Stopwh();
													}
					
							
					 }
				 )
				.show();}
				else{
					Toast.makeText(getApplicationContext(), "权限不足，无法修改机械信息。",
						     Toast.LENGTH_SHORT).show();
				}
				
			}
		});
		
		JXinfo01QXC = (Button) first.findViewById(R.id.SD_Button_JXQXC);
		JXinfo01QXC.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				JXinfo01C.setVisibility(View.GONE);
				JXinfo01_PC.setText("");
				JXinfo01_BZC.setText("");
				JXinfo01_NameC.setText("");
				removeView();
				 Stopwh();
			}
		});
		
	
		
		
		GRinfo01QDC = (Button) first.findViewById(R.id.SD_Button_GRQDC);
		GRinfo01QDC.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				if(Manager){
				new  AlertDialog.Builder(MainActivity.this)   
				.setTitle("修改合同项信息" )  
				.setMessage("是否进行修改？" )
				.setPositiveButton("取消" , null)  
				 .setNegativeButton("确定", new DialogInterface.OnClickListener() {
					 public void onClick(DialogInterface dialog, int whichButton) {
						 DecimalFormat decimalFormat=new DecimalFormat(".");
						 ChangeP(String.valueOf(fatherid), GRinfo01_PC.getText().toString(), GRinfo01_NameC.getText().toString(), GRinfo01_BZC.getText().toString(),String.valueOf(999999-Double.valueOf(decimalFormat.format(GRYY))),"1");
						 GRinfo01C.setVisibility(View.GONE);
						 info02.setVisibility(View.GONE);
						 Stopwh();
													}
					
							
					 }
				 )
				.show();}
				else{
					Toast.makeText(getApplicationContext(), "权限不足，无法修改工程队信息。",
					     Toast.LENGTH_SHORT).show();
					}
				
			}
		});
		
		GRinfo01QXC = (Button) first.findViewById(R.id.SD_Button_GRQXC);
		GRinfo01QXC.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				GRinfo01C.setVisibility(View.GONE);
				GRinfo01_PC.setText("");
				GRinfo01_BZC.setText("");
				GRinfo01_NameC.setText("");
				 Stopwh();
				 removeView();
				
			}
		});
		
	
		
		CLinfo01QDC = (Button) first.findViewById(R.id.SD_Button_CLQDC);
		CLinfo01QDC.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				if(Manager){
				new  AlertDialog.Builder(MainActivity.this)   
				.setTitle("修改合同项信息" )  
				.setMessage("是否进行修改？" )
				.setPositiveButton("取消" , null)  
				 .setNegativeButton("确定", new DialogInterface.OnClickListener() {
					 public void onClick(DialogInterface dialog, int whichButton) {
						 DecimalFormat decimalFormat=new DecimalFormat(".00");
						 ChangeP(String.valueOf(fatherid), CLinfo01_PC.getText().toString(), CLinfo01_NameC.getText().toString(), CLinfo01_BZC.getText().toString(),String.valueOf(99999999-Double.valueOf(decimalFormat.format(CLYY))),CLimage);
						 CLinfo01C.setVisibility(View.GONE);
						 info02.setVisibility(View.GONE);
						 Stopwh();
													}
					
							
					 }
				 )
				.show();}
				else{
					Toast.makeText(getApplicationContext(), "权限不足，无法修改工程队信息。",
					     Toast.LENGTH_SHORT).show();
					}
				
			}
		});
		
		CLinfo01QXC = (Button) first.findViewById(R.id.SD_Button_CLQXC);
		CLinfo01QXC.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				CLinfo01C.setVisibility(View.GONE);
				CLinfo01_PC.setText("");
				CLinfo01_BZC.setText("");
				CLinfo01_NameC.setText("");
				 Stopwh();
				 removeView();
				
			}
		});
		
		
		QTinfo01QDC = (Button) first.findViewById(R.id.SD_Button_QTQDC);
		QTinfo01QDC.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				if(Manager){
				new  AlertDialog.Builder(MainActivity.this)   
				.setTitle("修改合同项信息" )  
				.setMessage("是否进行修改？" )
				.setPositiveButton("取消" , null)  
				 .setNegativeButton("确定", new DialogInterface.OnClickListener() {
					 public void onClick(DialogInterface dialog, int whichButton) {
						 DecimalFormat decimalFormat=new DecimalFormat(".00");
						 ChangeP(String.valueOf(fatherid),"1", QTinfo01_NameC.getText().toString(), QTinfo01_BZC.getText().toString(),String.valueOf(99999999-Double.valueOf(decimalFormat.format(QTYY))),"1");
						 QTinfo01C.setVisibility(View.GONE);
						 info02.setVisibility(View.GONE);
						 Stopwh();
													}
					
							
					 }
				 )
				.show();}
				else{
					Toast.makeText(getApplicationContext(), "权限不足，无法修改工程队信息。",
					     Toast.LENGTH_SHORT).show();
					}
				
			}
		});
		
		QTinfo01QXC = (Button) first.findViewById(R.id.SD_Button_QTQXC);
		QTinfo01QXC.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
			QTinfo01C.setVisibility(View.GONE);
			
				QTinfo01_BZC.setText("");
				QTinfo01_NameC.setText("");
				 Stopwh();
				 removeView();
				
			}
		});
		

		
		JXLC = (Button)first.findViewById(R.id.SD_Button_JXinfo3LC);
		JXLC.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				deteleL(JX3_id, JX3_fatherid);
				JXinfo03.setVisibility(View.GONE);
				
			}
		});
		
		GRLC = (Button)first.findViewById(R.id.SD_Button_GRinfo3LC);
		GRLC.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				deteleL(GR3_id, GR3_fatherid);
				GRinfo03.setVisibility(View.GONE);
			}
		});
		
		showPerson = (Button)second.findViewById(R.id.LG_button_people);
		showPerson.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				Intent intent = new Intent();
				intent.putExtra("PROJECTID", PROJECTID);
				intent.putExtra("POWER", "0");
				intent.setClass(MainActivity.this, PersonActivity.class);
				startActivity(intent);
				
			}
		});
		
		
		JXTPTV = (TextView) first.findViewById(R.id.SD_textview_JX_Type2);
		JXTP = (Button)first.findViewById(R.id.SD_Button_JXTP);
		JXTP.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
			
				
			        AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);  //先得到构造器
			        builder.setTitle("工程车辆类型"); //设置标题
			        builder.setSingleChoiceItems(JXitems,JXTPi,new DialogInterface.OnClickListener() {
			            @Override
			            public void onClick(DialogInterface dialog, int which) {
			                //dialog.dismiss();
			              JXTPi = which;
			            }
			        });
			        builder.setPositiveButton("确定",new DialogInterface.OnClickListener() {
			            @Override
			            public void onClick(DialogInterface dialog, int which) {
			                
			               JXTPTV.setText(JXitems[JXTPi]);
			               dialog.dismiss();
			            }
			        });
			        builder.create().show();
			}
		});
		
		
		CLTPTV = (TextView) first.findViewById(R.id.SD_textview_CL_TP2);
		CLTP = (Button) first.findViewById(R.id.SD_Button_CLTP);
		CLTP.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				    AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);  //先得到构造器
			        builder.setTitle("材料单位"); //设置标题
			        builder.setSingleChoiceItems(CLitems,CLTPi,new DialogInterface.OnClickListener() {
			            @Override
			            public void onClick(DialogInterface dialog, int which) {
			                //dialog.dismiss();
			              CLTPi = which;
			            }
			        });
			        builder.setPositiveButton("确定",new DialogInterface.OnClickListener() {
			            @Override
			            public void onClick(DialogInterface dialog, int which) {
			                
			               CLTPTV.setText(CLitems[CLTPi]);
			               dialog.dismiss();
			            }
			        });
			        builder.create().show();
				
			}
		});
		
		
		mAdapter = new PagerAdapter()
		{
			@Override
			public void destroyItem(ViewGroup container, int position, Object object)
			{
				container.removeView(mViews.get(position));
			}

			@Override
			public Object instantiateItem(ViewGroup container, int position)
			{
				View view = mViews.get(position);
				container.addView(view);
				return view;
			}

			@Override
			public boolean isViewFromObject(View arg0, Object arg1)
			{
				return arg0 == arg1;
			}

			@Override
			public int getCount()
			{
				return mViews.size();
			}
		};
		
		TodayButton = (Button) second.findViewById(R.id.LG_button_searchtoday);
		TodayButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				logType = 0;
				removeLG();
				getLog();
				
				
			}
		});
		
		UserButton = (Button) second.findViewById(R.id.LG_button_searchM);
		UserButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				logType = 1;
				removeLG();
				getLogU();
				
				
			}
		});
		
		
		buildall();
		
	}
	private void initEvent() {
		// TODO 自动生成的方法存根
		 mViewpager.setAdapter(mAdapter);
		 
		 mViewpager.setOnPageChangeListener(new OnPageChangeListener() {	
			 @Override
				public void onPageSelected(int position)
				{
					
				}

				@Override
				public void onPageScrolled(int arg0, float arg1, int arg2)
				{

				}

				@Override
				public void onPageScrollStateChanged(int arg0)
				{
				}
			});
		 
		 
		 info01_QD.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO 自动生成的方法存根
					//buildView(info01value+"", info01_HT.getText().toString(), info01_Name.getText().toString()+" ", info01_BZ.getText().toString());
					
					if(Manager){
					new  AlertDialog.Builder(MainActivity.this)   
					.setTitle("添加合同" )  
					.setMessage("是否添加此合同？" )
					.setPositiveButton("取消" , null)  
					 .setNegativeButton("确定", new DialogInterface.OnClickListener() {
						 public void onClick(DialogInterface dialog, int whichButton) {
								Toast.makeText(getApplicationContext(),"创建信息已发送。",
									     Toast.LENGTH_SHORT).show();
								
								List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
								nameValuePairs.add(new BasicNameValuePair("userId",User.getId()));
								nameValuePairs.add(new BasicNameValuePair("userTrueName",User.getName() ));
								nameValuePairs.add(new BasicNameValuePair("projectId",PROJECTID ));
								
								nameValuePairs.add(new BasicNameValuePair("contractCompany",info01_Name.getText().toString() ));
								nameValuePairs.add(new BasicNameValuePair("contractRemark", info01_BZ.getText().toString()));
								nameValuePairs.add(new BasicNameValuePair("contractType", the_Type));
								nameValuePairs.add(new BasicNameValuePair("contractNo", "1"));
								String url = ProURL.url+"contract.do?method=create";
								Handler handler = new Handler(){
									@Override
									public void handleMessage(Message msg) {

										switch(msg.what){
											case 1:
												JSONObject json = thread.getJSONObject();
											String code;
											try {
												code = json.getString("code");
												if(code.equals("00000")){
													//onResume();
													removeall();
													buildall();
												}else{
													Toast.makeText(getApplicationContext(), json.getString("msg"),
														     Toast.LENGTH_SHORT).show();
												}
											} catch (JSONException e) {
												// TODO 自动生成的 catch 块
												e.printStackTrace();
											}
												
												break;
											case 2:
												Toast.makeText(getApplicationContext(), "连接超时，请重试。",
													     Toast.LENGTH_SHORT).show();
												break;
											default:
												break;
										}
									}
								};
					            thread= new NetworkThread(url, nameValuePairs,handler);
					            thread.start();
								
								info01_Name.setText("");
								info01_BZ.setText("");
								info01.setVisibility(View.GONE);
								Stopwh();
						 }
					 })
					.show();
					}else{
						Toast.makeText(getApplicationContext(), "权限不足，无法创建合同。",
							     Toast.LENGTH_SHORT).show();
					}
				
					
				}
			});
		 
		 
			info02_SC.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View arg0) {
					// TODO 自动生成的方法存根
					if(Manager){
					new  AlertDialog.Builder(MainActivity.this)   
					.setTitle("删除合同" )  
					.setMessage("是否删除此合同？" )
					.setPositiveButton("取消" , null)  
					 .setNegativeButton("确定", new DialogInterface.OnClickListener() {
						 public void onClick(DialogInterface dialog, int whichButton) {
								Toast.makeText(getApplicationContext(),"请求已发送。",
									     Toast.LENGTH_SHORT).show();
								List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
								nameValuePairs.add(new BasicNameValuePair("userId",User.getId() ));
								nameValuePairs.add(new BasicNameValuePair("userTrueName",User.getName() ));
								nameValuePairs.add(new BasicNameValuePair("projectId",PROJECTID ));
								nameValuePairs.add(new BasicNameValuePair("contractId",String.valueOf(contractId) ));
								
								String url = ProURL.url+"contract.do?method=delete";
								Handler handler = new Handler(){
									@Override
									public void handleMessage(Message msg) {

										switch(msg.what){
											case 1:
												JSONObject json = thread.getJSONObject();
												try {
													String code  = json.getString("code");
													if(code.equals("00000")){
														//onResume();
														removeall();
														buildall();
														info02.setVisibility(View.GONE);
														Stopwh();
						
													}else{
														Toast.makeText(getApplicationContext(), json.getString("msg"),
															     Toast.LENGTH_SHORT).show();
													}
												} catch (JSONException e) {
												// TODO 自动生成的 catch 块
													e.printStackTrace();
												}
												
												break;
											case 2:
												Toast.makeText(getApplicationContext(), "连接超时，请重试。",
													     Toast.LENGTH_SHORT).show();
												break;
											default:
												break;
										}
									}
								};
					            thread= new NetworkThread(url, nameValuePairs,handler);
					            thread.start();
								
						 }
					 })
					.show();
					}else{
						Toast.makeText(getApplicationContext(), "权限不足，无法删除合同。",
							     Toast.LENGTH_SHORT).show();
					}
				
					
			
					
					

				}
			});
		
		
	}
	private void buildImageView(final int cid,final int father_id,final int id,int x ,int y,final String type,final int s,final int number,final String name,final String price,final String bz,final String image){
		final LinearLayout Ibtn = new LinearLayout(SDialog.getContext());
		Ibtn.setId(id);
		RelativeLayout.LayoutParams lp =new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		//lp.width=150;
		//lp.height=150;
		lp.leftMargin = x;
		lp.topMargin = y;
		Ibtn.setId(id);
		Ibtn.setOrientation(LinearLayout.VERTICAL);
		
		
		
		ImageView Img = new ImageView(SDialog.getContext());
		RelativeLayout.LayoutParams lp1 =new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		lp1.width=100;
		lp1.height=100;
		Img.setLayoutParams(lp1);
		switch (type) {
		case "1":
			if(s==1)
				switch (image) {
				case "0":
					Img.setImageDrawable(getResources().getDrawable(R.drawable.p11));
					break;
				case "1":
					Img.setImageDrawable(getResources().getDrawable(R.drawable.p21));
					break;
				case "2":
					Img.setImageDrawable(getResources().getDrawable(R.drawable.p31));
					break;
				case "3":
					Img.setImageDrawable(getResources().getDrawable(R.drawable.p41));
					break;
				case "4":
					Img.setImageDrawable(getResources().getDrawable(R.drawable.p51));
					break;
				case "5":
					Img.setImageDrawable(getResources().getDrawable(R.drawable.p61));
					break;
				case "6":
					Img.setImageDrawable(getResources().getDrawable(R.drawable.p71));
					break;
				case "7":
					Img.setImageDrawable(getResources().getDrawable(R.drawable.p81));
					break;
				case "8":
					Img.setImageDrawable(getResources().getDrawable(R.drawable.p91));
					break;
				case "9":
					Img.setImageDrawable(getResources().getDrawable(R.drawable.p101));
				case "10":
					Img.setImageDrawable(getResources().getDrawable(R.drawable.p111));
					break;
				case "11":
					Img.setImageDrawable(getResources().getDrawable(R.drawable.p121));
					break;
				case "12":
					Img.setImageDrawable(getResources().getDrawable(R.drawable.p131));
					break;
				case "13":
					Img.setImageDrawable(getResources().getDrawable(R.drawable.p141));
					break;
				case "14":
					Img.setImageDrawable(getResources().getDrawable(R.drawable.p151));
					break;
				default:
					break;
				}
				//Img.setImageDrawable(getResources().getDrawable(R.drawable.machine1));
			else if(s==0)
				switch (image) {
				case "0":
					Img.setImageDrawable(getResources().getDrawable(R.drawable.p10));
					break;
				case "1":
					Img.setImageDrawable(getResources().getDrawable(R.drawable.p20));
					break;
				case "2":
					Img.setImageDrawable(getResources().getDrawable(R.drawable.p30));
					break;
				case "3":
					Img.setImageDrawable(getResources().getDrawable(R.drawable.p40));
					break;
				case "4":
					Img.setImageDrawable(getResources().getDrawable(R.drawable.p50));
					break;
				case "5":
					Img.setImageDrawable(getResources().getDrawable(R.drawable.p60));
					break;
				case "6":
					Img.setImageDrawable(getResources().getDrawable(R.drawable.p70));
					break;
				case "7":
					Img.setImageDrawable(getResources().getDrawable(R.drawable.p80));
					break;
				case "8":
					Img.setImageDrawable(getResources().getDrawable(R.drawable.p90));
					break;
				case "9":
					Img.setImageDrawable(getResources().getDrawable(R.drawable.p100));
					break;
				case "10":
					Img.setImageDrawable(getResources().getDrawable(R.drawable.p110));
					break;
				case "11":
					Img.setImageDrawable(getResources().getDrawable(R.drawable.p120));
					break;
				case "12":
					Img.setImageDrawable(getResources().getDrawable(R.drawable.p130));
					break;
				case "13":
					Img.setImageDrawable(getResources().getDrawable(R.drawable.p140));
					break;
				case "14":
					Img.setImageDrawable(getResources().getDrawable(R.drawable.p150));
					break;
				default:
					break;
				}
				//Img.setImageDrawable(getResources().getDrawable(R.drawable.machine_stop));
			break;
		case "2":
			if(s==1)
				Img.setImageDrawable(getResources().getDrawable(R.drawable.worker));
			else if(s==0)
				Img.setImageDrawable(getResources().getDrawable(R.drawable.worker_stop));
			break;
		default:
			break;
		}
		Img.setBackgroundColor(0X00FFFFFF);
		Img.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
		

		Img.setOnTouchListener(new OnTouchListener() {
			int	startX;
			int	startY;
			int X,Y;
			int NL,NT;

			@Override
			public boolean onTouch( View v, MotionEvent event ) {
				switch ( event.getAction() ) {
				case MotionEvent.ACTION_DOWN:// 手指第一次触摸到屏幕
					startX = ( int ) event.getRawX();
					startY = ( int ) event.getRawY();
					X = Ibtn.getLeft();
					Y = Ibtn.getTop();
					break;
				case MotionEvent.ACTION_MOVE:// 手指移动
					int newX = ( int ) event.getRawX();
					int newY = ( int ) event.getRawY();

					int dx = newX - startX;
					int dy = newY - startY;

					// 计算出来控件原来的位置
					int l = Ibtn.getLeft();
					int r = Ibtn.getRight();
					int t = Ibtn.getTop();
					int b = Ibtn.getBottom();

					int newt = t + dy;
					NT=newt;
					int newb = b + dy;
					int newl = l + dx;
					NL = newl;
					int newr = r + dx;

					if ( ( newl < 0 ) || ( newt < 0 )
							|| ( newr > addv.getWidth() )
							|| ( newb > addv.getHeight()) ) {
						break;
					}

					// 更新iv在屏幕的位置.
					
							Ibtn.layout( newl , newt , newr , newb );
							
							
							
					startX = ( int ) event.getRawX();
					startY = ( int ) event.getRawY();

					break;
				case MotionEvent.ACTION_UP: // 手指离开屏幕的一瞬间
					int lastx = Ibtn.getLeft();
					int lasty = Ibtn.getTop();
					if(X == lastx&&Y == lasty||(Math.abs(X-lastx)+Math.abs(Y-lasty)<10)){
						contractId = cid;
						
						switch (type) {
						case "1":
							JX3_fatherid = father_id;
							JX3_id = id;
							JX3_newl = lasty;
							JX3_newt = lastx;
							JX3_s = s;
							JXinfo3ID.setText("机械编号："+father_id);
							JXinfo3Name.setText("机械名称："+name);
							JXinfo3Price.setText("机械价格："+price+" 元/小时");
							JXinfo3BZ.setText("机械备注："+bz);
							if (s==1)
								JXinfo3QD.setText("停止");
							else if (s==0)
								JXinfo3QD.setText("开始");
							JXinfo03.setVisibility(View.VISIBLE);
							
							break;
						case "2":
							GR3_fatherid = father_id;
							GR3_id = id;
							GR3_newl = lasty;
							GR3_newt = lastx;
							GR3_s = s;
							if (s==1)
								GRinfo3QD.setText("停止");
							else if (s==0)
								GRinfo3QD.setText("开始");
							GRinfo3ID.setText("工队编号："+father_id);
							GRinfo3Name.setText("工队名称："+name);
							GRinfo3Price.setText("用工价格："+price+" 元/小时");
							GRinfo3Num.setText("工人数量："+number+" 人");
							GRinfo03.setVisibility(View.VISIBLE);
							break;

						default:
							break;
						}
					}else{
						try{
						Show1.setVisibility(View.GONE);
						Show2.setVisibility(View.VISIBLE);
						int count = 0;
						for(int i = 0;i<img.length();i++){
							if( img.getJSONObject(i).getInt("id")== id){

								img.getJSONObject(i).put("latitude",NT);
								img.getJSONObject(i).put("longitude",NL);

								
								count = 1;
							}
						}
						if(count==0){
							JSONObject lt = new JSONObject();
							lt.put("id",id);
							lt.put("property",father_id);
							lt.put("number",number);
							lt.put("latitude",NT);
							lt.put("longitude",NL);
							lt.put("status",s);
							img.put(lt);
							//JSONObject I = new JSONObject(lt);
							//img.put(lt);
						}
						}catch(JSONException e){
							e.printStackTrace();
						}
						
						//updatelocation(id, father_id, number, NT, NL, s);
					}

					break;
				}
				return true;
			}
		} );
		Ibtn.setLayoutParams(lp);
		
		
	
		
		TextView BH = new TextView(SDialog.getContext());
		RelativeLayout.LayoutParams lp2 =new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		lp2.height=32;
		BH.setLayoutParams(lp2);
		BH.setText("编号："+father_id);
		BH.setTextSize(9);
		BH.setGravity(Gravity.CENTER);
		
		TextPaint tp = BH.getPaint(); 
		tp.setFakeBoldText(true);
		Ibtn.addView(BH);
		Ibtn.addView(Img);
		
		if(type=="2"){
			TextView RS = new TextView(SDialog.getContext());
			RS.setLayoutParams(lp2);
			RS.setText(bz+"："+number);
			RS.setTextSize(9);
			RS.setGravity(Gravity.CENTER);
			
			TextPaint t = RS.getPaint(); 
			t.setFakeBoldText(true);
			Ibtn.addView(RS);
		}
		
		addv.addView(Ibtn);
		
	}
	
	private void Showwh(){
		wh.setVisibility(View.VISIBLE);
		wh.setClickable(true);
	}
	private void Stopwh(){
		wh.setVisibility(View.GONE);
		wh.setClickable(false);
	}
	
	private void StopJZ(){
		Jiazai.setVisibility(View.GONE);
		Jiazai.setClickable(false);
	}
	
	private void buildView(final String type,final String id,final String no,final String name,final String bz){
		final Button btn = new Button(SDialog.getContext());
		RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.FILL_PARENT);
		Drawable drawable1 = getResources().getDrawable(R.drawable.ht);
	    drawable1.setBounds(0, 0, rW/5, rW/5);//第一0是距左边距离，第二0是距上边距离，40分别是长宽
	    btn.setCompoundDrawables(drawable1, null, null, null);
	    lp.height = rW/3-20;
	    btn.setLayoutParams(lp);

		btn.setBackgroundDrawable(getResources().getDrawable(R.drawable.buttonback));
		btn.setId( Integer.parseInt(id));
		String a = name+"                          ";
		btn.setText(id+"  "+a.subSequence(0, 4));
		btn.setTextSize(9);
		btn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO 自动生成的方法存根
				Showwh();
				info02.setVisibility(View.VISIBLE);
				info02_ID.setText("合同编号："+id);
				info02_Name.setText("合同名称："+name);
				info02_BZ.setText("合同备注："+bz);
				fatherid = btn.getId();
				contractId = btn.getId();
				switch (type) {
				case "1":
					the_Type = "machine";
					break;
				case "2":
					the_Type = "people";
					break;
				case "3":
					the_Type = "material";
					break;
				case "4":
					the_Type = "other";
					break;

				default:
					break;
				}
				try {
					String info = Subkey.getString(id);
					if(info!=null){
						JSONArray PTS = new JSONArray(info);
						for(int i=0;i<PTS.length();i++){
							JSONObject pts = new JSONObject(PTS.getString(i));
							int Pid = pts.getInt("id");
							String name = pts.getString("name");
							String price = pts.getString("price");
							double num = pts.getDouble("total");
							System.out.print(num);
							String image = pts.getString("img");
							String bz = pts.getString("remark");
							buildsceond(Pid,type,name,price,num,bz,id,image);
						}
						
					}
					
				} catch (JSONException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}
				
				
			}
		});
		switch (type) {
		case "1":
			JXRL.addView(btn);
			break;
		case "2":
			GRRL.addView(btn);
			break;
		case "3":
			CLRL.addView(btn);
			break;
		case "4":
			QTRL.addView(btn);
			break;

		}
		
	}
	
	private void ShowView(String type){
		switch (type) {
		case "machine":
			JXinfo.setVisibility(View.VISIBLE);
			break;
		case "people":
			GRinfo.setVisibility(View.VISIBLE);
			break;
		case "material":
			CLinfo.setVisibility(View.VISIBLE);
			break;
		case "other":
			QTinfo.setVisibility(View.VISIBLE);
			break;

		default:
			break;
		}
	}
	private void buildsceond(final int id,String type,final String name,final String price,final Double num,final String bz, String Cid,final String image){
		int x = info02.getWidth();
		
		
		LinearLayout view = new LinearLayout(SDialog.getContext());
		RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		
		
		RelativeLayout view3 = new RelativeLayout(SDialog.getContext());
		view3.setGravity(Gravity.CENTER);
		RelativeLayout.LayoutParams lp6= new RelativeLayout.LayoutParams(x/2, x/6);
		final Button btn = new Button(SDialog.getContext());
		RelativeLayout.LayoutParams lp1 = new RelativeLayout.LayoutParams(x/2, x/6);
		
		contractId = Integer.parseInt(Cid);
		Drawable drawable1 = getResources().getDrawable(R.drawable.prt);
	    drawable1.setBounds(0, 0, x/8, x/8);//第一0是距左边距离，第二0是距上边距离，40分别是长宽
	    btn.setCompoundDrawables(drawable1, null, null, null);
	
			lp.height = x/6;
			 
			
			 btn.setLayoutParams(lp);
			 btn.setTextSize(13);
			 
			 btn.setBackgroundDrawable(getResources().getDrawable(R.drawable.buttonback));
			 btn.setId(id);
			
			 btn.setText("<"+id+">  "+name+"        ");
			 btn.setHorizontallyScrolling(true);
			 btn.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View arg0) {
					// TODO 自动生成的方法存根
					//buildImageView();
					info02.setVisibility(View.GONE);
					fatherid = btn.getId();
					DecimalFormat decimalFormat=new DecimalFormat(".00");
					
					switch (the_Type) {
					case "machine":	
						JXinfo2ID.setText("机械编号："+id);
						JXinfo2Name.setText("机械名称："+name);
						JXinfo2Price.setText("机械价格："+price+" 元/小时");
						JXinfo2BZ.setText("机械备注："+bz);
						if (num==0){
							
							JXinfo2QD.setClickable(false);
							JXinfo2QD.setBackgroundDrawable(getResources().getDrawable(R.drawable.buttonshape2));
						}
							
						else {
							JXinfo2QD.setClickable(true);
							JXinfo2QD.setBackgroundDrawable(getResources().getDrawable(R.drawable.buttonback));
							
						}
						JXNUM = num;
						JXinfo02.setVisibility(View.VISIBLE);
						break;
					case "people":	
						GRinfo2ID.setText("工队编号："+id);
						GRinfo2Name.setText("工队名称："+name);
						GRinfo2Price.setText("用工价格："+price+" 元/小时");
						GRinfoGDBZ.setText("工队备注："+bz);
						GRYY =999999-num;
						DecimalFormat decimalFormat1=new DecimalFormat(".");
						GRinfo2Num.setText("已用人数："+decimalFormat1.format(GRYY)+" 人");
						GRinfo02.setVisibility(View.VISIBLE);
						break;
					case "material":	
						CLNAME = name;
						CLPRICE = price;
						CLinfo2ID.setText("材料编号："+id);
						CLinfo2Name.setText("材料名称："+name);
						CLinfo2Price.setText("材料单价："+price+" 元");
						CLinfoGDBZ.setText("材料备注："+bz);
						CLYY =99999999-num;
						
						CLinfo2Num.setText("已用数量："+decimalFormat.format(CLYY)+" "+image);
						CLinfoTP.setText(image);
						CLinfo02.setVisibility(View.VISIBLE);
						
						break;
					case "other":	
						QTinfo2ID.setText("其他编号："+id);
						QTinfo2Name.setText("类别名称："+name);
						QTinfoGDBZ.setText("其他备注："+bz);
						QTYY = 99999999-num;
						QTinfo2Used.setText("已用金额："+decimalFormat.format(QTYY)+" 元");
						
						
						QTinfo02.setVisibility(View.VISIBLE);
						break;


					default:
						break;
					}
				}
			});
			 
			 
			 
			 
				RelativeLayout view2 = new RelativeLayout(SDialog.getContext());
				view2.setGravity(Gravity.CENTER);
				RelativeLayout.LayoutParams lp4= new RelativeLayout.LayoutParams(x/4, x/6);
				Button change = new Button(SDialog.getContext());
				RelativeLayout.LayoutParams lp5= new RelativeLayout.LayoutParams(x/6, x/6);
				change.setText("修改");
				change.setTextSize(9);
				change.setBackgroundDrawable(getResources().getDrawable(R.drawable.buttonback));
				change.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View arg0) {
						// TODO 自动生成的方法存根
						 info02.setVisibility(View.GONE);
						fatherid = id;
						switch (the_Type) {
						case "machine":	
							JXinfo01C.setVisibility(View.VISIBLE);
							JXinfo01_NameC.setText(name);
							JXinfo01_PC.setText(price);
							JXinfo01_BZC.setText(bz);
							JXNUM = num;
							JXimage = image;
							break;
						case "people":	
							GRinfo01C.setVisibility(View.VISIBLE);
							GRinfo01_NameC.setText(name);
							GRinfo01_PC.setText(price);
							GRinfo01_BZC.setText(bz);
							GRYY =999999-num;
							break;
						case "material":	
							
							CLinfo01C.setVisibility(View.VISIBLE);
							CLinfo01_NameC.setText(name);
							CLinfo01_PC.setText(price);
							CLinfo01_BZC.setText(bz);
							CLimage = image;
							CLYY =99999999-num;
							break;
						case "other":	
							QTinfo01C.setVisibility(View.VISIBLE);
							QTinfo01_NameC.setText(name);
							QTinfo01_BZC.setText(bz);
							QTYY = 99999999-num;
						
							break;


						default:
							break;
						}
					}
				});
				view2.addView(change,lp5);
			 
				RelativeLayout view1 = new RelativeLayout(SDialog.getContext());
				view1.setGravity(Gravity.CENTER);
				RelativeLayout.LayoutParams lp2= new RelativeLayout.LayoutParams(x/6, x/6);
				Button del = new Button(SDialog.getContext());
				RelativeLayout.LayoutParams lp3= new RelativeLayout.LayoutParams(x/6, x/6);
				del.setText("删除");
				del.setTextSize(9);
				del.setBackgroundDrawable(getResources().getDrawable(R.drawable.buttonback));
				del.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View arg0) {
						// TODO 自动生成的方法存根
						// TODO 自动生成的方法存根
						fatherid = id;
					
							if(Manager){
								new  AlertDialog.Builder(MainActivity.this)   
								.setTitle("删除合同项" )  
								.setMessage("是否删除？" )
								.setPositiveButton("取消" , null)  
								 .setNegativeButton("确定", new DialogInterface.OnClickListener() {
									 public void onClick(DialogInterface dialog, int whichButton) {
										 Dpro(String.valueOf(id));
										
										 info02.setVisibility(View.GONE);
										 
										 Stopwh();
																	}
									
											
									 }
								 )
								.show();
								}else{
									Toast.makeText(getApplicationContext(), "权限不足，无法进行删除操作。",
										     Toast.LENGTH_SHORT).show();
							}
						
					
						

						
					}
				});
				view1.addView(del,lp3);
			 
			view3.addView(btn, lp1);
			view.addView(view3, lp6);
			 view.addView(view2,lp4);
			 view.addView(view1, lp2);
			 
				
			 addRL.addView(view,lp);
		
		
	}
	
	
	@Override
	protected void onResume() {
		// TODO 自动生成的方法存根
		super.onResume();
		if(omg!=0){
			initView();
	    
	   
	    
			initEvent();
	    }
		omg++;
	}
	
	private void removeView() {
        //获取linearlayout子view的个数
        int count = addRL.getChildCount();
        for (int i=0;i<count; i++) {
            //用来判断当前linearlayout子view数多于2个，即还有我们点add增加的button
            addRL.removeViewAt(0);
        }
        count = addRL.getChildCount();
        
    }
	
	private void postSceond( final String name, final String price, final String total,final String image,  final String bz, final int fatherid2,final String conType){
		if(Manager){
			new  AlertDialog.Builder(MainActivity.this)   
			.setTitle("添加合同项" )  
			.setMessage("是否添加此合同项？" )
			.setPositiveButton("取消" , null)  
			 .setNegativeButton("确定", new DialogInterface.OnClickListener() {
				 public void onClick(DialogInterface dialog, int whichButton) {
					 
					 Toast.makeText(getApplicationContext(),"请求已发送。",
						     Toast.LENGTH_SHORT).show();
					List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
					nameValuePairs.add(new BasicNameValuePair("userId",User.getId()));
					nameValuePairs.add(new BasicNameValuePair("projectId",PROJECTID));
					nameValuePairs.add(new BasicNameValuePair("userTrueName",User.getName() ));
					nameValuePairs.add(new BasicNameValuePair("propertyImg",image ));
					nameValuePairs.add(new BasicNameValuePair("propertyName",name));
					nameValuePairs.add(new BasicNameValuePair("propertyTotal",total ));
					nameValuePairs.add(new BasicNameValuePair("propertyPrice",price));
					nameValuePairs.add(new BasicNameValuePair("contractId",String.valueOf(fatherid2)));
					nameValuePairs.add(new BasicNameValuePair("contractType",conType));
					nameValuePairs.add(new BasicNameValuePair("propertyRemark",bz ));
					
					String url = ProURL.url+"property.do?method=create";
					Handler handler = new Handler(){
						@Override
						public void handleMessage(Message msg) {

							switch(msg.what){
								case 1:
									JSONObject json = thread.getJSONObject();
									try {
										String code  = json.getString("code");
										if(code.equals("00000")){
											removeall();
											buildall();
											//onResume();
										}else{
											Toast.makeText(getApplicationContext(), json.getString("msg"),
												     Toast.LENGTH_SHORT).show();
										}
									} catch (JSONException e) {
									// TODO 自动生成的 catch 块
										e.printStackTrace();
									}
									
									break;
								case 2:
									Toast.makeText(getApplicationContext(), "连接超时，请重试。",
										     Toast.LENGTH_SHORT).show();
									break;
								default:
									break;
							}
						}
					};
			        thread= new NetworkThread(url, nameValuePairs,handler);
			        thread.start();
											}
				
						
				 }
			 )
			.show();
		
        }else{
        	Toast.makeText(getApplicationContext(), "权限不足，无法创建组件。",
				     Toast.LENGTH_SHORT).show();
        }
		
	}
	
	private void postlocation(String num,String status,String bz){
		Toast.makeText(getApplicationContext(),"请求已发送。",
			     Toast.LENGTH_SHORT).show();
		List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
		nameValuePairs.add(new BasicNameValuePair("userId",User.getId()));
		nameValuePairs.add(new BasicNameValuePair("userTrueName",User.getName()));
		nameValuePairs.add(new BasicNameValuePair("projectId",PROJECTID));
		nameValuePairs.add(new BasicNameValuePair("propertyId",String.valueOf(fatherid) ));
		nameValuePairs.add(new BasicNameValuePair("contractId",String.valueOf(contractId)));
		nameValuePairs.add(new BasicNameValuePair("locationNumber",num));
		nameValuePairs.add(new BasicNameValuePair("locationLatitude","100" ));
		nameValuePairs.add(new BasicNameValuePair("locationLongitude","100"));
		nameValuePairs.add(new BasicNameValuePair("locationStatus",status));
		nameValuePairs.add(new BasicNameValuePair("locationRemark",bz));
	
		
		String url = ProURL.url+"location.do?method=create";
		Handler handler = new Handler(){
			@Override
			public void handleMessage(Message msg) {

				switch(msg.what){
					case 1:
						JSONObject json = thread.getJSONObject();
						try {
							String code  = json.getString("code");
							if(code.equals("00000")){
								//onResume();
								removeall();
								buildall();
							}else{
								Toast.makeText(getApplicationContext(), json.getString("msg"),
									     Toast.LENGTH_SHORT).show();
							}
						} catch (JSONException e) {
						// TODO 自动生成的 catch 块
							e.printStackTrace();
						}
						
						break;
					case 2:
						Toast.makeText(getApplicationContext(), "连接超时，请重试。",
							     Toast.LENGTH_SHORT).show();
						break;
					default:
						break;
				}
			}
		};
        thread= new NetworkThread(url, nameValuePairs,handler);
        thread.start();
		
	}
	
	
	
	private void updatelocation(int locationid,int propertyid,int number, int x,int y, int status,String bz){
		//locationid propertyid number latitude longitude status
		Toast.makeText(getApplicationContext(),"请求已发送。",
			     Toast.LENGTH_SHORT).show();
		List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
		nameValuePairs.add(new BasicNameValuePair("userId",User.getId() ));
		nameValuePairs.add(new BasicNameValuePair("userTrueName",User.getName() ));
		nameValuePairs.add(new BasicNameValuePair("projectId",PROJECTID ));
		nameValuePairs.add(new BasicNameValuePair("contractId",String.valueOf(contractId) ));
		nameValuePairs.add(new BasicNameValuePair("locationId",String.valueOf(locationid) ));
		nameValuePairs.add(new BasicNameValuePair("propertyId",String.valueOf(propertyid)));
		nameValuePairs.add(new BasicNameValuePair("locationNumber",String.valueOf(number)));
		nameValuePairs.add(new BasicNameValuePair("locationLatitude",String.valueOf(x)));
		nameValuePairs.add(new BasicNameValuePair("locationLongitude",String.valueOf(y)));
		nameValuePairs.add(new BasicNameValuePair("locationStatus",String.valueOf(status)));
		nameValuePairs.add(new BasicNameValuePair("locationRemark",bz));
	
	
		
		String url = ProURL.url+"location.do?method=turn";
		Handler handler = new Handler(){
			@Override
			public void handleMessage(Message msg) {

				switch(msg.what){
					case 1:
						
						JSONObject json = thread.getJSONObject();
						try {
							String code  = json.getString("code");
							if(code.equals("00000")){
								//onResume();
								removeall();
								buildall();
							}else{
								Toast.makeText(getApplicationContext(), json.getString("msg"),
									     Toast.LENGTH_SHORT).show();
							}
						} catch (JSONException e) {
						// TODO 自动生成的 catch 块
							e.printStackTrace();
						}
						break;
					case 2:
						Toast.makeText(getApplicationContext(), "连接超时，请重试。",
							     Toast.LENGTH_SHORT).show();
						break;
					default:
						break;
				}
			}
		};
        thread= new NetworkThread(url, nameValuePairs,handler);
        thread.start();
	}	
	
	private void updateImg(){
		//locationid propertyid number latitude longitude status
		Toast.makeText(getApplicationContext(),"请求已发送。",
			     Toast.LENGTH_SHORT).show();
		List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);

		nameValuePairs.add(new BasicNameValuePair("data",img.toString() ));
		nameValuePairs.add(new BasicNameValuePair("userId",User.getId() ));
		nameValuePairs.add(new BasicNameValuePair("userTrueName",User.getName() ));
		nameValuePairs.add(new BasicNameValuePair("projectId",PROJECTID ));
	
		
	
		
		String url = ProURL.url+"location.do?method=update";
		Handler handler = new Handler(){
			@Override
			public void handleMessage(Message msg) {

				switch(msg.what){
					case 1:
						
						
						JSONObject json = thread.getJSONObject();
						try {
							String code  = json.getString("code");
							if(code.equals("00000")){
								onResume();
							}
						}catch (JSONException e) {
								// TODO 自动生成的 catch 块
								e.printStackTrace();
							}
						break;
					case 2:
						Toast.makeText(getApplicationContext(), "连接超时，请重试。",
							     Toast.LENGTH_SHORT).show();
						break;
					default:
						break;
				}
			}
		};
        thread= new NetworkThread(url, nameValuePairs,handler);
        thread.start();
	}	
	
	
	
	
	private void getLog(){
		List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);

		nameValuePairs.add(new BasicNameValuePair("projectId",PROJECTID ));
		nameValuePairs.add(new BasicNameValuePair("offset",String.valueOf(off) ));
		nameValuePairs.add(new BasicNameValuePair("limit",String.valueOf(lim) ));
		off+=20;
	
		
		String url = ProURL.url+"log.do?method=getbyproject";
		Handler handler = new Handler(){
			@Override
			public void handleMessage(Message msg) {

				switch(msg.what){
					case 1:
						
						
						JSONObject json = thread.getJSONObject();
						try {
							String code  = json.getString("code");
							if(code.equals("00000")){
								String data = json.getString("data");
								JSONObject da = new JSONObject(data);
								String log = da.getString("Logs");
								JSONArray logs = new JSONArray(log);
								for(int i=0;i<logs.length();i++){
									JSONObject L = logs.getJSONObject(i);
									Date d = new Date(L.getString("date"));
									
								
									int h = d.getHours();
									int m =d.getMinutes();
									int s =d.getSeconds();
							
									DateFormat df1 = DateFormat.getDateInstance();//日期格式，精确到日
									String year = df1.format(d);
									
//									int y = d.getYear();
//									int mo = d.getMonth();
//									int day = d.getDay();
//									
//									String year =y+"/"+mo+"/"+day;
									
								
									
									
									
									String hour="";
									String min="";
									String sec = "";
									if(h<10)
										 hour ="0"+String.valueOf(h);
									else
										 hour =String.valueOf(h);
									if(m<10)
										 min ="0"+String.valueOf(m);
									else
										 min =String.valueOf(m);
									if(s<10)
										 sec ="0"+String.valueOf(s);
									else
										 sec =String.valueOf(s);
									
									
									String date =year+"\n"+hour+":"+min+":"+sec;
									String info = L.getString("logString");
									buildLogView(date, info);
								}
								buildLogButton();
								
								
								
							}else{
								Toast.makeText(getApplicationContext(), json.getString("msg"),
									     Toast.LENGTH_SHORT).show();
							}
						}catch (JSONException e) {
								// TODO 自动生成的 catch 块
								e.printStackTrace();
							}
						break;
					case 2:
						Toast.makeText(getApplicationContext(), "连接超时，请重试。",
							     Toast.LENGTH_SHORT).show();
						break;
					default:
						break;
				}
			}
		};
        thread= new NetworkThread(url, nameValuePairs,handler);
        thread.start();
		
	}
	
public void buildLogView(String time,String info){
		
		LinearLayout view = new LinearLayout(LDialog.getContext());
		
		//RelativeLayout.LayoutParams lp1;
		//lp1=  (LayoutParams) view.getLayoutParams();
	//	RelativeLayout.LayoutParams father = (LayoutParams) additem.getParent();
		LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		lp1.width = ViewGroup.LayoutParams.FILL_PARENT;//father.width;

		view.setLayoutParams(lp1);
		
		TextView logTime = new TextView(LDialog.getContext());
		logTime.setText("  "+time+"  ");
		logTime.setTextSize(15);
		logTime.setGravity(Gravity.CENTER);
		logTime.setSingleLine(false);
		//itemname.setBackgroundColor(android.graphics.Color.parseColor("#ffffff"));
		//RelativeLayout.LayoutParams lp2;
		//lp2 = (LayoutParams) itemname.getLayoutParams();;
		LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.FILL_PARENT);
		//lp2.height=35;
		//lp2.width=50;
	

		logTime.setLayoutParams(lp2);
		
		TextView logInfo = new TextView(LDialog.getContext());
		
		logInfo.setText("\n"+"    "+info+"\n");
		logInfo.setTextSize(15);
		logInfo.setSingleLine(false);
		
		LinearLayout.LayoutParams lp3 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		logInfo.setLayoutParams(lp3);
		
		view.addView(logTime,lp2);
		view.addView(logInfo,lp3);
		
		
		LG.addView(view,lp1);
		
		
	}

@SuppressWarnings("deprecation")
public void buildLogButton(){
	
	RelativeLayout view = new RelativeLayout(LDialog.getContext());
	
	//RelativeLayout.LayoutParams lp1;
	//lp1=  (LayoutParams) view.getLayoutParams();
//	RelativeLayout.LayoutParams father = (LayoutParams) additem.getParent();
	RelativeLayout.LayoutParams lp1 = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
	lp1.width = ViewGroup.LayoutParams.FILL_PARENT;//father.width;

	view.setLayoutParams(lp1);
	
	RelativeLayout view2 = new RelativeLayout(LDialog.getContext());
	RelativeLayout.LayoutParams lp2 = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.FILL_PARENT);
	
	
	Button JZ = new Button(LDialog.getContext());
	JZ.setText("查看更多");
	JZ.setBackgroundDrawable(getResources().getDrawable(R.drawable.buttonback));
	JZ.setGravity(Gravity.CENTER);
	JZ.setTextSize(20);
	JZ.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View arg0) {
			// TODO 自动生成的方法存根
			switch (logType) {
			case 0:
				removeButton();
				getLog();
				break;
			case 1:
				removeButton();
				getLogU();
				break;

			default:
				break;
			}
			
		}
	});
	
	view2.addView(JZ);
	view2.setGravity(Gravity.CENTER);
	view.addView(view2,lp2);

	
	
	LG.addView(view,lp1);
	
	
}


	private void ChangeContract(String id,String htc,String namec,String bzc){
		Toast.makeText(getApplicationContext(),"请求已发送。",
			     Toast.LENGTH_SHORT).show();
		List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
		nameValuePairs.add(new BasicNameValuePair("userId", User.getId()));
		nameValuePairs.add(new BasicNameValuePair("userTrueName",User.getName()));
		nameValuePairs.add(new BasicNameValuePair("contractId",id));
		nameValuePairs.add(new BasicNameValuePair("projectId",PROJECTID));
		nameValuePairs.add(new BasicNameValuePair("contractCompany",namec));
		nameValuePairs.add(new BasicNameValuePair("contractRemark",bzc));
		nameValuePairs.add(new BasicNameValuePair("contractNo",htc));
		String url = ProURL.url+"contract.do?method=update";
		Handler handler = new Handler(){
		@SuppressWarnings("deprecation")
		@Override
		public void handleMessage(Message msg) {

			switch(msg.what){
				case 1:
					JSONObject json = thread.getJSONObject();
					try {
						String code  = json.getString("code");
						if(code.equals("00000")){
							//onResume();
							removeall();
							buildall();
							info02.setVisibility(View.VISIBLE);
							info01C.setVisibility(View.GONE);
						}else{
							Toast.makeText(getApplicationContext(), json.getString("msg"),
								     Toast.LENGTH_SHORT).show();
						}
					} catch (JSONException e) {
					// TODO 自动生成的 catch 块
						e.printStackTrace();
					}
					
					break;
				case 2:
					Toast.makeText(getApplicationContext(), "连接超时，请重试。",
						     Toast.LENGTH_SHORT).show();
					break;
				default:
					break;
			}
		}
	};
    thread= new NetworkThread(url, nameValuePairs,handler);
    thread.start();
		
	}

	private void ChangeP(String id,String price,String namec,String bzc,String number,String image){
		Toast.makeText(getApplicationContext(),"请求已发送。",
			     Toast.LENGTH_SHORT).show();
		List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
		nameValuePairs.add(new BasicNameValuePair("userId", User.getId()));
		nameValuePairs.add(new BasicNameValuePair("userTrueName",User.getName()));
		nameValuePairs.add(new BasicNameValuePair("contractId",String.valueOf(contractId)));
		nameValuePairs.add(new BasicNameValuePair("projectId",PROJECTID));
		nameValuePairs.add(new BasicNameValuePair("propertyId",id));
		nameValuePairs.add(new BasicNameValuePair("propertyImg",image));
		nameValuePairs.add(new BasicNameValuePair("propertyTotal",number));
		nameValuePairs.add(new BasicNameValuePair("propertyName",namec));
		nameValuePairs.add(new BasicNameValuePair("propertyPrice",price));
		nameValuePairs.add(new BasicNameValuePair("propertyRemark",bzc));
		
		String url = ProURL.url+"property.do?method=update";
		Handler handler = new Handler(){
		@SuppressWarnings("deprecation")
		@Override
		public void handleMessage(Message msg) {

			switch(msg.what){
				case 1:
					JSONObject json = thread.getJSONObject();
					try {
						String code  = json.getString("code");
						if(code.equals("00000")){
							//onResume();
							removeall();
							buildall();
						}else{
							Toast.makeText(getApplicationContext(), json.getString("msg"),
								     Toast.LENGTH_SHORT).show();
						}
					} catch (JSONException e) {
					// TODO 自动生成的 catch 块
						e.printStackTrace();
					}
					
					break;
				case 2:
					Toast.makeText(getApplicationContext(), "连接超时，请重试。",
						     Toast.LENGTH_SHORT).show();
					break;
				default:
					break;
			}
		}
	};
    thread= new NetworkThread(url, nameValuePairs,handler);
    thread.start();
	}
	
	private void Dpro(String id){
		Toast.makeText(getApplicationContext(),"请求已发送。",
			     Toast.LENGTH_SHORT).show();
		List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
		nameValuePairs.add(new BasicNameValuePair("userId", User.getId()));
		nameValuePairs.add(new BasicNameValuePair("userTrueName",User.getName()));
		nameValuePairs.add(new BasicNameValuePair("contractId",String.valueOf(contractId)));
		nameValuePairs.add(new BasicNameValuePair("projectId",PROJECTID));
		nameValuePairs.add(new BasicNameValuePair("propertyId",id));
		
		
		String url = ProURL.url+"property.do?method=delete";
		Handler handler = new Handler(){
		@SuppressWarnings("deprecation")
		@Override
		public void handleMessage(Message msg) {

			switch(msg.what){
				case 1:
					JSONObject json = thread.getJSONObject();
					try {
						String code  = json.getString("code");
						if(code.equals("00000")){
							//onResume();
							removeall();
							buildall();
						}else{
							Toast.makeText(getApplicationContext(), json.getString("msg"),
								     Toast.LENGTH_SHORT).show();
						}
					} catch (JSONException e) {
					// TODO 自动生成的 catch 块
						e.printStackTrace();
					}
					
					break;
				case 2:
					Toast.makeText(getApplicationContext(), "连接超时，请重试。",
						     Toast.LENGTH_SHORT).show();
					break;
				default:
					break;
			}
		}
	};
    thread= new NetworkThread(url, nameValuePairs,handler);
    thread.start();
	}
	
	private void updateCL(){
		Toast.makeText(getApplicationContext(),"请求已发送。",
			     Toast.LENGTH_SHORT).show();
		List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
		nameValuePairs.add(new BasicNameValuePair("userId", User.getId()));
		nameValuePairs.add(new BasicNameValuePair("userTrueName",User.getName()));
		nameValuePairs.add(new BasicNameValuePair("contractId",String.valueOf(contractId)));
		nameValuePairs.add(new BasicNameValuePair("projectId",PROJECTID));
		nameValuePairs.add(new BasicNameValuePair("propertyId",String.valueOf(fatherid)));
		nameValuePairs.add(new BasicNameValuePair("locationCostNumber",CLinfoUser.getText().toString()));
		nameValuePairs.add(new BasicNameValuePair("locationRemark",CLinfoBZ.getText().toString()));
		
		
		String url = ProURL.url+"location.do?method=updatenum";
		Handler handler = new Handler(){
		@SuppressWarnings("deprecation")
		@Override
		public void handleMessage(Message msg) {

			switch(msg.what){
				case 1:
					JSONObject json = thread.getJSONObject();
					try {
						String code  = json.getString("code");
						if(code.equals("00000")){
							//onResume();
							removeall();
							buildall();
						}else{
							Toast.makeText(getApplicationContext(), json.getString("msg"),
								     Toast.LENGTH_SHORT).show();
						}
					} catch (JSONException e) {
					// TODO 自动生成的 catch 块
						e.printStackTrace();
					}
					
					break;
				case 2:
					Toast.makeText(getApplicationContext(), "连接超时，请重试。",
						     Toast.LENGTH_SHORT).show();
					break;
				default:
					break;
			}
		}
	};
   thread= new NetworkThread(url, nameValuePairs,handler);
   thread.start();
	}
	
	
	private void deteleL(int locationid,int propertyid){
		Toast.makeText(getApplicationContext(),"请求已发送。",
			     Toast.LENGTH_SHORT).show();
		List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
		nameValuePairs.add(new BasicNameValuePair("userId",User.getId() ));
		nameValuePairs.add(new BasicNameValuePair("userTrueName",User.getName() ));
		nameValuePairs.add(new BasicNameValuePair("projectId",PROJECTID ));
		nameValuePairs.add(new BasicNameValuePair("contractId",String.valueOf(contractId) ));
		nameValuePairs.add(new BasicNameValuePair("locationId",String.valueOf(locationid) ));
		nameValuePairs.add(new BasicNameValuePair("propertyId",String.valueOf(propertyid)));
		String url = ProURL.url+"location.do?method=delete";
		Handler handler = new Handler(){
		@SuppressWarnings("deprecation")
		@Override
		public void handleMessage(Message msg) {

			switch(msg.what){
				case 1:
					JSONObject json = thread.getJSONObject();
					try {
						String code  = json.getString("code");
						if(code.equals("00000")){
							//onResume();
							removeall();
							buildall();
						}else{
							Toast.makeText(getApplicationContext(), json.getString("msg"),
								     Toast.LENGTH_SHORT).show();
						}
					} catch (JSONException e) {
					// TODO 自动生成的 catch 块
						e.printStackTrace();
					}
					
					break;
				case 2:
					Toast.makeText(getApplicationContext(), "连接超时，请重试。",
						     Toast.LENGTH_SHORT).show();
					break;
				default:
					break;
			}
		}
	};
    thread= new NetworkThread(url, nameValuePairs,handler);
    thread.start();
		
	}
	
	
	
	private void updateQT(){
		Toast.makeText(getApplicationContext(),"请求已发送。",
			     Toast.LENGTH_SHORT).show();
		List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
		nameValuePairs.add(new BasicNameValuePair("userId", User.getId()));
		nameValuePairs.add(new BasicNameValuePair("userTrueName",User.getName()));
		nameValuePairs.add(new BasicNameValuePair("contractId",String.valueOf(contractId)));
		nameValuePairs.add(new BasicNameValuePair("projectId",PROJECTID));
		nameValuePairs.add(new BasicNameValuePair("propertyId",String.valueOf(fatherid)));
		nameValuePairs.add(new BasicNameValuePair("locationCostNumber",QTinfoPrice.getText().toString()));
		nameValuePairs.add(new BasicNameValuePair("locationRemark",QTinfoBZ.getText().toString()));
		
		
		String url = ProURL.url+"location.do?method=updatenum";
		Handler handler = new Handler(){
		@SuppressWarnings("deprecation")
		@Override
		public void handleMessage(Message msg) {

			switch(msg.what){
				case 1:
					JSONObject json = thread.getJSONObject();
					try {
						String code  = json.getString("code");
						if(code.equals("00000")){
							//onResume();
							removeall();
							buildall();
						}else{
							Toast.makeText(getApplicationContext(), json.getString("msg"),
								     Toast.LENGTH_SHORT).show();
						}
					} catch (JSONException e) {
					// TODO 自动生成的 catch 块
						e.printStackTrace();
					}
					
					break;
				case 2:
					Toast.makeText(getApplicationContext(), "连接超时，请重试。",
						     Toast.LENGTH_SHORT).show();
					break;
				default:
					break;
			}
		}
	};
   thread= new NetworkThread(url, nameValuePairs,handler);
   thread.start();
	}
	
	private void removeButton() {
        //获取linearlayout子view的个数
        int count = LG.getChildCount();
        
            LG.removeViewAt(count-1);
            LG.invalidate();
            RelativeLayout view = new RelativeLayout(LDialog.getContext());
        	
       
        	RelativeLayout.LayoutParams lp1 = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        	lp1.width = ViewGroup.LayoutParams.FILL_PARENT;
        	lp1.height = 40;
        	view.setLayoutParams(lp1);
        	view.setBackgroundColor(Color.parseColor("#FF7F50"));
        	LG.addView(view);


      
        
    }
	
	private void removeLG() {
        //获取linearlayout子view的个数
        int count = LG.getChildCount();
        
        for(int i=0;i<count;i++){
            LG.removeViewAt(0);
          }
        
        LG.invalidate();
        off = 0;
            


      
        
    }
	
	
	private void getLogU(){
		List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);

		nameValuePairs.add(new BasicNameValuePair("projectId",PROJECTID ));
		nameValuePairs.add(new BasicNameValuePair("offset",String.valueOf(off) ));
		nameValuePairs.add(new BasicNameValuePair("limit",String.valueOf(lim) ));
		nameValuePairs.add(new BasicNameValuePair("userId",User.getId() ));
		off+=20;
	
		
		String url = ProURL.url+"log.do?method=getutp";
		Handler handler = new Handler(){
			@Override
			public void handleMessage(Message msg) {

				switch(msg.what){
					case 1:
						
						
						JSONObject json = thread.getJSONObject();
						try {
							String code  = json.getString("code");
							if(code.equals("00000")){
								String data = json.getString("data");
								JSONObject da = new JSONObject(data);
								String log = da.getString("Logs");
								JSONArray logs = new JSONArray(log);
								for(int i=0;i<logs.length();i++){
									JSONObject L = logs.getJSONObject(i);
									Date d = new Date(L.getString("date"));
									
								
									int h = d.getHours();
									int m =d.getMinutes();
									int s =d.getSeconds();
							
									DateFormat df1 = DateFormat.getDateInstance();//日期格式，精确到日
									String year = df1.format(d);
									
//									int y = d.getYear();
//									int mo = d.getMonth();
//									int day = d.getDay();
//									
//									String year =y+"/"+mo+"/"+day;
									
								
									
									
									
									String hour="";
									String min="";
									String sec = "";
									if(h<10)
										 hour ="0"+String.valueOf(h);
									else
										 hour =String.valueOf(h);
									if(m<10)
										 min ="0"+String.valueOf(m);
									else
										 min =String.valueOf(m);
									if(s<10)
										 sec ="0"+String.valueOf(s);
									else
										 sec =String.valueOf(s);
									
									
									String date =year+"\n"+hour+":"+min+":"+sec;
									String info = L.getString("logString");
									buildLogView(date, info);
								}
								buildLogButton();
								
								
								
							}else{
								Toast.makeText(getApplicationContext(), json.getString("msg"),
									     Toast.LENGTH_SHORT).show();
							}
						}catch (JSONException e) {
								// TODO 自动生成的 catch 块
								e.printStackTrace();
							}
						break;
					case 2:
						Toast.makeText(getApplicationContext(), "连接超时，请重试。",
							     Toast.LENGTH_SHORT).show();
						break;
					default:
						break;
				}
			}
		};
        thread= new NetworkThread(url, nameValuePairs,handler);
        thread.start();
		
	}
	
	private void buildall(){
		
		 Subkey = new JSONObject();
		 img  = new JSONArray();
		
		
		 allcost=allJX=allGR=allCL=allQT=0;
		 Tcost=TJX=TGR=TCL=TQT=0;
		 addJX=addGR=0;
		
		 off =0;
		 lim=20;
		top++;
		JX=GR=CL=QT=ADD=1;
		
		Intent intent = getIntent();
		PROJECTID = intent.getStringExtra("PROJECTID");
		List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
	
		nameValuePairs.add(new BasicNameValuePair("projectId", PROJECTID));
		String url = ProURL.url+"project.do?method=load";
		Handler handler = new Handler(){
						@Override
				public void handleMessage(Message msg) {

					switch(msg.what){
						case 1:
							JSONObject Json = thread.getJSONObject();
							try {
								String code  = Json.getString("code");
								if(code.equals("00000")){
									String data = Json.getString("data");//"{\"id\":1,\"constracts\":{\"machine\":[{\"id\":3,\"no\":0,\"type\":\"machine\",\"project\":1,\"company\":\"this\",\"remark\":\"1234\",\"propertys\":[]}],\"people\":[{\"id\":2,\"no\":0,\"type\":\"people\",\"project\":1,\"company\":\"company2\",\"remark\":\"fuck\",\"propertys\":[]},{\"id\":1,\"no\":0,\"type\":\"material\",\"project\":1,\"company\":\"company1\",\"remark\":\"什么什么公司\",\"propertys\":[{\"id\":2,\"type\":\"2\",\"img\":\"2\",\"name\":\"2\",\"total\":2,\"price\":2.0,\"constract\":1,\"locations\":[]},{\"id\":3,\"type\":\"meterial\",\"img\":\"img\",\"name\":\"name\",\"total\":1,\"price\":2.2,\"constract\":1,\"locations\":[]},{\"id\":1,\"type\":\"1\",\"img\":\"1\",\"name\":\"1\",\"total\":1,\"price\":1.0,\"constract\":1,\"locations\":[{\"id\":2,\"property\":1,\"number\":2,\"latitude\":2.0,\"longitude\":2.0,\"status\":0},{\"id\":1,\"property\":1,\"number\":1,\"latitude\":1.0,\"longitude\":1.0,\"status\":0}]}]}]},\"name\":\"工程1\",\"date\":\"Nov 18, 2015 2:11:04 PM\",\"creator\":1}";//null;//json.getString("data");
									//thread.stop();
									JSONObject pro = new JSONObject(data);
									
									CREATOR = pro.getString("creator");
									Manager = CREATOR.equals(User.getId());
									
									topInfo.setText("用户名："+User.getName());
									topPro.setText("工程名："+pro.getString("name"));
									
									String totalCost = pro.getString("totalCost");
									JSONObject tc =new JSONObject(totalCost);
									allJX =Float.valueOf(tc.getString("machineCost")); 
									allGR =Float.valueOf(tc.getString("peopleCost")); 
									allCL =Float.valueOf(tc.getString("materialCost")); 
									allQT =Float.valueOf(tc.getString("otherCost")); 
								
									String logs = pro.getString("logs");
									
									
									JSONArray Logs =new JSONArray(logs);
									infoTextView1.setText("");
									infoTextView2.setText("");
									infoTextView3.setText("");
									switch (Logs.length()) {
									case 0:
									
										break;
									case 1:
										for(int i=0;i<1;i++){
											JSONObject log = Logs.getJSONObject(i);
											Date d = new Date(log.getString("date"));
											int h = d.getHours();
											int m =d.getMinutes();
											String hour="";
											String min="";
											if(h<10)
												 hour ="0"+String.valueOf(h);
											else
												 hour =String.valueOf(h);
											if(m<10)
												 min ="0"+String.valueOf(m);
											else
												 min =String.valueOf(m);
											
											String date =hour+":"+min;
											
											String info = log.getString("logString");
											if(i==0){
												infoTextView1.setText(date+"  "+info);
												Toast.makeText(getApplicationContext(),date+"  "+info,
													     Toast.LENGTH_SHORT).show();
											}
											if(i==1)
												infoTextView2.setText(date+"  "+info);
											if(i==2)
												infoTextView3.setText(date+"  "+info);
											
											
										}
										break;
									case 2:
										for(int i=0;i<2;i++){
											JSONObject log = Logs.getJSONObject(i);
											Date d = new Date(log.getString("date"));
											int h = d.getHours();
											int m =d.getMinutes();
											String hour="";
											String min="";
											if(h<10)
												 hour ="0"+String.valueOf(h);
											else
												 hour =String.valueOf(h);
											if(m<10)
												 min ="0"+String.valueOf(m);
											else
												 min =String.valueOf(m);
											
											String date =hour+":"+min;
											
											String info = log.getString("logString");
											if(i==0){
												infoTextView1.setText(date+"  "+info);
												Toast.makeText(getApplicationContext(),date+"  "+info,
													     Toast.LENGTH_SHORT).show();
											}
											if(i==1)
												infoTextView2.setText(date+"  "+info);
											if(i==2)
												infoTextView3.setText(date+"  "+info);
											
										}
										break;

									default:
										for(int i=0;i<3;i++){
											JSONObject log = Logs.getJSONObject(i);
											Date d = new Date(log.getString("date"));
											int h = d.getHours();
											int m =d.getMinutes();
											String hour="";
											String min="";
											if(h<10)
												 hour ="0"+String.valueOf(h);
											else
												 hour =String.valueOf(h);
											if(m<10)
												 min ="0"+String.valueOf(m);
											else
												 min =String.valueOf(m);
											
											String date =hour+":"+min;
											
											String info = log.getString("logString");
											if(i==0){
												infoTextView1.setText(date+"  "+info);
												Toast.makeText(getApplicationContext(),date+"  "+info,
													     Toast.LENGTH_SHORT).show();
											}
											if(i==1)
												infoTextView2.setText(date+"  "+info);
											if(i==2)
												infoTextView3.setText(date+"  "+info);
											
										}
										break;
									}
									
									
									
									json = pro.getString("img");
									 view = (ShowView) first.findViewById(R.id.SD_view);
									 view.invalidate();
									 //StopJZ();
									String Constract = pro.getString("contracts");
									JSONObject Ctr = new JSONObject(Constract);
									String machine = Ctr.getString("machine");
									JSONArray MHE = new JSONArray(machine);
									for(int i=0;i<MHE.length();i++){
										JSONObject pts = new JSONObject(MHE.getString(i));
										String id = pts.getString("id");
										String no = pts.getString("no");
										String company = pts.getString("company")+"  ";
										String remark = pts.getString("remark");
										String subkey = pts.getString("propertys");
										Subkey.put(id, subkey);
										buildView("1", id, no, company, remark);
										if(subkey!=null){
											JSONArray PTY = new JSONArray(subkey);
											for(int j=0;j<PTY.length();j++){
												JSONObject pty = new JSONObject(PTY.getString(j));
												String locations = pty.getString("locations");
												String name = pty.getString("name");
												String price = pty.getString("price");
												String remark2 = pty.getString("remark");
												
												if(locations!=null){
													JSONArray LTS = new JSONArray(locations);
													for(int k=0;k<LTS.length();k++){
														JSONObject lts = new JSONObject(LTS.getString(k));
														String cost  = lts.getString("cost");
														
														Date t = new Date(lts.getString("date"));
														Date curDate = new Date(System.currentTimeMillis());
														int prt = lts.getInt("property");
														int Iid = lts.getInt("id");
														int x1 = lts.getInt("longitude");
														int y1 = lts.getInt("latitude");
														int status =lts.getInt("status");
														int number = lts.getInt("number");
														Calendar todayStart = Calendar.getInstance();  
												        todayStart.set(Calendar.HOUR_OF_DAY, 0);  
												        todayStart.set(Calendar.MINUTE, 0);  
												        todayStart.set(Calendar.SECOND, 0);  
												        todayStart.set(Calendar.MILLISECOND, 0);  
												        long todayStartTime = todayStart.getTime().getTime();
												        if(t.getTime()>todayStart.getTime().getTime())
												        	TJX += Float.valueOf(cost);
														if(status==1){
															addJX += Float.valueOf(price)*number/3600;
															
													        float time = curDate.getTime()-t.getTime();
													        allJX +=time/1000/60/60 * Float.valueOf(price);
													        if(t.getTime()>=todayStartTime){
													        	TJX+=time/1000/60/60 * Float.valueOf(price);
													        }else{
													        	TJX+=(curDate.getTime()-todayStartTime)/1000/60/60 * Float.valueOf(price);
													        }

														}
														buildImageView(Integer.parseInt(id),prt,Iid, x1, y1, "1", status,number,name,price,remark2,pty.getString("img"));
														
													}
												}
											}
										}
											
									}
									
									
									
									String people = Ctr.getString("people");
									JSONArray PEO = new JSONArray(people);
									for(int i=0;i<PEO.length();i++){
										JSONObject pts = new JSONObject(PEO.getString(i));
										String id = pts.getString("id");
										String company = pts.getString("company")+"  ";
										String remark = pts.getString("remark");
										String subkey = pts.getString("propertys");
										String no = pts.getString("no");
										Subkey.put(id, subkey);
										buildView("2", id, no, company, remark);
										
										if(subkey!=null){
											JSONArray PTY = new JSONArray(subkey);
											for(int j=0;j<PTY.length();j++){
												JSONObject pty = new JSONObject(PTY.getString(j));
												String locations = pty.getString("locations");
												String name = pty.getString("name");
												String price = pty.getString("price");
												
												if(locations!=null){
													JSONArray LTS = new JSONArray(locations);
													for(int k=0;k<LTS.length();k++){
														JSONObject lts = new JSONObject(LTS.getString(k));
														
														String cost  = lts.getString("cost");
														
														Date t = new Date(lts.getString("date"));
														Date curDate = new Date(System.currentTimeMillis());
														int prt = lts.getInt("property");
														int Iid = lts.getInt("id");
														int x1 = lts.getInt("longitude");
														int y1 = lts.getInt("latitude");
														int status =lts.getInt("status");
														int number = lts.getInt("number");
														Calendar todayStart = Calendar.getInstance();  
												        todayStart.set(Calendar.HOUR_OF_DAY, 0);  
												        todayStart.set(Calendar.MINUTE, 0);  
												        todayStart.set(Calendar.SECOND, 0);  
												        todayStart.set(Calendar.MILLISECOND, 0);  
												        long todayStartTime = todayStart.getTime().getTime();
												        if(t.getTime()>todayStart.getTime().getTime())
												        	TGR += Float.valueOf(cost);
														if(status==1){
															addGR += Float.valueOf(price)*number/3600;
													        float time = curDate.getTime()-t.getTime();
													        allGR +=time/1000/60/60 * Float.valueOf(price)*number;
													        if(t.getTime()>=todayStartTime){
													        	TGR+=time/1000/60/60 * Float.valueOf(price)*number;
													        }else{
													        	TGR+=(curDate.getTime()-todayStartTime)/1000/60/60 * Float.valueOf(price)*number;
													        }

														}
														buildImageView(Integer.parseInt(id),prt,Iid, x1, y1, "2", status,number,name,price,lts.getString("remark"),"");
														
													}
												}
											}
										}
											
									}
									
									String material = Ctr.getString("material");
									JSONArray MRL = new JSONArray(material);
									for(int i=0;i<MRL.length();i++){
										JSONObject pts = new JSONObject(MRL.getString(i));
										String id = pts.getString("id");
										String company = pts.getString("company")+"  ";
										String remark = pts.getString("remark");
										String subkey = pts.getString("propertys");
										String no = pts.getString("no");
										Subkey.put(id, subkey);
										buildView("3", id, no, company, remark);
										if(subkey!=null){
											JSONArray PTY = new JSONArray(subkey);
											for(int j=0;j<PTY.length();j++){
												JSONObject pty = new JSONObject(PTY.getString(j));
												String locations = pty.getString("locations");
												String name = pty.getString("name");
												String price = pty.getString("price");
												JSONArray LC = new JSONArray(locations);
												JSONObject lc = LC.getJSONObject(0);
												Date d = new Date(lc.getString("date"));
												Calendar todayStart = Calendar.getInstance();  
										        todayStart.set(Calendar.HOUR_OF_DAY, 0);  
										        todayStart.set(Calendar.MINUTE, 0);  
										        todayStart.set(Calendar.SECOND, 0);  
										        todayStart.set(Calendar.MILLISECOND, 0);  
										        long todayStartTime = todayStart.getTime().getTime();
												if(d.getTime()>todayStartTime){
													float C =Float.valueOf(lc.getString("cost"));
													TCL+=C;
												}
											}
										}
											
									}
									
									String other = Ctr.getString("other");
									JSONArray OTR = new JSONArray(other);
									for(int i=0;i<OTR.length();i++){
										JSONObject pts = new JSONObject(OTR.getString(i));
										String id = pts.getString("id");
										String company = pts.getString("company")+"  ";
										String remark = pts.getString("remark");
										String subkey = pts.getString("propertys");
										String no = pts.getString("no");
										Subkey.put(id, subkey);
										buildView("4", id, no, company, remark);
										if(subkey!=null){
											JSONArray PTY = new JSONArray(subkey);
											for(int j=0;j<PTY.length();j++){
												JSONObject pty = new JSONObject(PTY.getString(j));
												String locations = pty.getString("locations");
												String name = pty.getString("name");
												String price = pty.getString("price");
												JSONArray LC = new JSONArray(locations);
												JSONObject lc = LC.getJSONObject(0);
												Date d = new Date(lc.getString("date"));
												Calendar todayStart = Calendar.getInstance();  
										        todayStart.set(Calendar.HOUR_OF_DAY, 0);  
										        todayStart.set(Calendar.MINUTE, 0);  
										        todayStart.set(Calendar.SECOND, 0);  
										        todayStart.set(Calendar.MILLISECOND, 0);  
										        long todayStartTime = todayStart.getTime().getTime();
												if(d.getTime()>todayStartTime){
													float C =Float.valueOf(lc.getString("cost"));
													TQT+=C;
												}
											}
										}
											
									}
									
									allcost = allJX+allGR+allCL+allQT;
									Tcost = TJX+TGR+TCL+TQT;
									all.setText("总成本="+allcost+"=机械("+allJX+")+人工("+allGR+")+材料("+allCL+")+其他("+allQT+")");
									today.setText("当日成本="+Tcost+"=机械("+TJX+")+人工("+TGR+")+材料("+TCL+")+其他("+TQT+")");
									
									StopJZ();
									removeLG();
									 getLog();
									 f5running = true;
									
											timer.schedule(task, 1000,1000);
									 }else{
											Toast.makeText(getApplicationContext(), Json.getString("msg"),
												     Toast.LENGTH_SHORT).show();
										}
									 
									
//									TimerTask task = new TimerTask(){   
//
//										@Override
//										public void run() {
//										
//											allJX+=addJX;
//											TJX+=addJX;
//											allGR+=addGR;
//											TGR+=addGR;
//											allcost = allJX+allGR+allCL+allQT;
//											Tcost = TJX+TGR+TCL+TQT;
//											all.setText("总成本="+allcost+"=机械("+allJX+")+人工("+allGR+")+材料("+allCL+")+其他("+allQT+")");
//											today.setText("当日成本="+Tcost+"=机械("+TJX+")+人工("+TGR+")+材料("+TCL+")+其他("+TQT+")");
//											
//										}
//								    	
//									};
//									Timer timer = new Timer(); 
//
//									timer.schedule(task, 1000); 
//									

							}catch(Exception e){
								
								e.printStackTrace();
	
						}	
								
								
							break;
						case 2:
							Toast.makeText(getApplicationContext(), "连接超时，请重试。",
								     Toast.LENGTH_SHORT).show();
							break;
						default:
							break;
							}
				}
		};
      thread= new NetworkThread(url, nameValuePairs,handler);
      thread.start();
     
	}
	
	private void removeall(){
		 int count = addv.getChildCount();
	        for (int i=2;i<count; i++) {
	            //用来判断当前linearlayout子view数多于2个，即还有我们点add增加的button
	            addv.removeViewAt(2);
	        }
			count = JXRL.getChildCount();
		        for (int i=0;i<count; i++) {
		            //用来判断当前linearlayout子view数多于2个，即还有我们点add增加的button
		            JXRL.removeViewAt(0);
		        }
				 count = GRRL.getChildCount();
			        for (int i=0;i<count; i++) {
			            //用来判断当前linearlayout子view数多于2个，即还有我们点add增加的button
			            GRRL.removeViewAt(0);
			        }
					count = CLRL.getChildCount();
				        for (int i=0;i<count; i++) {
				            //用来判断当前linearlayout子view数多于2个，即还有我们点add增加的button
				            CLRL.removeViewAt(0);
				        }
						count = QTRL.getChildCount();
					        for (int i=0;i<count; i++) {
					            //用来判断当前linearlayout子view数多于2个，即还有我们点add增加的button
					            QTRL.removeViewAt(0);
					        }
				removeView();
		
	}
	
	
}
