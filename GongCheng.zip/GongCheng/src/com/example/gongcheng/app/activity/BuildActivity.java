package com.example.gongcheng.app.activity;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


import com.example.gongcheng.R;
import com.example.gongcheng.draw.*;
import com.example.gongcheng.app.entity.User;
import com.example.gongcheng.app.thread.NetworkThread;
import com.example.gongcheng.app.ui.ProURL;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class BuildActivity extends Activity implements OnClickListener{

	private Button queding;
	private Button quxiao;
	private Button chongzhi;
	private EditText xiangmu;
	private NetworkThread thread;

	public DrawView view;
	public static JSONArray jarray; 
	
	private String xiangmuView;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.new_project);
		initView();
		initEvent();
		

	}
	
	public void initView(){
		queding=(Button) findViewById(R.id.XJ_button_queding);
		quxiao=(Button) findViewById(R.id.XJ_button_quxiao);
		chongzhi = (Button) findViewById(R.id.XJ_button_chongzhi);
		xiangmu = (EditText) findViewById(R.id.XJ_edittext_xiangmuming);
		view = (DrawView) findViewById(R.id.XJ_RLayout);
		jarray = new JSONArray();

	}
	
	public void initEvent(){
		queding.setOnClickListener(this);
		quxiao.setOnClickListener(this);
		chongzhi.setOnClickListener(this);
	}
	
	@Override
	public void onClick(View v) {
		// TODO �Զ����ɵķ������
		switch(v.getId()){
		case R.id.XJ_button_quxiao:
	
			BuildActivity.this.finish();
				
			break;
			
		case R.id.XJ_button_queding:
			
//			Intent intent = new Intent();
//			intent.putExtra("json", jarray.toString());
//			intent.setClass(BuildActivity.this, MainActivity.class);
//			startActivity(intent);
			
			xiangmuView = xiangmu.getText().toString();
			
					List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
					nameValuePairs.add(new BasicNameValuePair("userId",User.getId() ));
					nameValuePairs.add(new BasicNameValuePair("projcetName",xiangmuView ));
					nameValuePairs.add(new BasicNameValuePair("projectImg", jarray.toString()));
					String url = ProURL.url+"project.do?method=create";
					Handler handler = new Handler(){
						@Override
						public void handleMessage(Message msg) {

							switch(msg.what){
								case 1:
									JSONObject json = thread.getJSONObject();
								String code;
								try {
									code = json.getString("code");
									if(code.equals("00000")){
										Intent intent = new Intent();
										//intent.putExtra("json", jarray.toString());
										intent.setClass(BuildActivity.this, ProjectActivity.class);
										startActivity(intent);
									}else{
										Toast.makeText(getApplicationContext(), json.getString("msg"),
											     Toast.LENGTH_SHORT).show();
									}
								} catch (JSONException e) {
									// TODO 自动生成的 catch 块
									e.printStackTrace();
								}
									
									break;
								case 2:
									Toast.makeText(getApplicationContext(), "连接超时，请重试。",
										     Toast.LENGTH_SHORT).show();
									break;
								default:
									break;
							}
						}
					};
		            thread= new NetworkThread(url, nameValuePairs,handler);
		            thread.start();

			
			break;
			
		case R.id.XJ_button_chongzhi:
			jarray=new JSONArray();
			view.clear();
			break;
		}	
					
		
	}
	
	

	
}
