package com.example.gongcheng.app.activity;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import com.example.gongcheng.R;

import com.example.gongcheng.app.entity.User;
import com.example.gongcheng.app.thread.NetworkThread;
import com.example.gongcheng.app.ui.ProURL;

import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Build;

public class LoginActivity extends Activity implements OnClickListener{

	private Button denglu;
	
	static EditText zhanghao;
	static EditText mima;	
	private NetworkThread thread;

	private String userNameValue,passwordValue;
	private RelativeLayout Rlayout;
	private int staus = 1; 
	private static final int STOPSPLASH = 0; 
	//time in milliseconds 
	private static final long SPLASHTIME = 8000; 
	
	private Animation myAnimation_Alpha; 
	private Animation animatinoGone ; 
	
	private Handler splashHandler = new Handler() { 
	    public void handleMessage(Message msg) { 
	         switch (msg.what) { 
	         case STOPSPLASH: 
	              if( staus == 1 ){                
	
	          		
	          		
	            	  Rlayout.setVisibility(View.GONE); 
	              } 
	              sendEmptyMessageDelayed(STOPSPLASH, SPLASHTIME); 
	              break;
	         case 3000:
	        		if(!userNameValue.equals("")){
	                    
	          			
	        			Toast.makeText(getApplicationContext(), "登陆请求已发送。",
	        				     Toast.LENGTH_SHORT).show();
	          			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
	          			nameValuePairs.add(new BasicNameValuePair("userName", userNameValue));
	          			nameValuePairs.add(new BasicNameValuePair("userPassword", passwordValue));
	          			String url = ProURL.url+"user.do?method=login";
	          			//String url = ProURL.url+"user.do?method=test";
	          			Handler handler = new Handler(){
	          			@SuppressWarnings("deprecation")
	          			@Override
	          			public void handleMessage(Message msg) {

	          				switch(msg.what){
	          					case 1:
	          						JSONObject json = thread.getJSONObject();
	          						try {
	          							String code  = json.getString("code");
	          							if(code.equals("00000")){
	          								String data = json.getString("data");
	          								JSONObject pro = new JSONObject(data);
	          								String user = pro.getString("user");
	          								JSONArray U = new JSONArray(user);
	          								String u = U.getString(0);
	          								JSONObject S = new JSONObject(u);
	          								User.setId(S.getString("id"));
	          								User.setName(S.getString("truename"));
	          								Intent intent = new Intent();
	          								intent.setClass(LoginActivity.this, ProjectActivity.class);
	          								startActivity(intent);
	          							}else{
	          								Toast.makeText(getApplicationContext(), json.getString("msg"),
	          									     Toast.LENGTH_SHORT).show();
	          							}
	          						} catch (JSONException e) {
	          						// TODO 自动生成的 catch 块
	          							e.printStackTrace();
	          						}
	          						
	          						break;
	          					case 2:
	          						Toast.makeText(getApplicationContext(), "连接超时，请重试。",
	          							     Toast.LENGTH_SHORT).show();
	          						break;
	          					default:
	          						break;
	          				}
	          			}
	          		};
	                 thread= new NetworkThread(url, nameValuePairs,handler);
	          	    thread.start();

	        		}
	        	 break;
	             
	         } 
	         super.handleMessage(msg); 
	    } 
	}; 
	
	
	static SharedPreferences sp; 
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.userland);
		sp=this.getSharedPreferences("userInfo",Context.MODE_PRIVATE);
	
		Message msg = new Message(); 
	    msg.what = STOPSPLASH; 
	    splashHandler.sendMessageDelayed(msg, SPLASHTIME);
	    Message msg1 = new Message(); 
	    msg1.what = 3000; 
	    splashHandler.sendMessageDelayed(msg1, 3000);
	    initShare();
		initView();
		initEvent();
		
	//	Rlayout.setVisibility(View.VISIBLE);
		//onRestart();

		
	}
	
//	@Override
//	protected void onResume() {
//		// TODO 自动生成的方法存根
//		super.onResume();
//		try {
//			Thread.sleep(2000);
//		} catch (InterruptedException e) {
//			// TODO 自动生成的 catch 块
//			e.printStackTrace();
//		}
//		Rlayout.setVisibility(View.GONE);
//	}

	private void initShare(){
		userNameValue=sp.getString("USER_NAME", "");
		passwordValue= sp.getString("PASSWORD","" );

		
	}
	
	private void initView(){

		
	
  		
		
		
		denglu=(Button) findViewById(R.id.DL_button_denglu);
	
		zhanghao=(EditText) findViewById(R.id.DL_edittext_zhanghao);
		mima=(EditText) findViewById(R.id.DL_edittext_mima);
		
		zhanghao.setText(sp.getString("USER_NAME", ""));
		mima.setText(sp.getString("PASSWORD", ""));
		
		Rlayout = (RelativeLayout) findViewById(R.id.DL_Rlayout);
		
		
		
		
	}
	
	private void initEvent(){
		denglu.setOnClickListener(this);
	
		
		
	}

	@Override
	public void onClick(View v) {
		// TODO �Զ����ɵķ������
		switch(v.getId()){
		case R.id.DL_button_denglu:
			Toast.makeText(getApplicationContext(), "登陆请求已发送。",
				     Toast.LENGTH_SHORT).show();
			userNameValue = zhanghao.getText().toString(); 
			passwordValue = mima.getText().toString();
			Editor editor = sp.edit();  
            editor.putString("USER_NAME", userNameValue);  
            editor.putString("PASSWORD",passwordValue);  
            editor.commit();  
     
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
			nameValuePairs.add(new BasicNameValuePair("userName", userNameValue));
			nameValuePairs.add(new BasicNameValuePair("userPassword", passwordValue));
			String url = ProURL.url+"user.do?method=login";
			Handler handler = new Handler(){
			@SuppressWarnings("deprecation")
			@Override
			public void handleMessage(Message msg) {

				switch(msg.what){
					case 1:
						JSONObject json = thread.getJSONObject();
						try {
							String code  = json.getString("code");
							if(code.equals("00000")){
								String data = json.getString("data");
								JSONObject pro = new JSONObject(data);
								String user = pro.getString("user");
								JSONArray U = new JSONArray(user);
								String u = U.getString(0);
								JSONObject S = new JSONObject(u);
								User.setId(S.getString("id"));
								User.setName(S.getString("truename"));
								Intent intent = new Intent();
								intent.setClass(LoginActivity.this, ProjectActivity.class);
								startActivity(intent);
							}else{
								Toast.makeText(getApplicationContext(), json.getString("msg"),
									     Toast.LENGTH_SHORT).show();
							}
						} catch (JSONException e) {
						// TODO 自动生成的 catch 块
							e.printStackTrace();
						}
						
						break;
					case 2:
						Toast.makeText(getApplicationContext(), "连接超时，请重试。",
							     Toast.LENGTH_SHORT).show();
						break;
					default:
						break;
				}
			}
		};
        thread= new NetworkThread(url, nameValuePairs,handler);
	    thread.start();


		
            
			break;
			

		}
		
	}
	

	
	 
	 
}




