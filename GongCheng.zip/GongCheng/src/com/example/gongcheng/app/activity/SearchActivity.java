package com.example.gongcheng.app.activity;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.example.gongcheng.R;
import com.example.gongcheng.app.entity.User;
import com.example.gongcheng.app.thread.NetworkThread;
import com.example.gongcheng.app.ui.ProURL;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class SearchActivity extends Activity implements OnClickListener{
	
	private Button fanhui;
	private String sousuo;
	private NetworkThread thread;
	private int top=0;
	private RelativeLayout additem;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.search_project);
		initView();
		initEvent();


	}
	
	public void initView(){
		top = 0;
		fanhui = (Button) findViewById(R.id.CZ_button_fanhui);
		additem = (RelativeLayout) findViewById(R.id.CZ_RLayout);
		Intent intent = getIntent();  
		sousuo = intent.getStringExtra("name");
		List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
        nameValuePairs.add(new BasicNameValuePair("projectName", sousuo));
        String url = ProURL.url+"project.do?method=search";
        Handler handler = new Handler(){
						@Override
				public void handleMessage(Message msg) {

					switch(msg.what){
						case 1:
							JSONObject json = thread.getJSONObject();
							try {
								String code  = json.getString("code");
								if(code.equals("00000")){
									String data = json.getString("data");
									//thread.stop();
									JSONObject pro = new JSONObject(data);
									String project = pro.getString("projects");
									JSONArray arr = new JSONArray(project);
									for (int j = 0; j < arr.length(); j++) {  
										JSONArray item = new JSONArray(arr.getString(j));
										String id = item.getString(0);
										String name = item.getString(1);
										buildView(id, name);
									}  
								}else{
									Toast.makeText(getApplicationContext(), json.getString("msg"),
										     Toast.LENGTH_SHORT).show();
								}
							}catch(Exception e){
								
								e.printStackTrace();
	
						}	
								
//        try{
//        	buildView("1", "项目一");
//        	buildView("1", "项目一");
//        	buildView("1", "项目一");
//        	buildView("1", "项目一");
//        	buildView("1", "项目一");
//        	buildView("1", "项目一");
//        	buildView("1", "项目一");
//        	buildView("1", "项目一");
//        	buildView("1", "项目一");
//        	buildView("1", "项目一");
//        	buildView("1", "项目一");
//        	buildView("1", "项目一");	
//        	}catch(Exception e){
//        		e.printStackTrace();
//			
//		}
								
							break;
						case 2:
							Toast.makeText(getApplicationContext(), "连接超时，请重试。",
								     Toast.LENGTH_SHORT).show();
							break;
						default:
							break;
							}
				}
		};
        thread= new NetworkThread(url, nameValuePairs,handler);
        thread.start();
	}
	
	public void initEvent(){
		fanhui.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO �Զ����ɵķ������
		switch (v.getId()) {
		case R.id.CZ_button_fanhui:
			SearchActivity.this.finish();
			
			break;

		default:
			break;
		}
		
	}
	
	
public void buildView(final String id,String name){
		
		RelativeLayout view = new RelativeLayout(this);
		view.setId(Integer.parseInt(id));
		//RelativeLayout.LayoutParams lp1;
		//lp1=  (LayoutParams) view.getLayoutParams();
	//	RelativeLayout.LayoutParams father = (LayoutParams) additem.getParent();
		RelativeLayout.LayoutParams lp1 = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		lp1.width = ViewGroup.LayoutParams.WRAP_CONTENT;//father.width;
		lp1.height= 200;
		
		lp1.addRule(RelativeLayout.ALIGN_PARENT_TOP);
		lp1.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
		lp1.topMargin = top;
		top+=150;
		view.setLayoutParams(lp1);
		
		TextView itemname = new TextView(this);
		itemname.setText(name);
		itemname.setTextSize(15);
		itemname.setGravity(Gravity.CENTER);
		//itemname.setBackgroundColor(android.graphics.Color.parseColor("#ffffff"));
		//RelativeLayout.LayoutParams lp2;
		//lp2 = (LayoutParams) itemname.getLayoutParams();;
		RelativeLayout.LayoutParams lp2 = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		//lp2.height=35;
		//lp2.width=50;
	
		lp2.addRule(RelativeLayout.CENTER_VERTICAL);
		lp2.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
		lp2.leftMargin=150;
		itemname.setLayoutParams(lp2);
		
		
		final Button jinru = new Button(this);
		jinru.setText("申请加入");
		jinru.setTextSize(12);
		jinru.setBackgroundDrawable(getResources().getDrawable(R.drawable.buttonback));
		//RelativeLayout.LayoutParams lp3;
		//lp3 = (LayoutParams) jinru.getLayoutParams();;
		RelativeLayout.LayoutParams lp3 = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		lp3.width  = 250;
		lp3.height = 110;
		lp3.addRule(RelativeLayout.CENTER_VERTICAL);
		lp3.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
		lp3.leftMargin=600;
		jinru.setLayoutParams(lp3);
		jinru.setOnClickListener(new Button.OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				Toast.makeText(getApplicationContext(),"请求已发送。",
					     Toast.LENGTH_SHORT).show();
				jinru.setClickable(false);
				jinru.setBackgroundDrawable(getResources().getDrawable(R.drawable.buttonshape2));
				List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
				nameValuePairs.add(new BasicNameValuePair("userId",User.getId() ));
				nameValuePairs.add(new BasicNameValuePair("projectId",id));
				String url = ProURL.url+"project.do?method=add";				
				Handler handler = new Handler(){
					@Override
					public void handleMessage(Message msg) {

						switch(msg.what){
							case 1:
								JSONObject json = thread.getJSONObject();
								
								try {

								String code  = json.getString("code");
								if(code.equals("00000")){
									String data = json.getString("data");
									}else{
										Toast.makeText(getApplicationContext(), json.getString("msg"),
											     Toast.LENGTH_SHORT).show();
									}
							} catch (JSONException e) {
							// TODO 自动生成的 catch 块
								e.printStackTrace();
							}
								break;
							case 2:
								Toast.makeText(getApplicationContext(), "连接超时，请重试。",
									     Toast.LENGTH_SHORT).show();
								break;
							default:
								break;
						}
					}
				};
		        thread= new NetworkThread(url, nameValuePairs,handler);
		        thread.start();
				
			}
			
		});
		

		
		
		
		
		view.addView(itemname,lp2);
		view.addView(jinru,lp3);
		
		additem.addView(view,lp1);
		
		
	}

}
