package com.example.gongcheng.app.activity;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.example.gongcheng.R;

import com.example.gongcheng.app.entity.User;
import com.example.gongcheng.app.thread.NetworkThread;
import com.example.gongcheng.app.ui.ProURL;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences.Editor;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;

public class ProjectActivity extends Activity implements OnClickListener {
	
	private Button changeinfo;
	private Button fanhui;
	private Button xinjian;
	private Button chazhao;
	private Button ua;
	private EditText sousuo;
	private String sousuoValue;
	private String mgs,code ;
	private NetworkThread thread;
	private RelativeLayout additem;
	private int top =0;
	private int onr=0;
	private int le = 0;
	static Boolean isRunning = false;
	
	 private ViewPager mViewpager;
	 private PagerAdapter mAdapter;
	 private List<View> mViews;
	 private LayoutInflater mInflater;

	 //TAB
	 private LinearLayout mTabproject;
	 private LinearLayout mTabinfo;
	 
	 //Buttom
	 private Button mProject;
	 private Button mInfo;
	 
	 private Dialog pDialog;
	 private Dialog iDialog;
	 
	 private TextView UserName;
	 
	 
		Timer timer = new Timer();
		Handler handler = new Handler(){
		  public void handleMessage (Message msg)  {
		    switch (msg.what) {
		        case 1:
		        	
		        	List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
		    		nameValuePairs.add(new BasicNameValuePair("userId",User.getId() ));
		    		String url = ProURL.url+"project.do?method=get";				
		    		Handler handler = new Handler(){
		    			@Override
		    			public void handleMessage(Message msg) {

		    				switch(msg.what){
		    				
		    					case 1:
		    						JSONObject json = thread.getJSONObject();
		    						
		    						try {

		    						String code  = json.getString("code");
		    						if(code.equals("00000")){
		    							String data = json.getString("data");
		    							JSONObject pro = new JSONObject(data);
		    							int a = pro.getInt("number");
		    							if(a!=0){
		    								ua.setText("查看申请("+a+")");
		    							}else{
		    								ua.setText("查看申请");
		    							}
		    							String project = pro.getString("projects");
		    							JSONArray arr = new JSONArray(project);
		    							if (arr.length()>le){
		    								removeView();
		    								top=0;
		    								for (int i = 0; i < arr.length(); i++) {  
		    									JSONArray item = new JSONArray(arr.getString(i));
		    									String id = item.getString(0);
		    									String name = item.getString(1);
		    									String power = item.getString(2);
		    									if(!power.equals("0"))
		    										buildView(id, name, power);
		    							}  
		    						}
		    					}else{
									Toast.makeText(getApplicationContext(), json.getString("msg"),
										     Toast.LENGTH_SHORT).show();
								}
		    						isRunning = true;
		    					} catch (JSONException e) {
		    					// TODO 自动生成的 catch 块
		    						e.printStackTrace();
		    					}
		    						break;
		    					case 2:
									Toast.makeText(getApplicationContext(), "连接超时，请重试。",
										     Toast.LENGTH_SHORT).show();
									break;
		    					default:
		    						break;
		    				}
		    			}
		    		};
		    		thread= new NetworkThread(url, nameValuePairs,handler);
		    		thread.start();
		           break;
		    }
		    super.handleMessage(msg);
		   }
		};  
		 
		TimerTask task = new TimerTask(){
		  public void run() {
			  if(isRunning){
				  Message message = new Message();
				  message.what = 1;
				  handler.sendMessage(message);
				  isRunning = false;
		   }
		   }
		};  
	 
	
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.view_project);
		initView();
		 
		initEvent();
		
		
		

	}
	
	
	public void initView(){
		try{
			timer.schedule(task, 5000,5000);
		}catch(Exception e){
			
		}
		isRunning = true;
		pDialog=new Dialog(ProjectActivity.this);
		pDialog.setContentView(R.layout.project_selection);
		 mInflater = LayoutInflater.from(this);
		 mViewpager = (ViewPager) findViewById(R.id.id_viewpager);
		
		
		
		
		
		//tab
		mTabproject = (LinearLayout) findViewById(R.id.BBG_bottom_1);
		mTabinfo = (LinearLayout) findViewById(R.id.BBG_bottom_info);
		
		
		//button
		mProject = (Button) findViewById(R.id.BBG_button_project);
		mInfo = (Button) findViewById(R.id.BBG_button_info);
		
		
		
		mViews = new ArrayList<View>();
		View first = mInflater.inflate(R.layout.project_selection, null);
		View second = mInflater.inflate(R.layout.userinfo, null);

		mViews.add(first);
		mViews.add(second);
		
		fanhui=(Button) first.findViewById(R.id.GC_button_tuichu);
		xinjian=(Button)first. findViewById(R.id.GC_button_xinjian);
		chazhao=(Button) first.findViewById(R.id.GC_button_chazhao);
		ua = (Button) first.findViewById(R.id.GC_button_chakan);
		sousuo = (EditText) first.findViewById(R.id.GC_editText_sousuo);
		additem = (RelativeLayout) first.findViewById(R.id.GC_RLayout);
		changeinfo = (Button) second.findViewById(R.id.UF_button_change);
		UserName = (TextView)second.findViewById(R.id.UF_textView_userName);
		UserName.setText("用户名："+User.getName());

		mAdapter = new PagerAdapter()
		{
			@Override
			public void destroyItem(ViewGroup container, int position, Object object)
			{
				container.removeView(mViews.get(position));
			}

			@Override
			public Object instantiateItem(ViewGroup container, int position)
			{
				View view = mViews.get(position);
				container.addView(view);
				return view;
			}

			@Override
			public boolean isViewFromObject(View arg0, Object arg1)
			{
				return arg0 == arg1;
			}

			@Override
			public int getCount()
			{
				return mViews.size();
			}
		};
		
		
		
		
		
		
		
//		try {
//			buildView("1", "项目一", "1");
//			buildView("1", "项目一", "2");
//			buildView("1", "项目一", "1");
//			buildView("1", "项目一", "1");
//			buildView("1", "项目一", "1");
//			buildView("1", "项目一", "1");
//			buildView("1", "项目一", "1");
//			buildView("1", "项目一", "1");
//			buildView("1", "项目一", "1");
//			buildView("1", "项目一", "1");
//			buildView("1", "项目一", "1");
//			buildView("1", "项目一", "1");
//			buildView("1", "项目一", "1");
//			buildView("1", "项目一", "1");
//			buildView("1", "项目一", "1");
//			buildView("1", "项目一", "1");
//		}catch(Exception e){
//			e.printStackTrace();
//			
//		}
		


		List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
		nameValuePairs.add(new BasicNameValuePair("userId",User.getId() ));
		String url = ProURL.url+"project.do?method=get";				
		Handler handler = new Handler(){
			@Override
			public void handleMessage(Message msg) {

				switch(msg.what){
					case 1:
						JSONObject json = thread.getJSONObject();
						
						try {

						String code  = json.getString("code");
						if(code.equals("00000")){
							String data = json.getString("data");
							JSONObject pro = new JSONObject(data);
							int a = pro.getInt("number");
							if(a!=0){
								ua.setText("查看申请("+a+")");
							}else{
								ua.setText("查看申请");
							}
							String project = pro.getString("projects");
							JSONArray arr = new JSONArray(project);
							le = arr.length();
							for (int i = 0; i < arr.length(); i++) {  
							   JSONArray item = new JSONArray(arr.getString(i));
							   String id = item.getString(0);
							   String name = item.getString(1);
							   String power = item.getString(2);
							   if(!power.equals("0"))
								   buildView(id, name, power);
							}  
						}else{
							Toast.makeText(getApplicationContext(), json.getString("msg"),
								     Toast.LENGTH_SHORT).show();
						}
					} catch (JSONException e) {
					// TODO 自动生成的 catch 块
						e.printStackTrace();
					}
						break;
					case 2:
						Toast.makeText(getApplicationContext(), "连接超时，请重试。",
							     Toast.LENGTH_SHORT).show();
						break;
					default:
						break;
				}
				
			}
		};
        thread= new NetworkThread(url, nameValuePairs,handler);
        thread.start();
        
        mViewpager.setAdapter(mAdapter);
	}
	
	public void initEvent(){
		fanhui.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO 自动生成的方法存根
	
				isRunning = false;
				Editor editor = LoginActivity.sp.edit();  
		        editor.putString("USER_NAME", "");  
		        editor.putString("PASSWORD","");  
		        editor.commit(); 
		        LoginActivity.zhanghao.setText("");
		        LoginActivity.mima.setText("");
				ProjectActivity.this.finish();
					

				
			}
		});
		
		xinjian.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO 自动生成的方法存根
				isRunning = false;
				Intent intent1 = new Intent();
				intent1.setClass(ProjectActivity.this,BuildActivity.class);
				startActivity(intent1);

				
			}
		});
		
		chazhao.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
	
				
				sousuoValue = sousuo.getText().toString();
				isRunning = false;
				
				Intent intent = new Intent();
				intent.putExtra("name", sousuoValue);
				intent.setClass(ProjectActivity.this,SearchActivity.class);
				startActivity(intent);


				
			}
		});
		
		ua.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO 自动生成的方法存根
				isRunning = false;
				Intent intent = new Intent();
				intent.setClass(ProjectActivity.this,UserApplicationActivity.class);
				startActivity(intent);
				
			}
		});
		
		changeinfo.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO 自动生成的方法存根
				isRunning = false;
				Intent intent = new Intent();
				intent.setClass(ProjectActivity.this,ChangeActivity.class);
				startActivity(intent);
			}
		});
		
		
		mTabproject.setOnClickListener(this);
		mTabinfo.setOnClickListener(this);
		  
		mViewpager.setOnPageChangeListener(new OnPageChangeListener() {	@Override
				public void onPageSelected(int position)
				{
					reColor();
					switch (position)
					{
					case 0:
						mProject.setBackgroundColor(Color.parseColor("#efefef"));
						break;
					case 1:
						mInfo.setBackgroundColor(Color.parseColor("#efefef"));
						break;
					
					}

					
				}

				@Override
				public void onPageScrolled(int arg0, float arg1, int arg2)
				{

				}

				@Override
				public void onPageScrollStateChanged(int arg0)
				{
				}
			});
		
	}
	
	@Override
	public void onClick(View v) {
		// TODO �Զ����ɵķ������
		switch(v.getId()){
		
		
			
			
		case R.id.BBG_bottom_1:
			reColor();
			mViewpager.setCurrentItem(0);
			mProject.setBackgroundColor(Color.parseColor("#efefef"));
			break;

		case R.id.BBG_bottom_info:
			reColor();
			mViewpager.setCurrentItem(1);
			mInfo.setBackgroundColor(Color.parseColor("#efefef"));
			break;
					
		}
	}
	
	
	public void buildView(final String id,String name,String power){
		
		RelativeLayout view = new RelativeLayout(pDialog.getContext());
		view.setId(Integer.parseInt(id));
		//RelativeLayout.LayoutParams lp1;
		//lp1=  (LayoutParams) view.getLayoutParams();
	//	RelativeLayout.LayoutParams father = (LayoutParams) additem.getParent();
		RelativeLayout.LayoutParams lp1 = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		lp1.width = ViewGroup.LayoutParams.WRAP_CONTENT;//father.width;
		lp1.height= 200;
		
		lp1.addRule(RelativeLayout.ALIGN_PARENT_TOP);
		lp1.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
		lp1.topMargin = top;
		top+=150;
		view.setLayoutParams(lp1);
		
		TextView itemname = new TextView(pDialog.getContext());
		itemname.setText(name);
		itemname.setTextSize(15);
		itemname.setGravity(Gravity.CENTER);
		//itemname.setBackgroundColor(android.graphics.Color.parseColor("#ffffff"));
		//RelativeLayout.LayoutParams lp2;
		//lp2 = (LayoutParams) itemname.getLayoutParams();;
		RelativeLayout.LayoutParams lp2 = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		//lp2.height=35;
		//lp2.width=50;
	
		lp2.addRule(RelativeLayout.CENTER_VERTICAL);
		lp2.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
		lp2.leftMargin=150;
		itemname.setLayoutParams(lp2);
		
		
		Button jinru = new Button(pDialog.getContext());
		jinru.setText("进入");
		jinru.setTextSize(12);
		jinru.setBackgroundDrawable(getResources().getDrawable(R.drawable.buttonback));
		//RelativeLayout.LayoutParams lp3;
		//lp3 = (LayoutParams) jinru.getLayoutParams();;
		RelativeLayout.LayoutParams lp3 = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		lp3.width  = 250;
		lp3.height = 110;
		lp3.addRule(RelativeLayout.CENTER_VERTICAL);
		lp3.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
		lp3.leftMargin=400;
		jinru.setLayoutParams(lp3);
		jinru.setOnClickListener(new Button.OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				Intent I = new Intent();
				isRunning = false;
				I.putExtra("PROJECTID", id);
				I.setClass(ProjectActivity.this,MainActivity.class);
				startActivity(I);
				
			}
			
		});
		
		final Button pbtn = new Button(pDialog.getContext());
		pbtn.setTextSize(12);
		pbtn.setBackgroundDrawable(getResources().getDrawable(R.drawable.buttonback));
		//RelativeLayout.LayoutParams lp4;
		//lp4 = (LayoutParams) pbtn.getLayoutParams();;
		RelativeLayout.LayoutParams lp4 = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		lp4.width  = 250;
		lp4.height = 110;
		lp4.addRule(RelativeLayout.CENTER_VERTICAL);
		lp4.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
		lp4.leftMargin=700;
		pbtn.setLayoutParams(lp4);
		
		switch (power) {
		case "1":
			pbtn.setText("管理");
			pbtn.setOnClickListener(new Button.OnClickListener(){

				@Override
				public void onClick(View arg0) {
					// TODO 自动生成的方法存根
					isRunning = false;
					Intent I = new Intent();
					I.putExtra("PROJECTID", id);
					I.setClass(ProjectActivity.this,Management.class);
					startActivity(I);
					
					
				}
				
			});
			break;
		case "2":
			pbtn.setText("退出");
			pbtn.setOnClickListener(new Button.OnClickListener(){

				@Override
				public void onClick(View arg0) {
					// TODO 自动生成的方法存根
					isRunning = false;
					new  AlertDialog.Builder(ProjectActivity.this)   
					.setTitle("退出工程" )  
					.setMessage("是否退出该工程？" )
					.setPositiveButton("取消" , null)  
					 .setNegativeButton("确定", new DialogInterface.OnClickListener() {
						 public void onClick(DialogInterface dialog, int whichButton) {
							 Toast.makeText(getApplicationContext(),"退出请求已发送。",
								     Toast.LENGTH_SHORT).show();
							pbtn.setClickable(false);
							pbtn.setBackgroundDrawable(getResources().getDrawable(R.drawable.buttonshape2));
							List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
							nameValuePairs.add(new BasicNameValuePair("userId",User.getId() ));
							nameValuePairs.add(new BasicNameValuePair("projectId",id));
							String url = ProURL.url+"project.do?method=quit";				
							Handler handler = new Handler(){
								@Override
								public void handleMessage(Message msg) {

									switch(msg.what){
										case 1:
											JSONObject json = thread.getJSONObject();
											
											try {

											String code  = json.getString("code");
											if(code.equals("00000")){
									
												Toast.makeText(getApplicationContext(),"退出成功。",
													     Toast.LENGTH_SHORT).show();
												onResume();
												}  else{
													Toast.makeText(getApplicationContext(), json.getString("msg"),
														     Toast.LENGTH_SHORT).show();
												}
										} catch (JSONException e) {
										// TODO 自动生成的 catch 块
											e.printStackTrace();
										}
											break;
										case 2:
											Toast.makeText(getApplicationContext(), "连接超时，请重试。",
												     Toast.LENGTH_SHORT).show();
											break;
										default:
											break;
									}
								}
							};
					        thread= new NetworkThread(url, nameValuePairs,handler);
					        thread.start();
							 
														}
						
								
						 }
					 )
					.show();
					
					
					
				}
				
			});

			break;
		}
		
		
		
		
		view.addView(itemname,lp2);
		view.addView(jinru,lp3);
		view.addView(pbtn,lp4);
		
		additem.addView(view,lp1);
		
		
	}
	
	
	private void reColor() {
		// TODO �Զ���ɵķ������
		mProject.setBackgroundColor(Color.parseColor("#808080"));
		mInfo.setBackgroundColor(Color.parseColor("#808080"));
		
		
	}
	
	@Override
	protected void onResume() {
		// TODO 自动生成的方法存根
		super.onResume();
		if(onr!=0){
			
			top=0;
			removeView();
			initView();	    	   	    
			initEvent();
			additem.invalidate();
	   }
		onr++;
	}
	
	private void removeView() {
       
        int count = additem.getChildCount();
        for (int i=0;i<count; i++) {
            
            additem.removeViewAt(0);
           
        }
        additem.invalidate();
        
    }
}
