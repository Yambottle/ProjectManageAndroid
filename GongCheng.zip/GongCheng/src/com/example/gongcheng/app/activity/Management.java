package com.example.gongcheng.app.activity;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.example.gongcheng.R;
import com.example.gongcheng.app.entity.User;
import com.example.gongcheng.app.thread.NetworkThread;
import com.example.gongcheng.app.ui.ProURL;
import com.example.gongcheng.draw.ChangeView;
import com.example.gongcheng.draw.DrawView;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Management extends Activity {
	public static JSONArray jarray,Img,data;
	
	private Button baocun,fanhui,shanchu,chongzhi,chengyuan,qingkong;
	private EditText xiangmu;
	private NetworkThread thread;
	private Intent intent;

	public ChangeView view;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.changeview);
		initView();
		initEvent();

	}



	private void initView() {
		// TODO 自动生成的方法存根
		baocun = (Button) findViewById(R.id.CV_button_baocun);
		fanhui = (Button) findViewById(R.id.CV_button_fanhui);
		shanchu = (Button) findViewById(R.id.CV_button_shanchu);
		chongzhi = (Button) findViewById(R.id.CV_button_chongzhi);
		chengyuan = (Button) findViewById(R.id.CV_button_chengyuan);
		xiangmu = (EditText) findViewById(R.id.CV_edittext_xiangmuming);
		qingkong =  (Button) findViewById(R.id.CV_button_qinghong);
		view = (ChangeView) findViewById(R.id.CV_RLayout);
		intent = getIntent(); 
		
		
		
		List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
		nameValuePairs.add(new BasicNameValuePair("projectId",intent.getStringExtra("PROJECTID") ));
		String url = ProURL.url+"project.do?method=loadMng";
		Handler handler = new Handler(){
			@Override
			public void handleMessage(Message msg) {

				switch(msg.what){
					case 1:
						JSONObject json = thread.getJSONObject();
					String code;
					try {
						code = json.getString("code");
						if(code.equals("00000")){
							data = json.getJSONArray("data"); 
							xiangmu.setText(data.getString(0));
							Img =new JSONArray(data.getString(1));
							jarray =new JSONArray(data.getString(1));
							ChangeView.isDraw = true;
							view.invalidate();
							
							
						}else{
							Toast.makeText(getApplicationContext(), json.getString("msg"),
								     Toast.LENGTH_SHORT).show();
						}
					} catch (JSONException e) {
						// TODO 自动生成的 catch 块
						e.printStackTrace();
					}
						
						break;
					case 2:
						Toast.makeText(getApplicationContext(), "连接超时，请重试。",
							     Toast.LENGTH_SHORT).show();
						break;
					default:
						break;
				}
			}
		};
        thread= new NetworkThread(url, nameValuePairs,handler);
        thread.start();
		
		
		
	}
	
	private void initEvent() {
		// TODO 自动生成的方法存根
		baocun.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				new  AlertDialog.Builder(Management.this)   
				.setTitle("修改工程" )  
				.setMessage("是否修改该工程？" )
				.setPositiveButton("取消" , null)  
				 .setNegativeButton("确定", new DialogInterface.OnClickListener() {
					 public void onClick(DialogInterface dialog, int whichButton) {
							
		        			Toast.makeText(getApplicationContext(), "请求已发送。",
		        				     Toast.LENGTH_SHORT).show();
		          			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
		          			nameValuePairs.add(new BasicNameValuePair("userId", User.getId()));
		          			nameValuePairs.add(new BasicNameValuePair("userTrueName", User.getName()));
		          			nameValuePairs.add(new BasicNameValuePair("projectId",intent.getStringExtra("PROJECTID")));
		          			nameValuePairs.add(new BasicNameValuePair("projectName", xiangmu.getText().toString()));
		          			nameValuePairs.add(new BasicNameValuePair("projectImg",jarray.toString()));
		          		
		          			String url = ProURL.url+"project.do?method=update";
		          			Handler handler = new Handler(){
		          			@SuppressWarnings("deprecation")
		          			@Override
		          			public void handleMessage(Message msg) {

		          				switch(msg.what){
		          					case 1:
		          						JSONObject json = thread.getJSONObject();
		          						try {
		          							String code  = json.getString("code");
		          							if(code.equals("00000")){
		          								Toast.makeText(getApplicationContext(), "修改成功。",
		          			        				     Toast.LENGTH_SHORT).show();
		          							}else{
		          								Toast.makeText(getApplicationContext(), json.getString("msg"),
		          									     Toast.LENGTH_SHORT).show();
		          							}
		          						} catch (JSONException e) {
		          						// TODO 自动生成的 catch 块
		          							e.printStackTrace();
		          						}
		          						
		          						break;
		          					case 2:
		          						Toast.makeText(getApplicationContext(), "连接超时，请重试。",
		          							     Toast.LENGTH_SHORT).show();
		          						break;
		          					default:
		          						break;
		          				}
		          			}
		          		};
		                 thread= new NetworkThread(url, nameValuePairs,handler);
		          	    thread.start();
		
						 
													}
					
							
					 }
				 )
				.show();
				
			}
		});
		
		fanhui.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				finish();
			}
		});
		
		
		shanchu.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				new  AlertDialog.Builder(Management.this)   
				.setTitle("删除工程" )  
				.setMessage("是否删除该工程？" )
				.setPositiveButton("取消" , null)  
				 .setNegativeButton("确定", new DialogInterface.OnClickListener() {
					 public void onClick(DialogInterface dialog, int whichButton) {
						 
						 Toast.makeText(getApplicationContext(),"删除请求已发送。",
							     Toast.LENGTH_SHORT).show();
						 
						List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
						nameValuePairs.add(new BasicNameValuePair("userId",User.getId() ));
						nameValuePairs.add(new BasicNameValuePair("projectId",intent.getStringExtra("PROJECTID")));
						String url = ProURL.url+"project.do?method=delete";				
						Handler handler = new Handler(){
							@Override
							public void handleMessage(Message msg) {

								switch(msg.what){
									case 1:
										JSONObject json = thread.getJSONObject();
										
										try {

										String code  = json.getString("code");
										if(code.equals("00000")){
											
											Toast.makeText(getApplicationContext(),"删除成功。",
												     Toast.LENGTH_SHORT).show();
											finish();
											
											}else{
												Toast.makeText(getApplicationContext(), json.getString("msg"),
													     Toast.LENGTH_SHORT).show();
											}  
									} catch (JSONException e) {
									// TODO 自动生成的 catch 块
										e.printStackTrace();
									}
										break;
									case 2:
										Toast.makeText(getApplicationContext(), "连接超时，请重试。",
											     Toast.LENGTH_SHORT).show();
										break;
									default:
										break;
								}
							}
						};
				        thread= new NetworkThread(url, nameValuePairs,handler);
				        thread.start();

						 
													}
					
							
					 }
				 )
				.show();
				
			}
		});
		
		
		chongzhi.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				
				try {
					Img =new JSONArray(data.getString(1));
					jarray =new JSONArray(data.getString(1));
				} catch (JSONException e) {
					// TODO 自动生成的 catch 块
					e.printStackTrace();
				}
				
				view.clear();
				
			}
		});
		
		qingkong.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				Img =new JSONArray();
				jarray =new JSONArray();
				
				view.clear();
				
			}
		});
		
		
		chengyuan.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO 自动生成的方法存根
				Intent i = new Intent();
				i.putExtra("PROJECTID",intent.getStringExtra("PROJECTID"));
				i.putExtra("POWER", "1");
				i.setClass(Management.this, PersonActivity.class);
				startActivity(i);
				
			}
		});
		
	}

}
