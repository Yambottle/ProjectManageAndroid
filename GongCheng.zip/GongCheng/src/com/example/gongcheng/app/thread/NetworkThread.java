package com.example.gongcheng.app.thread;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.os.Handler;
import android.widget.Toast;

public class NetworkThread extends Thread {
	private static final String APPLICATION_JSON = "application/json";
    
    private static final String CONTENT_TYPE_TEXT_JSON = "text/json";


	private String url;
	private JSONObject json;
	private List<NameValuePair> nameValuePairs;
	private Handler handler;
    public NetworkThread(String url,List<NameValuePair> nameValuePairs,Handler handler1){//定义带参数的构造函数,达到初始化线程内变量的值
       this.url=url;
       this.nameValuePairs=nameValuePairs;
       this.handler = handler1;
     
    }
    @Override
    public void run() {
    	 try{ 
    		 DefaultHttpClient httpClient = new DefaultHttpClient();
    		 HttpPost post = new HttpPost(url);
		 
    		 httpClient.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, 15000); 
		 
    		 httpClient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT, 15000);
		
	
			 post.setEntity(new UrlEncodedFormEntity(nameValuePairs,HTTP.UTF_8));
			 HttpResponse rsp = httpClient.execute(post);
	        
			 HttpEntity httpEntity = rsp.getEntity();
			 String displayString = EntityUtils.toString(httpEntity);
			 json = new JSONObject(displayString);
			 handler.sendEmptyMessage(1);
	     }catch (IOException | JSONException e) {
				// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
			handler.sendEmptyMessage(2);
		}
    }
    
    public JSONObject getJSONObject(){
    	return json;
    }
    
    

}
