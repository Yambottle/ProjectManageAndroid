package com.example.gongcheng.app.entity;

public class User {

	private static String id;
	private static String name;
	private static String pwd;
	
	public static String getId() {
		return id;
	}
	public static void setId(String userid) {
		id = userid;
	}
	public static String getName() {
		return name;
	}
	public static void setName(String username) {
		name = username;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	
}
