package com.example.gongcheng.app.utils;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.os.Environment;
import android.util.Base64;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;


public class BitmapUtils {

	public static int dip2pix(Context context, int dips) {
		int densityDpi = context.getResources().getDisplayMetrics().densityDpi;
		return (dips * densityDpi) / 160;
	}

	public static int pix2dip(Context context, int pixs) {
		int densityDpi = context.getResources().getDisplayMetrics().densityDpi;
		return (pixs * 160) / densityDpi;
	}

	/**
	 * 灏嗗浘鐗囦繚瀛樺湪鎸囧畾璺緞涓�	 * 
	 * @param bitmap
	 * @param descPath
	 */
	public static void saveBitmap(Bitmap bitmap, String descPath) {
		File file = new File(descPath);
		if (!file.getParentFile().exists()) {
			file.getParentFile().mkdirs();
		}
		if (!file.exists()) {
			try {
				bitmap.compress(CompressFormat.JPEG, 30, new FileOutputStream(
						file));
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}
		
		if (null != bitmap) {
			bitmap.recycle();
			bitmap = null;
		}
	}

	// -------------------------------------------------------------------------------------------------------------------
	public static Bitmap getRoundedCornerBitmap(Bitmap bitmap) {
		Bitmap output = Bitmap.createBitmap(bitmap.getWidth(),
				bitmap.getHeight(), Config.ARGB_8888);
		Canvas canvas = new Canvas(output);

		final int color = 0xff424242;
		final Paint paint = new Paint();
		final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
		final RectF rectF = new RectF(rect);
		final float roundPx = 12;

		paint.setAntiAlias(true);
		canvas.drawARGB(0, 0, 0, 0);
		paint.setColor(color);
		canvas.drawRoundRect(rectF, roundPx, roundPx, paint);

		paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
		canvas.drawBitmap(bitmap, rect, rect, paint);

		if (null != bitmap) {
			bitmap.recycle();
			bitmap = null;
		}
		
		return output;
	}

	/**
	 * 杞崲鍥剧墖鎴愬渾褰�	 * 
	 * @param bitmap
	 *            浼犲叆Bitmap瀵硅薄
	 * @return
	 */
	public static Bitmap toRoundBitmap(Bitmap bitmap) {
		if (bitmap == null) {
			return null;
		}
		int width = bitmap.getWidth();
		int height = bitmap.getHeight();
		float roundPx;
		float left, top, right, bottom, dst_left, dst_top, dst_right, dst_bottom;
		if (width <= height) {
			roundPx = width / 2;
			top = 0;
			bottom = width;
			left = 0;
			right = width;
			height = width;
			dst_left = 0;
			dst_top = 0;
			dst_right = width;
			dst_bottom = width;
		} else {
			roundPx = height / 2;
			float clip = (width - height) / 2;
			left = clip;
			right = width - clip;
			top = 0;
			bottom = height;
			width = height;
			dst_left = 0;
			dst_top = 0;
			dst_right = height;
			dst_bottom = height;
		}
		Bitmap output = Bitmap.createBitmap(width, height, Config.ARGB_8888);
		Canvas canvas = new Canvas(output);
		final int color = 0xff424242;
		final Paint paint = new Paint();
		final Rect src = new Rect((int) left, (int) top, (int) right,
				(int) bottom);
		final Rect dst = new Rect((int) dst_left, (int) dst_top,
				(int) dst_right, (int) dst_bottom);
		final RectF rectF = new RectF(dst);
		paint.setAntiAlias(true);
		canvas.drawARGB(0, 0, 0, 0);
		paint.setColor(color);
		canvas.drawRoundRect(rectF, roundPx, roundPx, paint);
		paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
		canvas.drawBitmap(bitmap, src, dst, paint);
		
		if(null != bitmap) {
			bitmap.recycle();
			bitmap = null;
		}
		return output;
	}

	/**
	 * @param 鈥滃皢鍥剧墖鍐呭瑙ｆ瀽鎴愬瓧鑺傛暟缁勨�
	 * @param inStream
	 * @return byte[]
	 * @throws Exception
	 */
	public static byte[] readStream(InputStream inStream) throws Exception {
		byte[] buffer = new byte[1024];
		int len = -1;
		ByteArrayOutputStream outStream = new ByteArrayOutputStream();
		while ((len = inStream.read(buffer)) != -1) {
			outStream.write(buffer, 0, len);
		}
		byte[] data = outStream.toByteArray();
		outStream.close();
		inStream.close();
		return data;

	}

	/**
	 * @param "灏嗗瓧鑺傛暟缁勮浆鎹负ImageView鍙皟鐢ㄧ殑Bitmap瀵硅薄"
	 * @param bytes
	 * @param opts
	 * @return Bitmap
	 */
	public static Bitmap getPicFromBytes(byte[] bytes,
			BitmapFactory.Options opts) {
		if (bytes != null)
			if (opts != null)
				return BitmapFactory.decodeByteArray(bytes, 0, bytes.length,
						opts);
			else
				return BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
		return null;
	}

	/**
	 * @param "鍥剧墖缂╂斁"
	 * @param bitmap
	 *            瀵硅薄
	 * @param w
	 *            瑕佺缉鏀剧殑瀹藉害
	 * @param h
	 *            瑕佺缉鏀剧殑楂樺害
	 * @return newBmp 鏂�Bitmap瀵硅薄
	 */
	public static Bitmap zoomBitmap(Bitmap bitmap, int w, int h) {
		int width = bitmap.getWidth();
		int height = bitmap.getHeight();
		Matrix matrix = new Matrix();
		float scaleWidth = (float) w / (float) width;
		float scaleHeight = (float) h / (float) height;
		matrix.postScale(scaleWidth, scaleHeight);
		Bitmap newBmp = Bitmap.createBitmap(bitmap, 0, 0, width, height,
				matrix, true);
		return newBmp;
	}

	public static Bitmap zoomBMP(Bitmap bitmap, int w, int h) {
		int width = bitmap.getWidth();
		int height = bitmap.getHeight();
		Matrix matrix = new Matrix();
		float scaleWidth = (float) w / (float) width;
		float scaleHeight = (float) h / (float) height;
		matrix.postScale(scaleWidth, scaleHeight);
		Bitmap newBmp = Bitmap.createBitmap(bitmap, 0, 0, width, height,
				matrix, true);
		return newBmp;
	}

	public static File saveBitmap(String path, Bitmap bitmap) {
		return getFileFromBytes(Bitmap2Bytes(bitmap), path);
	}

	/**
	 * 鎶夿itmap杞珺yte
	 */
	public static byte[] Bitmap2Bytes(Bitmap bm) {
		if (bm == null) {
			return null;
		}
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		bm.compress(CompressFormat.PNG, 100, baos);
		
		if (bm != null) {
			bm.recycle();
			bm = null;
		}
		
		return baos.toByteArray();
	}

	@SuppressLint("NewApi")
	public static String getBitmapStrBase64(Bitmap bitmap) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		bitmap.compress(CompressFormat.PNG, 100, baos);
		byte[] bytes = baos.toByteArray();
		String data = Base64.encodeToString(bytes, 0, bytes.length,
				Base64.DEFAULT);
		
		if (bitmap != null) {
			bitmap.recycle();
			bitmap = null;
		}
		
		return data;
	}

	/**
	 * 鎶婂瓧鑺傛暟缁勪繚瀛樹负涓�釜鏂囦欢
	 */
	public static File getFileFromBytes(byte[] b, String outputFile) {
		BufferedOutputStream stream = null;
		File file = null;
		try {
			file = new File(outputFile);
			if (!file.getParentFile().exists()) {
				file.getParentFile().mkdirs();
			}
			FileOutputStream fstream = new FileOutputStream(file);
			stream = new BufferedOutputStream(fstream);
			stream.write(b);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (stream != null) {
				try {
					stream.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		}
		return file;
	}

	/**
	 * 鏍规嵁鎵嬫満鐨勫垎杈ㄧ巼浠�dp 鐨勫崟浣�杞垚涓�px(鍍忕礌)
	 */
	public static int dip2px(Context context, float dpValue) {
		final float scale = context.getResources().getDisplayMetrics().density;
		return (int) (dpValue * scale + 0.5f);
	}

	/**
	 * 鏍规嵁鎵嬫満鐨勫垎杈ㄧ巼浠�px(鍍忕礌) 鐨勫崟浣�杞垚涓�dp
	 */
	public static int px2dip(Context context, float pxValue) {
		final float scale = context.getResources().getDisplayMetrics().density;
		return (int) (pxValue / scale + 0.5f);
	}

	public static Bitmap drawableToBitmap(Drawable drawable) {

		Bitmap bitmap = Bitmap
				.createBitmap(
						drawable.getIntrinsicWidth(),
						drawable.getIntrinsicHeight(),
						drawable.getOpacity() != PixelFormat.OPAQUE ? Config.ARGB_8888
								: Config.RGB_565);
		Canvas canvas = new Canvas(bitmap);

		drawable.setBounds(0, 0, drawable.getIntrinsicWidth(),
				drawable.getIntrinsicHeight());
		drawable.draw(canvas);

		return bitmap;

	}

//	public static byte[] compressBitmap(int maxNumOfPixels, String imgpath) {
//		double maxSize = 100.00;
//		Bitmap bitmap = loadBitmap(maxNumOfPixels, imgpath);
//		if (null != bitmap) {
//			byte[] bBitmap = convertBitmap(bitmap);
//			if (bitmap != null) {
//				bitmap.recycle();
//				bitmap = null;
//			}
//			double mid = bBitmap.length / 1024;
//			if (mid > maxSize) {
//				double i = mid / maxSize;
//				bBitmap = compressBitmap((int) (maxNumOfPixels / Math.abs(i)),
//						imgpath);
//			}
//			return bBitmap;
//		} else {
//			return null;
//		}
//	}

	public static byte[] convertBitmap(Bitmap bitmap) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		bitmap.compress(CompressFormat.JPEG, 100, baos);
		int options = 100;
//		LogUtil.e("===baos.toByteArray().length===" + baos.toByteArray().length);
//		LogUtil.e("===baos.size===" + baos.size());
		while (baos.size() / 1024 > 100) { // 寰幆鍒ゆ柇濡傛灉鍘嬬缉鍚庡浘鐗囨槸鍚﹀ぇ浜�00kb,澶т簬缁х画鍘嬬缉
			baos.reset();// 閲嶇疆baos鍗虫竻绌篵aos
			options -= 10;// 姣忔閮藉噺灏�0
			bitmap.compress(CompressFormat.JPEG, options, baos);// 杩欓噷鍘嬬缉options%锛屾妸鍘嬬缉鍚庣殑鏁版嵁瀛樻斁鍒癰aos涓�
		}
		try {
			baos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (bitmap != null) {
				bitmap.recycle();
				bitmap = null;
			}
		}
		return baos.toByteArray();

	}

//	public static Bitmap loadBitmap(int maxNumOfPixels, String imgpath) {
//		Bitmap bitmap = null;
//		try {
//			FileInputStream f = new FileInputStream(new File(imgpath));
//
//			// 绗竴娆¤В鏋愬皢inJustDecodeBounds璁剧疆涓簍rue锛屾潵鑾峰彇鍥剧墖澶у皬
//			final BitmapFactory.Options options = new BitmapFactory.Options();
//			options.inJustDecodeBounds = true;
//			BitmapFactory.decodeFile(imgpath, options);
//			// 璋冪敤涓婇潰瀹氫箟鐨勬柟娉曡绠梚nSampleSize鍊�			if (0 == maxNumOfPixels) {
//				maxNumOfPixels = 128 * 128;
//			}
//			options.inSampleSize = computeSampleSize(options, -1,
//					maxNumOfPixels);
//			// 浣跨敤鑾峰彇鍒扮殑inSampleSize鍊煎啀娆¤В鏋愬浘鐗�			options.inJustDecodeBounds = false;
//			bitmap = BitmapFactory.decodeStream(f, null, options);
//
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		
//		}
//		return bitmap;
//	}
//
//	public static int computeSampleSize(BitmapFactory.Options options,
//
//	int minSideLength, int maxNumOfPixels) {
//
//		int initialSize = computeInitialSampleSize(options, minSideLength,
//
//		maxNumOfPixels);
//
//		int roundedSize;
//
//		if (initialSize <= 8) {
//
//			roundedSize = 1;
//
//			while (roundedSize < initialSize) {
//
//				roundedSize <<= 1;
//
//			}
//
//		} else {
//
//			roundedSize = (initialSize + 7) / 8 * 8;
//
//		}
//
//		return roundedSize;
//	}

	private static int computeInitialSampleSize(BitmapFactory.Options options,

	int minSideLength, int maxNumOfPixels) {

		double w = options.outWidth;

		double h = options.outHeight;

		int lowerBound = (maxNumOfPixels == -1) ? 1 :

		(int) Math.ceil(Math.sqrt(w * h / maxNumOfPixels));

		int upperBound = (minSideLength == -1) ? 128 :

		(int) Math.min(Math.floor(w / minSideLength),

		Math.floor(h / minSideLength));

		if (upperBound < lowerBound) {

			// return the larger one when there is no overlapping zone.

			return lowerBound;

		}

		if ((maxNumOfPixels == -1) &&

		(minSideLength == -1)) {

			return 1;

		} else if (minSideLength == -1) {

			return lowerBound;

		} else {

			return upperBound;

		}
	}

//	public static String saveBitmap2file(Bitmap bmp, String filename) {
//		CompressFormat format = Bitmap.CompressFormat.JPEG;
//		int quality = 100;
//		OutputStream stream = null;
//		try {
//			stream = new FileOutputStream(filename);
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		bmp.compress(format, quality, stream);
//		return filename;
//	}
	
	 /** 
     * 淇濆瓨鏂囦欢 
     * @param bm 
     * @param fileName 
     * @throws java.io.IOException
     */  
    public static String saveFile(Bitmap bm, String fileName) throws IOException { 
     String path = getSDPath() +"/revoeye/";  
        File dirFile = new File(path);  
        if(!dirFile.exists()){  
            dirFile.mkdir();  
        }  
        File myCaptureFile = new File(path + fileName);  
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(myCaptureFile));  
        bm.compress(CompressFormat.JPEG, 100, bos);
        bos.flush();  
        bos.close(); 
        return myCaptureFile.getPath();
    } 
    public static String getSDPath(){
    	  File sdDir = null;
    	  boolean sdCardExist = Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED); //鍒ゆ柇sd鍗℃槸鍚﹀瓨鍦�    	  if (sdCardExist)
    	  {
    	   sdDir = Environment.getExternalStorageDirectory();//鑾峰彇璺熺洰褰�    	  
    	  return sdDir.toString();   
    	 }
    }
	public static Bitmap Bytes2Bimap(byte[] b) {
		if (b.length != 0) {
			return BitmapFactory.decodeByteArray(b, 0, b.length);
		} else {
			return null;
		}
	}
}
