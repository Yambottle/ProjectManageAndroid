package com.example.gongcheng.draw;

import org.json.JSONArray;
import org.json.JSONException;

import com.example.gongcheng.app.activity.MainActivity;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

public class ShowView extends View {
	private Paint brush = new Paint();


	public ShowView(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO 自动生成的构造函数存根
		brush.setAntiAlias(true);
		brush.setColor(Color.BLACK);
		brush.setStyle(Paint.Style.STROKE);
		brush.setStrokeJoin(Paint.Join.ROUND);
		brush.setStrokeWidth(30f);
	}
	
	
	@Override
	protected void onDraw(Canvas canvas) {
		// TODO 自动生成的方法存根
		super.onDraw(canvas);
//		for(int i=0;i<8;i++)
//			for(int j =0;j<13;j++){
//				canvas.drawCircle((i+1)*MainActivity.viewW/9,(j+1)*MainActivity.viewH/14 ,4 , brush);
//			}
		JSONArray arr;
		try {
			arr = new JSONArray(MainActivity.json);
			for (int i = 0; i < arr.length(); i++) {  
				   JSONArray item = new JSONArray(arr.getString(i));
				   int first = item.getInt(1);
				   int sceond = item.getInt(2);
				   int x1=first%8;
				   int y1 = first/8+1;
				   if(x1==0){x1=8;y1=first/8;};
				   int x2 = sceond%8;
				   int y2 = sceond/8+1;
				   if(x2==0){x2=8;y2=sceond/8;};
				   canvas.drawLine((float)x1/9*MainActivity.viewW, (float)y1/14*MainActivity.viewH, (float)x2/9*MainActivity.viewW, (float)y2/14*MainActivity.viewH, brush);
			}  
		} catch (JSONException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		
		
	}

	

}
