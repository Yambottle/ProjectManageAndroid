package com.example.gongcheng.draw;

import java.lang.reflect.InvocationTargetException;

import org.json.JSONArray;
import org.json.JSONException;

import com.example.gongcheng.app.activity.BuildActivity;
import com.example.gongcheng.app.activity.MainActivity;
import com.example.gongcheng.app.activity.Management;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class ChangeView extends View {
	private Paint brush = new Paint();
	private Path path = new Path();
	private int x=0,y=0;
	private  int count = 0,a=0;
	private int from = 0;
	public static boolean isDraw = false;

	

	public ChangeView(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO 自动生成的构造函数存根
		brush.setAntiAlias(true);
		brush.setColor(Color.BLACK);
		brush.setStyle(Paint.Style.STROKE);
		brush.setStrokeJoin(Paint.Join.ROUND);
		brush.setStrokeWidth(15f);
	}

	@Override
	protected void onDraw(Canvas canvas) {
		// TODO 自动生成的方法存根
		super.onDraw(canvas);
		//path.moveTo(x, y);
		
		
		
		
		
			
			
			

        	for(int i=0;i<8;i++)
    			for(int j =0;j<13;j++){
    				canvas.drawCircle(100+100*i, 100+100*j,4 , brush);
    			}  
        	
        	canvas.drawPath(path, brush);
        	
      
        		try {
        			JSONArray arr;
        			isDraw = false;
        	
        			arr = Management.Img;
        			if(a==0){
        				count=Management.Img.length();
        			}
        			a++;
        			for (int i = 0; i < arr.length(); i++) {  
        				JSONArray item = new JSONArray(arr.getString(i));
    				   int first = item.getInt(1);
    				   int sceond = item.getInt(2);
    				   int x1=first%8;
    				   int y1 = first/8+1;
    				   if(x1==0){x1=8;y1=first/8;};
    				   int x2 = sceond%8;
    				   int y2 = sceond/8+1;
    				   if(x2==0){x2=8;y2=sceond/8;};
    				   canvas.drawLine((float)x1*100, (float)y1*100, (float)x2*100, (float)y2*100, brush);
    			}  
    		} catch (Exception e) {
    			// TODO 自动生成的 catch 块
    			e.printStackTrace();
    		}
    	
  }
		

	
	
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		isDraw = true;
		float pointX = event.getX();
		float pointY = event.getY();
		int pX = (int)pointX;
		int pY = (int)pointY;
		int X=pX/100*100;
		int Y= pY/100*100;
	    int Z ;
		JSONArray JA = new JSONArray();

		// Checks for the event that occurs
		switch (event.getAction()) {
		case MotionEvent.ACTION_DOWN:
			if(pX%100>0&&pX%100<50&&X>0&&X<900){
				if(pY%100>0&&pY%100<50&&Y>0&&Y<1400){
					
					
					
					from = (Y/100)*8+X/100-8;
					if(from>0&&Y/100>0&&X/100>0)
						path.moveTo(X, Y);
					
				}
				else if(pY%100>=50&&pY%100<99&&Y<1300){
			
					
					from = (Y/100)*8+X/100;
					if(from>0&&Y/100>0&&X/100>0)
						path.moveTo(X, Y+100);
					
				}
				
			}
			
			else if(pX%100>=50&&pX%100<99&&X<800){
				if(pY%100>0&&pY%100<50&&Y>0&&Y<1400){
					
					
					from = (Y/100)*8+X/100-7;
					if(from>0&&Y/100>0&&X/100>0)
						path.moveTo(X+100, Y);
					
				}
				else if(pY%100>=50&&pY%100<99&&Y<1300){
				
			
					from = (Y/100)*8+X/100+1;
					if(from>0&&Y/100>0&&X/100>0)
						path.moveTo(X+100, Y+100);
					
				}
				if(from==1)path.moveTo(100, 100);
				
			}
			return true;
		case MotionEvent.ACTION_MOVE:
			
			if(pX%100>0&&pX%100<30&&X>0&&X<900){
				if(pY%100>0&&pY%100<30&&Y>0&&Y<1400){
					
					Z = (Y/100)*8+X/100-8;
					if(from!=Z&&from>0&&Z>0){
						path.lineTo(X, Y);
						path.moveTo(X, Y);
						JA.put(++count);
						JA.put(from);
						JA.put(Z);
						Management.jarray.put(JA);
					}
					from = Z;
				}
				else if(pY%100>70&&pY%100<99&&Y<1300){
					
					Z = (Y/100)*8+X/100;
					if(from!=Z&&from>0&&Z>0){
						path.lineTo(X, Y+100);
						path.moveTo(X, Y+100);
						JA.put(++count);
						JA.put(from);
						JA.put(Z);
						Management.jarray.put(JA);
					}
					from = Z;
				}
				
			}
			
			else if(pX%100>70&&pX%100<99&&X<800){
				if(pY%100>0&&pY%100<39&&Y>0&&Y<1400){
					
					Z = (Y/100)*8+X/100-7;
					if(from!=Z&&from>0&&Z>0){
						path.lineTo(X+100, Y);
						path.moveTo(X+100, Y);
						JA.put(++count);
						JA.put(from);
						JA.put(Z);
						Management.jarray.put(JA);
					}
					from = Z;
				}
				else if(pY%100>70&&pY%100<99&&Y<1300){
					
					Z = (Y/100)*8+X/100+1;
					if(from!=Z&&from>0&&Z>0){
						path.lineTo(X+100, Y+100);
						path.moveTo(X+100, Y+100);
						JA.put(++count);
						JA.put(from);
						JA.put(Z);
						Management.jarray.put(JA);
					}
					from = Z;
				}
				
			}
			break;
		case MotionEvent.ACTION_UP:
			path.moveTo(pointY, pointY);
			
			break;
		default:
			return false;
		}
		// Force a view to draw.
		//isDraw = true;
		postInvalidate();
		return false;

	}
	public void clear(){
		count=Management.Img.length();
		path.reset();
		postInvalidate();
		path = new Path();
		
	}

}
