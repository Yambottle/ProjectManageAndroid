package com.example.gongcheng.draw;

import org.json.JSONArray;
import org.json.JSONObject;

import com.example.gongcheng.app.activity.BuildActivity;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class DrawView extends View {
	
	private Paint brush = new Paint();
	private Path path = new Path();
	private int x=0,y=0;
	private  int count = 0;
	private int from = 0;

	

	public DrawView(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO 自动生成的构造函数存根
		brush.setAntiAlias(true);
		brush.setColor(Color.BLACK);
		brush.setStyle(Paint.Style.STROKE);
		brush.setStrokeJoin(Paint.Join.ROUND);
		brush.setStrokeWidth(15f);
	}

	@Override
	protected void onDraw(Canvas canvas) {
		// TODO 自动生成的方法存根
		super.onDraw(canvas);
		//path.moveTo(x, y);
		
		
		
		
		
			
			
			

        	for(int i=0;i<8;i++)
    			for(int j =0;j<13;j++){
    				canvas.drawCircle(100+100*i, 100+100*j,4 , brush);
    			}  
        	
        	canvas.drawPath(path, brush);
  }
		

	
	
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		float pointX = event.getX();
		float pointY = event.getY();
		int pX = (int)pointX;
		int pY = (int)pointY;
		int X=pX/100*100;
		int Y= pY/100*100;
	    int Z ;
		JSONArray JA = new JSONArray();

		// Checks for the event that occurs
		switch (event.getAction()) {
		case MotionEvent.ACTION_DOWN:
			if(pX%100>0&&pX%100<50&&X>0&&X<900){
				if(pY%100>0&&pY%100<50&&Y>0&&Y<1400){
					
					
					
					from = (Y/100)*8+X/100-8;
					if(from>0&&Y/100>0&&X/100>0)
						path.moveTo(X, Y);
					
				}
				else if(pY%100>=50&&pY%100<99&&Y<1300){
			
					
					from = (Y/100)*8+X/100;
					if(from>0&&Y/100>0&&X/100>0)
						path.moveTo(X, Y+100);
					
				}
				
			}
			
			else if(pX%100>=50&&pX%100<99&&X<800){
				if(pY%100>0&&pY%100<50&&Y>0&&Y<1400){
					
					
					from = (Y/100)*8+X/100-7;
					if(from>0&&Y/100>0&&X/100>0)
						path.moveTo(X+100, Y);
					
				}
				else if(pY%100>=50&&pY%100<99&&Y<1300){
				
			
					from = (Y/100)*8+X/100+1;
					if(from>0&&Y/100>0&&X/100>0)
						path.moveTo(X+100, Y+100);
					
				}
				if(from==1)path.moveTo(100, 100);
				
			}
			return true;
		case MotionEvent.ACTION_MOVE:
			
			if(pX%100>0&&pX%100<30&&X>0&&X<900){
				if(pY%100>0&&pY%100<30&&Y>0&&Y<1400){
					
					Z = (Y/100)*8+X/100-8;
					if(from!=Z&&from>0&&Z>0){
						path.lineTo(X, Y);
						path.moveTo(X, Y);
						JA.put(++count);
						JA.put(from);
						JA.put(Z);
						BuildActivity.jarray.put(JA);
					}
					from = Z;
				}
				else if(pY%100>70&&pY%100<99&&Y<1300){
					
					Z = (Y/100)*8+X/100;
					if(from!=Z&&from>0&&Z>0){
						path.lineTo(X, Y+100);
						path.moveTo(X, Y+100);
						JA.put(++count);
						JA.put(from);
						JA.put(Z);
						BuildActivity.jarray.put(JA);
					}
					from = Z;
				}
				
			}
			
			else if(pX%100>70&&pX%100<99&&X<800){
				if(pY%100>0&&pY%100<39&&Y>0&&Y<1400){
					
					Z = (Y/100)*8+X/100-7;
					if(from!=Z&&from>0&&Z>0){
						path.lineTo(X+100, Y);
						path.moveTo(X+100, Y);
						JA.put(++count);
						JA.put(from);
						JA.put(Z);
						BuildActivity.jarray.put(JA);
					}
					from = Z;
				}
				else if(pY%100>70&&pY%100<99&&Y<1300){
					
					Z = (Y/100)*8+X/100+1;
					if(from!=Z&&from>0&&Z>0){
						path.lineTo(X+100, Y+100);
						path.moveTo(X+100, Y+100);
						JA.put(++count);
						JA.put(from);
						JA.put(Z);
						BuildActivity.jarray.put(JA);
					}
					from = Z;
				}
				
			}
			break;
		case MotionEvent.ACTION_UP:
			path.moveTo(pointY, pointY);
			
			break;
		default:
			return false;
		}
		// Force a view to draw.
		postInvalidate();
		return false;

	}
	public void clear(){
		count=0;
		path.reset();
		postInvalidate();
		path = new Path();
		
	}
	
	
}