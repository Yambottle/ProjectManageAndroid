package com.example.projectmanage.entity;

import java.io.Serializable;

public class Project implements Serializable{
	private static final long serialVersionUID = 1L;

	private Integer id;
	
	private String name;
	
	private String center;
	
	private String map;
	
	private String creator;
	
	private String date;
	
	private String machinecost;
	
	private String peoplecost;
	
	private String materialcost;
	
	private String othercost;
	
	private String valuation;
	
	private String allcost;
	
	private String contractId;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMap() {
		return map;
	}

	public void setMap(String map) {
		this.map = map;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getMachinecost() {
		return machinecost;
	}

	public void setMachinecost(String machinecost) {
		this.machinecost = machinecost;
	}

	public String getPeoplecost() {
		return peoplecost;
	}

	public void setPeoplecost(String peoplecost) {
		this.peoplecost = peoplecost;
	}

	public String getMaterialcost() {
		return materialcost;
	}

	public void setMaterialcost(String materialcost) {
		this.materialcost = materialcost;
	}

	public String getOthercost() {
		return othercost;
	}

	public void setOthercost(String othercost) {
		this.othercost = othercost;
	}

	public String getValuation() {
		return valuation;
	}

	public void setValuation(String valuation) {
		this.valuation = valuation;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getContractId() {
		return contractId;
	}

	public void setContractId(String contractId) {
		this.contractId = contractId;
	}

	public String getAllcost() {
		return allcost;
	}

	public void setAllcost(String allcost) {
		this.allcost = allcost;
	}

	public String getCenter() {
		return center;
	}

	public void setCenter(String center) {
		this.center = center;
	}
	
}
