package com.example.projectmanage.common;

import java.io.Serializable;

public class Parameter implements Serializable{
	
	public final static String SUCCESS_CODE = "00000";
	public final static String FALSE_CODE = "10000";
	public final static String SP_NAME = "userSP";
	//public final static String url ="http://192.168.199.159:8888/xxgc/";//Test
	//public final static String url ="http://192.168.199.159:8888/gcgl/";
	public final static String url ="http://115.28.244.50/gcgl/";//OutNet
	
}
