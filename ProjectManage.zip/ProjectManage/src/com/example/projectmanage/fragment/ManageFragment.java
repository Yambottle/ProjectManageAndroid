package com.example.projectmanage.fragment;

import com.example.projectmanage.activity.R;
import com.example.projectmanage.activity.ValueInputActivity;

import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class ManageFragment extends Fragment implements OnClickListener{

	private RelativeLayout valueRelativeLayout;
	private TextView valueTextView;
	private ImageView valueImageView;
	
	public View onCreateView(LayoutInflater inflater,
			@Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		
		return inflater.inflate(R.layout.fragment_manage,container, false);
	}
	
	@Override
	public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onViewCreated(view, savedInstanceState);
		
		valueRelativeLayout = (RelativeLayout) view.findViewById(R.id.valueRL);
		valueTextView = (TextView) view.findViewById(R.id.valueTV);
		valueImageView = (ImageView) view.findViewById(R.id.valueIV);
		
		valueRelativeLayout.setOnClickListener(this);
		valueTextView.setOnClickListener(this);
		valueImageView.setOnClickListener(this);
	}

	@Override
	public void onClick(View view) {
		switch (view.getId()) {
		case R.id.valueRL:
		case R.id.valueTV:
		case R.id.valueIV:
			toValueInput();
			break;
		}
	}
	
	public void toValueInput(){
		Intent intent = new Intent();
		intent.setClass(this.getActivity(), ValueInputActivity.class);
		this.getActivity().startActivity(intent);
	}
}
