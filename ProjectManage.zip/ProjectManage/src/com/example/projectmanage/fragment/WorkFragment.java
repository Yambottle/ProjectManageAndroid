package com.example.projectmanage.fragment;

import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.MapStatus;
import com.baidu.mapapi.map.MapStatusUpdate;
import com.baidu.mapapi.map.MapStatusUpdateFactory;
import com.baidu.mapapi.map.MapView;
import com.baidu.mapapi.map.MyLocationData;
import com.baidu.mapapi.map.UiSettings;
import com.baidu.mapapi.map.BaiduMap.OnMapStatusChangeListener;
import com.baidu.mapapi.model.LatLng;
import com.example.projectmanage.activity.ProjectActivity;
import com.example.projectmanage.activity.R;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;

public class WorkFragment extends Fragment implements OnClickListener,OnMapStatusChangeListener,BDLocationListener{
	
	private MapView mMapView;
    private BaiduMap mBaiduMap;
    private UiSettings mUiSettings;
    public LocationClient mLocClient;
    private int isFirstLoc = 0;
    
    boolean isLockMap = true;
    private ImageButton lockImageButton;
    
    private LinearLayout manpowerLinearLayout, machineLinearLayout, resourceLinearLayout, contractLinearLayout;
    private TextView manpowerTextView, machineTextView, resourceTextView, contractTextView;
    
    private LinearLayout horizontalLinearLayout;
	
	public View onCreateView(LayoutInflater inflater,
			@Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		View v = inflater.inflate(R.layout.fragment_work, null);
        mMapView = (MapView) v.findViewById(R.id.bmapViewFragment);
        mBaiduMap = mMapView.getMap();
        return v;
	}
	
	@Override
	public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
		super.onViewCreated(view, savedInstanceState);
		
		lockImageButton = (ImageButton) view.findViewById(R.id.lock);
		
		manpowerLinearLayout = (LinearLayout) view.findViewById(R.id.manpowerLL);
		machineLinearLayout = (LinearLayout) view.findViewById(R.id.machineLL);
		resourceLinearLayout = (LinearLayout) view.findViewById(R.id.resourceLL);
		contractLinearLayout = (LinearLayout) view.findViewById(R.id.otherLL);
		manpowerTextView = (TextView) view.findViewById(R.id.manpowerTV);
		machineTextView = (TextView) view.findViewById(R.id.machineTV);
		resourceTextView = (TextView) view.findViewById(R.id.resourceTV);
		contractTextView = (TextView) view.findViewById(R.id.otherTV);
		
		horizontalLinearLayout = (LinearLayout) view.findViewById(R.id.hLL);
		//实现Map
    	initMap();
    	//Lock

    	initEvent();
		//实现HorizontalScroll一级二级关联
    	initSecLev(1);
	}
	
	public void initEvent(){
		lockImageButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View view) {
				lock_unlock();
			}
		});
		
	}
	
	public void initSecLev(int tab){
		LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.MATCH_PARENT);
		LinearLayout.LayoutParams widgetParams = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
		for(int i=0;i<tab;i++){
			LinearLayout newLayout = new LinearLayout(getActivity());
			newLayout.setOrientation(LinearLayout.VERTICAL);
			newLayout.setGravity(Gravity.CENTER_HORIZONTAL);
			ImageButton imageButton = new ImageButton(getActivity());
			imageButton.setImageDrawable(getResources().getDrawable(R.drawable.user32));
			imageButton.setLayoutParams(widgetParams);
			TextView textView1 = new TextView(getActivity());
			textView1.setText("名称");
			textView1.setLayoutParams(widgetParams);
			TextView textView2 = new TextView(getActivity());
			textView2.setText("123");
			textView2.setLayoutParams(widgetParams);
			newLayout.addView(imageButton);
			newLayout.addView(textView1);
			newLayout.addView(textView2);
			horizontalLinearLayout.addView(newLayout, layoutParams);
		}
	}
	
	@Override
	public void onClick(View view) {
		horizontalLinearLayout.removeAllViews();
		switch (view.getId()) {
		case R.id.manpowerLL:
		case R.id.manpowerTV:
			initSecLev(1);
			break;
		case R.id.machineLL:
		case R.id.machineTV:
			initSecLev(2);
			break;
		case R.id.resourceLL:
		case R.id.resourceTV:
			initSecLev(3);
			break;
		case R.id.otherLL:
		case R.id.otherTV:
			initSecLev(4);
			break;
		}
		
	}
	
	public void initMap(){
    	//remove widget
    	mMapView.removeViewAt(1);//logo
    	mMapView.showZoomControls(false);//zoom
    	//init map
    	mUiSettings = mBaiduMap.getUiSettings();
    	mUiSettings.setCompassEnabled(true);//compass
    	mUiSettings.setAllGesturesEnabled(false);
    	//定义地图状态
    	LatLng ll = new LatLng(36.072982329734174, 120.38889101891933);
        MapStatusUpdate msu = MapStatusUpdateFactory.newLatLngZoom(ll, 13);
        mBaiduMap.setMapStatus(msu);
    }

	@Override
	public void onReceiveLocation(BDLocation location) {
		// map view 销毁后不在处理新接收的位置
        if (location == null || mMapView == null) {
            return;
        }
        MyLocationData locData = new MyLocationData.Builder()
                .accuracy(location.getRadius())
                        // 此处设置开发者获取到的方向信息，顺时针0-360
                .direction(100).latitude(location.getLatitude())
                .longitude(location.getLongitude()).build();
        mBaiduMap.setMyLocationData(locData);
        if (isFirstLoc < 3) {
            isFirstLoc++;
            LatLng ll = new LatLng(location.getLatitude(), location.getLongitude());
            MapStatusUpdate msu = MapStatusUpdateFactory.newLatLngZoom(ll, 13);
            mBaiduMap.animateMapStatus(msu);
        }
		
	}

	@Override
	public void onMapStatusChange(MapStatus arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onMapStatusChangeFinish(MapStatus arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onMapStatusChangeStart(MapStatus arg0) {
		// TODO Auto-generated method stub
		
	}

	public void lock_unlock(){
		if(isLockMap){
			((ProjectActivity)getActivity()).mViewPager.setScanScroll(false);
			mUiSettings.setAllGesturesEnabled(true);
			isLockMap = false;
			lockImageButton.setImageDrawable(getResources().getDrawable(R.drawable.lockopen48));
			setEvent();
		}else{
			((ProjectActivity)getActivity()).mViewPager.setScanScroll(true);
			mUiSettings.setAllGesturesEnabled(false);
			isLockMap = true;
			lockImageButton.setImageDrawable(getResources().getDrawable(R.drawable.lockclose48));
			unsetEvent();
		}
	}
	
	public void setEvent(){
		manpowerLinearLayout.setOnClickListener(this);
		machineLinearLayout.setOnClickListener(this);
		resourceLinearLayout.setOnClickListener(this);
		contractLinearLayout.setOnClickListener(this);
		manpowerTextView.setOnClickListener(this);
		machineTextView.setOnClickListener(this);
		resourceTextView.setOnClickListener(this);
		contractTextView.setOnClickListener(this);
	}
	
	public void unsetEvent(){
		manpowerLinearLayout.setOnClickListener(null);
		machineLinearLayout.setOnClickListener(null);
		resourceLinearLayout.setOnClickListener(null);
		contractLinearLayout.setOnClickListener(null);
		manpowerTextView.setOnClickListener(null);
		machineTextView.setOnClickListener(null);
		resourceTextView.setOnClickListener(null);
		contractTextView.setOnClickListener(null);
	}
	
	@Override
	public void onPause() {
        super.onPause();
        mMapView.onPause();
    }

    @Override
	public void onResume() {
        super.onResume();
        mMapView.onResume();
    }

    @Override
	public void onDestroy() {
        super.onDestroy();
        mMapView.onDestroy();
    }

}
