package com.example.projectmanage.fragment;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.example.projectmanage.activity.CreateProjectActivity;
import com.example.projectmanage.activity.FindProjectActivity;
import com.example.projectmanage.activity.ProjectActivity;
import com.example.projectmanage.activity.R;
import com.example.projectmanage.menu.Menu;
import com.example.projectmanage.menu.MenuItem;
import com.example.projectmanage.menu.Menu.SateliteClickedListener;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView.OnItemClickListener;

public class TabSearchFragment extends Fragment implements OnItemClickListener,OnScrollListener{
	
	private Handler handler=new Handler();
	private ArrayList<Map<String, Object>> utp_pro_list;

	private ListView lv;
	private SimpleAdapter sa;
	private List<Map<String,Object>> dataList;
	
	@SuppressWarnings("unchecked")
	@Override
	public View onCreateView(LayoutInflater inflater,
			@Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		utp_pro_list = (ArrayList<Map<String, Object>>) getArguments().getSerializable("utp_pro_list");
		return inflater.inflate(R.layout.fragment_search,container, false);
	}
	
	@Override
	public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
		super.onViewCreated(view, savedInstanceState);
		lv=(ListView)view.findViewById(R.id.listView1);
		handler.post(new Runnable() {
			@Override
			public void run() {
				//ListView
				dataList =new ArrayList<Map<String, Object>>();
				sa=new SimpleAdapter(
				getActivity(), getData(),R.layout.item_search,//MainActivity.this
				new String[]{"item_title","money_content","item_content"}, 
				new int[]{R.id.item_title,R.id.textView1,R.id.item_content});
				lv.setAdapter(sa);
			}
		});
		lv.setOnItemClickListener(this);
		lv.setOnScrollListener(this);
		
		initMenu(view);
	}

	//------------------------------ListView&&ListItem
	@SuppressWarnings("unchecked")
	private List<Map<String,Object>> getData(){
		for(Map<String,Object> listMap : utp_pro_list){
			Map<String,Object> projectMap = (Map<String,Object>)listMap.get("project");
			Map<String,Object> map = new HashMap<String,Object>();
			map.put("item_title", projectMap.get("name"));
			map.put("money_content", "总成本："+projectMap.get("allcost"));
			map.put("item_content", "创建者："+projectMap.get("creator"));
			dataList.add(map);
		}
		return dataList;
	}
	//------------------------------ListViewEvents

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
		// TODO Auto-generated method stub
		toProjectItem();
	}
	
	public void initMenu(View v){
		Menu menu = (Menu) v.findViewById(R.id.menu);
		List<MenuItem> items = new ArrayList<MenuItem>();
		MenuItem item1 = new MenuItem(1, R.drawable.paper72);
		MenuItem item2 = new MenuItem(2, R.drawable.magnifier72);
		items.add(item1);
		items.add(item2);
		menu.addItems(items);
		menu.setOnItemClickedListener(new SateliteClickedListener() {
			public void eventOccured(int id) {
				switch (id) {
				case 1:
					toCreateProject();
					break;
				case 2:					
					toFindProject();
					break;
				}
			}
		});
	}

	@Override
	public void onScroll(AbsListView arg0, int arg1, int arg2, int arg3) {
	}

	@Override
	public void onScrollStateChanged(AbsListView arg0, int arg1) {
	}
	
	public void toCreateProject(){//-------
		Intent intent = new Intent();
		Bundle bundle = new Bundle();
		bundle.putSerializable("utp_pro_list", utp_pro_list);
		intent.putExtras(bundle);
		intent.setClass(this.getActivity(), CreateProjectActivity.class);
		this.getActivity().startActivity(intent);
		this.getActivity().finish();
	}
	
	public void toFindProject(){
		Intent intent = new Intent();
		intent.setClass(this.getActivity(), FindProjectActivity.class);
		this.getActivity().startActivity(intent);
	}
	
	public void toProjectItem(){
		Intent intent = new Intent();
		intent.setClass(this.getActivity(), ProjectActivity.class);
		this.getActivity().startActivity(intent);
	}
}

