package com.example.projectmanage.fragment;

import java.util.Map;

import com.example.projectmanage.activity.LoginActivity;
import com.example.projectmanage.activity.PwdActivity;
import com.example.projectmanage.activity.R;
import com.example.projectmanage.common.Parameter;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class TabMeFragment extends Fragment implements OnClickListener{
	
	private Map<String, Object> userMap ;
	
	private RelativeLayout pwdRelativeLayout, outRelativeLayout ;
	private TextView myInfo, myTrueName, myPhone, pwdTextView, outTextView ;
	private ImageView pwdImageView, outImageView ;
	
	private SharedPreferences sp ;
	
	@SuppressWarnings("unchecked")
	public View onCreateView(LayoutInflater inflater,
			@Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		userMap = (Map<String, Object>) getArguments().getSerializable("userMap");
		return inflater.inflate(R.layout.fragment_me,container, false);
	}
	
	@Override
	public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onViewCreated(view, savedInstanceState);
		myInfo = (TextView) view.findViewById(R.id.myInfo);
		myTrueName = (TextView) view.findViewById(R.id.myTrueName);
		myPhone = (TextView) view.findViewById(R.id.myPhone);
		
		myInfo.setText((String)userMap.get("name"));
		myTrueName.setText((String)userMap.get("truename"));
		myPhone.setText((String)userMap.get("phone"));
		
		
		pwdRelativeLayout = (RelativeLayout) view.findViewById(R.id.pwdRL);
		pwdTextView = (TextView) view.findViewById(R.id.pwdTV);
		pwdImageView = (ImageView) view.findViewById(R.id.pwdIV);
		
		outRelativeLayout = (RelativeLayout) view.findViewById(R.id.outRL);
		outTextView = (TextView) view.findViewById(R.id.outTV);
		outImageView = (ImageView) view.findViewById(R.id.outIV);
		
		pwdRelativeLayout.setOnClickListener(this);
		pwdTextView.setOnClickListener(this);
		pwdImageView.setOnClickListener(this);
		outRelativeLayout.setOnClickListener(this);
		outTextView.setOnClickListener(this);
		outImageView.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {

		switch (v.getId()) {
		case R.id.pwdIV:
		case R.id.pwdRL:
		case R.id.pwdTV:
			changePWD();
			break;
		case R.id.outIV:
		case R.id.outRL:
		case R.id.outTV:
			logout();
			break;
		}
		
	}
	
	public void logout(){
		sp = this.getActivity().getSharedPreferences(Parameter.SP_NAME, Context.MODE_PRIVATE);
		Editor e = sp.edit();
		e.clear();
		e.commit();
		
		Intent intent = new Intent();
		intent.setClass(this.getActivity(), LoginActivity.class);
		this.getActivity().startActivity(intent);
		this.getActivity().finish();
	}
	
	public void changePWD(){
		Intent intent = new Intent();
		intent.setClass(this.getActivity(), PwdActivity.class);
		this.getActivity().startActivity(intent);
	}
	
}
