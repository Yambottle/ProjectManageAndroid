package com.example.projectmanage.activity;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import com.example.projectmanage.common.Parameter;
import com.example.projectmanage.http.AccessNetwork;
import com.example.projectmanage.http.ReadResp;
import com.google.gson.Gson;

import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends Activity implements OnClickListener{
	
	private Button sendButton, resetButton;
	private EditText userEditText, pwdEditText;
	private String name ;
	private String pwd ;
	private ReadResp readResp ;
	private SharedPreferences sp ;
	private String userkey = "user";
	private String loginFail = "连接失败，请重试";	
	private String url =Parameter.url+ "user.do?method=login";
	//private String url =Parameter.url+ "user.do?method=test";
	private List<NameValuePair> nameValuePairs;
	private Map<String , Object> userMap;
	private Gson gson;
	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		sendButton = (Button) findViewById(R.id.login);
		resetButton = (Button) findViewById(R.id.reset);
		userEditText = (EditText)findViewById(R.id.name);
		pwdEditText = (EditText)findViewById(R.id.pwd);
		sp = getSharedPreferences(Parameter.SP_NAME, Context.MODE_PRIVATE);
		nameValuePairs = new ArrayList<NameValuePair>();
		userMap = new HashMap<String , Object>();
		gson = new Gson();
		readResp = new ReadResp();
		sendButton.setOnClickListener(this);
		resetButton.setOnClickListener(this);
	}
	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.login:
			login();
			hideSoftWin();
			break;
		case R.id.reset:
			reset();
			break;
		}
		
	}
	
	public void putShare(String name , String pwd ){
		Editor e = sp.edit();
		e.putString("name", name);
		e.putString("pwd", pwd);
		e.commit();
	}
	
	public void login(){
		name = userEditText.getText().toString().trim();
		pwd = pwdEditText.getText().toString().trim();
		nameValuePairs.clear();
		Handler h= new Handler(){
			@Override
			public void handleMessage(Message msg) {
				String error = msg.getData().getString("error");
				if(error == null){
					String dataString = readResp.readResp(msg);
					if(readResp.getCode().equals(Parameter.SUCCESS_CODE)){
						putShare(name, pwd);//put login info
						Intent i = new Intent();
						Bundle bundle = new Bundle();
						bundle.putString("data", dataString);
						i.putExtras(bundle);
						i.setClass(LoginActivity.this, FunctionActivity.class);
						startActivity(i);
						sendButton.setEnabled(true);
						LoginActivity.this.finish();
					}else if(readResp.getCode().equals(Parameter.FALSE_CODE)){
						sendButton.setEnabled(true);
						Toast.makeText(LoginActivity.this,loginFail, Toast.LENGTH_LONG).show();
					}
				}else{
					sendButton.setEnabled(true);
					Toast.makeText(LoginActivity.this,error, Toast.LENGTH_LONG).show();
				}		
			}
		};
		sendButton.setEnabled(false);//inhibit click again
		
		try {
			name=new String(name.getBytes(),"UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		userMap.put("name", name);
		userMap.put("pwd", pwd);
		//Toast.makeText(getApplicationContext(), userMap.toString(),Toast.LENGTH_LONG).show();//
		nameValuePairs.add(new BasicNameValuePair(userkey,gson.toJson(userMap)));
		new Thread(new AccessNetwork(url,nameValuePairs,h)).start();
	}
	
	public void reset(){
		userEditText.setText("");
		pwdEditText.setText("");
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		if (keyCode == KeyEvent.KEYCODE_BACK )
		{
			// 创建退出对话框
			AlertDialog isExit = new AlertDialog.Builder(this)
			.setTitle("系统提示")
			.setMessage("确定要退出吗?")
			.setPositiveButton("确定", listener)
			.setNegativeButton("取消", listener)
			.create();

			isExit.show();

		}
		
		return false;
		
	}
	/**监听对话框里面的button点击事件*/
	DialogInterface.OnClickListener listener = new DialogInterface.OnClickListener()
	{
		public void onClick(DialogInterface dialog, int which)
		{
			switch (which)
			{
			case AlertDialog.BUTTON_POSITIVE:// "确认"按钮退出程序
				finish();
				break;
			case AlertDialog.BUTTON_NEGATIVE:// "取消"第二个按钮取消对话框
				break;
			default:
				break;
			}
		}
	};	
	
	@Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            if (getCurrentFocus() != null && getCurrentFocus().getWindowToken() != null) {
            	InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);  
                imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
            }
        }
        return super.onTouchEvent(event);
    }
	
	public void hideSoftWin(){
		InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);  
        imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
	}
}