package com.example.projectmanage.activity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import com.baidu.lbsapi.auth.n;
import com.baidu.location.e.p;
import com.example.projectmanage.common.Parameter;
import com.example.projectmanage.http.AccessNetwork;
import com.example.projectmanage.http.ReadResp;
import com.google.gson.Gson;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import android.widget.Toast;

public class MainActivity extends Activity {

	private String name, pwd ;
	private SharedPreferences  sp;
	private ReadResp readResp ;
	private String userkey = "user";
	private String loginOvertime = "登录信息过期";	
	private String url = Parameter.url+ "user.do?method=login";
	private List<NameValuePair> nameValuePairs;
	private Map<String , Object> userMap;
	private Gson gson;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		//display login image
		//login:UI/sharepreference
		readResp = new ReadResp();
		sp = getSharedPreferences(Parameter.SP_NAME,Context.MODE_PRIVATE);
		nameValuePairs = new ArrayList<NameValuePair>();
		userMap = new HashMap<String , Object>();
		gson = new Gson();
		
		Handler handler = new Handler();
		handler.postDelayed(new Runnable() {
			@Override
			public void run() {
				if(checkPref()){//login in SP
					loginFromPref();
				}else{//go to Login
					Intent intent = new Intent();
					intent.setClass(MainActivity.this, LoginActivity.class);
					startActivity(intent);
				}
			}
		}, 3000);
	}
	
	protected void onPause() {
        super.onPause();
        Handler handler = new Handler();
		handler.postDelayed(new Runnable() {
			@Override
			public void run() {
				MainActivity.this.finish();
			}
		}, 2500);
    }
	
	public boolean checkPref() {
		name = sp.getString("name", null);
		pwd = sp.getString("pwd", null);
		if(name != null||pwd != null){
			return true;
		}else{
			return false;
		}
	}
	
	public void loginFromPref(){//login from SharePreference
		Handler h= new Handler(){
			@Override
			public void handleMessage(Message msg) {
				String error = msg.getData().getString("error");//check time out
				if(error == null){	
					String dataString = readResp.readResp(msg);
					if(readResp.getCode().equals(Parameter.SUCCESS_CODE)){//check resp_code
						Intent i = new Intent();
						Bundle bundle = new Bundle();
						bundle.putString("data", dataString);
						i.putExtras(bundle);
						i.setClass(MainActivity.this, FunctionActivity.class);
						startActivity(i);
					}else if(readResp.getCode().equals(Parameter.FALSE_CODE)){//login false to Login.act
						Editor e = sp.edit();
						e.clear();
						e.commit();
						Toast.makeText(MainActivity.this,loginOvertime, Toast.LENGTH_LONG).show();
						Intent intent = new Intent();
						intent.setClass(MainActivity.this, LoginActivity.class);
						startActivity(intent);
					}
				}else{//login false to Login.act
					Toast.makeText(MainActivity.this,error, Toast.LENGTH_LONG).show();
					Intent intent = new Intent();
					intent.setClass(MainActivity.this, LoginActivity.class);
					startActivity(intent);
				}		
			}
		};
		
		userMap.put("name", name);
		userMap.put("pwd", pwd);
		nameValuePairs.add(new BasicNameValuePair(userkey,gson.toJson(userMap)));
		new Thread(new AccessNetwork(url,nameValuePairs, h)).start();
	}
}
