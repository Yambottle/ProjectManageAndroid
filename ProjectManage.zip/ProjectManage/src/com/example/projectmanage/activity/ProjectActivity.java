package com.example.projectmanage.activity;

import java.util.ArrayList;
import java.util.List;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.projectmanage.fragment.DataFragment;
import com.example.projectmanage.fragment.ManageFragment;
import com.example.projectmanage.fragment.WorkFragment;
import com.example.projectmanage.widget.CustomViewPager;

public class ProjectActivity extends FragmentActivity {
	
	private Button logButton;
	private ImageButton backImageButton;
	private TextView title;
	
	public CustomViewPager mViewPager;
	private List<Fragment> fragmentList;
	private Fragment dataFragment, manageFragment, workFragment ;
	private RelativeLayout r1, r2, r3;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_project);
		
		//TopBar
		title = (TextView) findViewById(R.id.textView1);
		backImageButton = (ImageButton) findViewById(R.id.back);
		backImageButton.setOnClickListener(new OnClickListener() {
			public void onClick(View arg0) {
				finish();	
			}
		});
		logButton = (Button) findViewById(R.id.log);
		logButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View view) {				
				Intent intent = new Intent();
				intent.setClass(ProjectActivity.this, ProjectLogActivity.class);
				startActivity(intent);
			}
		});
		
		//Pager
		mViewPager=(CustomViewPager) findViewById(R.id.pager);
		initData();
		initManage();
		initWork();
		fragmentList=new ArrayList<Fragment>();
		fragmentList.add(manageFragment);
		fragmentList.add(dataFragment);
		fragmentList.add(workFragment);
		
		r1 = (RelativeLayout) findViewById(R.id.r1);
		r2 = (RelativeLayout) findViewById(R.id.r2);
		r3 = (RelativeLayout) findViewById(R.id.r3);
		
		mViewPager.setAdapter(new MyFrageStatePagerAdapter2(getSupportFragmentManager()));
		mViewPager.setCurrentItem(1, true);
		toData();
		
	}
	
	public void initData(){
		dataFragment = new DataFragment();
	}
	
	public void initManage(){
		manageFragment = new ManageFragment();
	}
	
	public void initWork(){
		workFragment = new WorkFragment();
	}
	
	public class MyFrageStatePagerAdapter2 extends FragmentStatePagerAdapter {

		public MyFrageStatePagerAdapter2(FragmentManager fm) {
			super(fm);
		}

		@Override
		public int getCount() {
			return fragmentList.size(); 
		}

		@Override
		public Fragment getItem(int position) {
			return fragmentList.get(position);
		}

		@Override
		public void finishUpdate(ViewGroup container){
			super.finishUpdate(container);
			resTab();
			switch (mViewPager.getCurrentItem()) {
			case 0:
				toManage();
				break;
			case 1:
				toData();
				break;
			case 2:
				toWork();
				break;
			}
		}
	}
	
	public void resTab(){
		r1.setBackgroundColor(R.color.red);
		r2.setBackgroundColor(R.color.red);
		r3.setBackgroundColor(R.color.red);
	}
	
	public void toData(){
		r2.setBackgroundColor(R.color.downbarblue);
		title.setText("工程名称");
		logButton.setVisibility(View.VISIBLE);
	}
	
	public void toManage(){
		r1.setBackgroundColor(R.color.downbarblue);
		title.setText("对象管理");
		logButton.setVisibility(View.GONE);
	}
	
	public void toWork(){
		r3.setBackgroundColor(R.color.downbarblue);
		title.setText("入场离场");
		logButton.setVisibility(View.GONE);
	}
}
