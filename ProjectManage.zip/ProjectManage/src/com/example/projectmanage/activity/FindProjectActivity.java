package com.example.projectmanage.activity;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import com.baidu.mapapi.SDKInitializer;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.BaiduMap.OnMarkerClickListener;
import com.baidu.mapapi.map.BaiduMapOptions;
import com.baidu.mapapi.map.BitmapDescriptor;
import com.baidu.mapapi.map.BitmapDescriptorFactory;
import com.baidu.mapapi.map.InfoWindow.OnInfoWindowClickListener;
import com.baidu.mapapi.map.InfoWindow;
import com.baidu.mapapi.map.MapStatus;
import com.baidu.mapapi.map.MapView;
import com.baidu.mapapi.map.Marker;
import com.baidu.mapapi.map.MarkerOptions;
import com.baidu.mapapi.map.UiSettings;
import com.baidu.mapapi.map.MarkerOptions.MarkerAnimateType;
import com.baidu.mapapi.model.LatLng;
import com.baidu.platform.comapi.map.v;
import com.example.projectmanage.activity.R;
import com.example.projectmanage.common.Parameter;
import com.example.projectmanage.http.AccessNetwork;
import com.example.projectmanage.http.ReadResp;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.Toast;
import android.widget.FrameLayout.LayoutParams;

public class FindProjectActivity extends Activity implements OnClickListener, OnInfoWindowClickListener{

	private List<NameValuePair> nameValuePairs;
	private String getMapkey = "projectName";
	private String searchUrl =Parameter.url+ "project.do?method=search";
	private String joinUrl =Parameter.url+ "project.do?method=join";
	private Handler handler;
	private ReadResp readResp ;
	private Gson gson;
	private List<Map<String, Object>> proList;
	private String projectkey = "projectName";
	private String userkey = "userName";
	
	private FrameLayout mapparentFrameLayout;
	private MapView mMapView;
	private BaiduMap mBaiduMap;
    private UiSettings mUiSettings;
    private BitmapDescriptor bitmapDescriptor ;
    private Button button;
    private InfoWindow mInfoWindow ;
    private String proName ;
    
    private ImageButton backImageButton;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//remove SDKinit
		setContentView(R.layout.activity_find_project);
		getInfoAndInit();
		initEvent();
	}

	private void getInfoAndInit() {
		nameValuePairs = new ArrayList<NameValuePair>();
		readResp = new ReadResp();
		gson = new Gson();
		bitmapDescriptor = BitmapDescriptorFactory.fromResource(R.drawable.point48);
		handler = new Handler(){

			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				String dataString = readResp.readResp(msg);
				if(readResp.getCode().equals(Parameter.SUCCESS_CODE)){
				Map<String, Object> dataMap = gson.fromJson(dataString, new TypeToken<Map<String, Object>>() {}.getType());
				proList = (List<Map<String, Object>>) dataMap.get("projects");
				initMap();
				initPoint(proList);
				initEvent();
				}else{
					Toast.makeText(getApplicationContext(), readResp.getMessage(), Toast.LENGTH_LONG);
				}
			}
		};
		nameValuePairs.add(new BasicNameValuePair(getMapkey, ""));
		new Thread(new AccessNetwork(searchUrl,nameValuePairs, handler)).start();// TODO Auto-generated method stub
	}

	private void initMap() {
		
		mapparentFrameLayout = (FrameLayout) findViewById(R.id.mapparent);
		BaiduMapOptions options = new BaiduMapOptions();
		options.zoomControlsEnabled(false);//zoom
		LatLng ll = new LatLng(36.072982329734174, 120.38889101891933);
		options.mapStatus(new MapStatus.Builder().target(ll).zoom(13).build()); 
		mMapView = new MapView(FindProjectActivity.this, options);
		mMapView.removeViewAt(1);//logo
		mMapView.setClickable(true);
		FrameLayout.LayoutParams params_map = new FrameLayout.LayoutParams( LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT); 
		mapparentFrameLayout.addView(mMapView, params_map);
		//EditText
		
		mBaiduMap = mMapView.getMap();
    	mUiSettings = mBaiduMap.getUiSettings();
    	mUiSettings.setCompassEnabled(true);//compass
	}
	
	private void initPoint(List<Map<String, Object>> proList) {
		
		for(Map<String, Object> project : proList){
			
			LatLng ll = (LatLng)gson.fromJson((String)project.get("center"), new TypeToken<LatLng>() {}.getType());
			//marker
			Bundle bundle = new Bundle();
			bundle.putString("proname", (String)project.get("name"));
			MarkerOptions mo = new MarkerOptions().
					position(ll).
					extraInfo(bundle).
					icon(bitmapDescriptor).zIndex(9).
					animateType(MarkerAnimateType.drop);
			mBaiduMap.addOverlay(mo);

		}
		
		//markerInfoButton
		mBaiduMap.setOnMarkerClickListener(new OnMarkerClickListener() {
			@Override
			public boolean onMarkerClick(Marker marker) {
				
				proName = marker.getExtraInfo().getString("proname").toString();
				button = new Button(FindProjectActivity.this);
				button.setBackgroundResource(R.drawable.popup);
				button.setText((String)marker.getExtraInfo().getString("proname"));
				mInfoWindow = new InfoWindow(BitmapDescriptorFactory.fromView(button), marker.getPosition(), -47, FindProjectActivity.this);
				mBaiduMap.showInfoWindow(mInfoWindow);
				return false;
			}
		});
	}
	
	public void onInfoWindowClick() {
		nameValuePairs.clear();
		nameValuePairs.add(new BasicNameValuePair(projectkey, proName));
		nameValuePairs.add(new BasicNameValuePair(userkey, FindProjectActivity.this.getSharedPreferences(Parameter.SP_NAME, MODE_PRIVATE).getString("name", "")));
		AlertDialog isExit = new AlertDialog.Builder(FindProjectActivity.this)
		.setTitle("发送申请")
		.setMessage("确定要发送申请吗?")
		.setPositiveButton("确定", dialoglistener)
		.setNegativeButton("取消", dialoglistener)
		.create();
		isExit.show();
	}
	
	private void initEvent() {
		backImageButton = (ImageButton) findViewById(R.id.back);
		backImageButton.setOnClickListener(this);
	}


	@Override
	public void onClick(View view) {
		
		switch (view.getId()) {
		case R.id.back:
			finish();
			break;
		}
		
	}
	
	DialogInterface.OnClickListener dialoglistener = new DialogInterface.OnClickListener()
	{
		public void onClick(DialogInterface dialog, int which)
		{
			switch (which)
			{
			case AlertDialog.BUTTON_POSITIVE:// "确认"按钮退出程序
				Handler h = new Handler(){
					@Override
					public void handleMessage(Message msg) {
						super.handleMessage(msg);
						readResp.readRespNoData(msg);
						if(readResp.getCode().equals(Parameter.SUCCESS_CODE)){
							Toast.makeText(getApplicationContext(), readResp.getMessage(), Toast.LENGTH_LONG).show();
						}else{
							Toast.makeText(getApplicationContext(), readResp.getMessage(), Toast.LENGTH_LONG).show();
						}
					}
				};
				new Thread(new AccessNetwork(joinUrl,nameValuePairs, h)).start();// TODO Auto-generated method stub
				break;
			case AlertDialog.BUTTON_NEGATIVE:// "取消"第二个按钮取消对话框
				break;
			default:
				break;
			}
		}
	};

}
