package com.example.projectmanage.activity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.SimpleAdapter;

public class ValueInputActivity extends Activity implements OnClickListener {

	private ListView lv;
	private SimpleAdapter sa;
	private List<Map<String,Object>> dataList;
	private Handler handler=new Handler();
	
	private Button addButton, saveButton;
	private ImageButton backImageButton;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_value_input);
		lv=(ListView)findViewById(R.id.listView1);
		handler.post(new Runnable() {
			@Override
			public void run() {
				//ListView
				dataList =new ArrayList<Map<String, Object>>();
				sa=new SimpleAdapter(
				ValueInputActivity.this, getData(),R.layout.item_value_input,
				new String[]{"name","nametext","price","pricetext","quantity","quantitytext","total","totaltext"}, 
				new int[]{R.id.name,R.id.nametext,R.id.price,R.id.pricetext,R.id.quantity,R.id.quantitytext,R.id.total,R.id.totaltext});
				lv.setAdapter(sa);
			}
		});
		
		addButton = (Button) findViewById(R.id.add);
		saveButton = (Button) findViewById(R.id.save);
		backImageButton = (ImageButton) findViewById(R.id.back);
		addButton.setOnClickListener(this);
		saveButton.setOnClickListener(this);
		backImageButton.setOnClickListener(this);
		//item可删除
	}

	private List<Map<String,Object>> getData(){
			Map<String,Object> map = new HashMap<String,Object>();
			map.put("name", "名称：");
			map.put("nametext","");
			map.put("price", "单价：");
			map.put("pricetext","");
			map.put("quantity", "数量：");
			map.put("quantitytext","");
			map.put("total", "总价：");
			map.put("totaltext","");
			dataList.add(map);
		return dataList;
	}
	
	public void addItem(){
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("name", "名称：");
		map.put("nametext","");
		map.put("price", "单价：");
		map.put("pricetext","");
		map.put("quantity", "数量：");
		map.put("quantitytext","");
		map.put("total", "总价：");
		map.put("totaltext","");
		dataList.add(map);
		sa.notifyDataSetChanged();
	}

	@Override
	public void onClick(View view) {
		switch (view.getId()) {
		case R.id.add:
			addItem();
			break;
		case R.id.back:
			finish();
		}
	}
	
	@Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            if (getCurrentFocus() != null && getCurrentFocus().getWindowToken() != null) {
            	InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);  
                imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
            }
        }
        return super.onTouchEvent(event);
    }
	
	public void hideSoftWin(){
		InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);  
        imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
	}

}
