package com.example.projectmanage.activity;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.example.projectmanage.fragment.TabMeFragment;
import com.example.projectmanage.fragment.TabSearchFragment;
import com.example.projectmanage.widget.TopBar;
import com.example.projectmanage.widget.TopBar.TopbarClickListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Toast;

public class FunctionActivity extends FragmentActivity implements OnClickListener {
	
	private LinearLayout Tabsearch,Tabme;
	private int TabSelectColor=0xFF293047;
	private int TabNotSelectColor=0xFF304160;
	private ImageButton Ibsearch,Ibme;
	private TopBar topBar;

	private ViewPager mViewPager;
	private List<Fragment> fragmentList;
	private Fragment fsearch,fme;
	
	private Map<String, Object> dataMap;
	
	private String choosePro = "选择工程";
	private String meInfo = "我的信息";
	private String log_info = "申请信息";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_fuction);
		
		String dataString = (String)getIntent().getStringExtra("data");
		dataMap = new Gson().fromJson(dataString,  new TypeToken<Map<String,Object>>() {}.getType());
		//TopBar
		topBar=(TopBar)findViewById(R.id.topbar);
		topBar.setOnTopbarClickListener(new TopbarClickListener() {
			
			@Override
			public void rightClick() {
				// TODO Auto-generated method stub
			}
			
			@Override
			public void leftClick() {
				Toast.makeText(FunctionActivity.this, log_info, Toast.LENGTH_SHORT).show();
			}
		});
		
		//Tab
		Tabsearch=(LinearLayout)findViewById(R.id.searchtab);
		Tabme=(LinearLayout)findViewById(R.id.metab);
			
		Ibsearch=(ImageButton)findViewById(R.id.searchimg);
		Ibme=(ImageButton)findViewById(R.id.meimg);
		Ibsearch.setBackgroundColor(TabSelectColor);
		
		Tabsearch.setOnClickListener(this);
		Tabme.setOnClickListener(this);
		Ibsearch.setOnClickListener(this);
		Ibme.setOnClickListener(this);
		
		//Pager
		mViewPager=(ViewPager) findViewById(R.id.pager);
		initSearch();
		initMe();
		fragmentList=new ArrayList<Fragment>();
		fragmentList.add(fsearch);
		fragmentList.add(fme);
		
		mViewPager.setAdapter(new MyFrageStatePagerAdapter(getSupportFragmentManager()));
		changeView(0);
	}

	public void initSearch(){
		Bundle bundle = new Bundle();
		bundle.putSerializable("utp_pro_list",(Serializable)dataMap.get("list"));
		fsearch = new TabSearchFragment();
		fsearch.setArguments(bundle);
	}
	
	public void initMe(){
		Bundle bundle = new Bundle();
		bundle.putSerializable("userMap",(Serializable)dataMap.get("user"));
		fme = new TabMeFragment();
		fme.setArguments(bundle);
	}
	
	public class MyFrageStatePagerAdapter extends FragmentStatePagerAdapter {

		public MyFrageStatePagerAdapter(FragmentManager fm) {
			super(fm);
		}

		@Override
		public int getCount() {
			return fragmentList.size(); 
		}

		@Override
		public Fragment getItem(int position) {
			return fragmentList.get(position);
		}

		@Override
		public void finishUpdate(ViewGroup container){
			super.finishUpdate(container);
			resTab();
			switch (mViewPager.getCurrentItem()) {
			case 0:
				toSearch();
				break;
			case 1:
				toMe();
				break;
			}
		}
	}
	
	@Override
	public void onClick(View v) {
		resTab();
		switch(v.getId()){
			case R.id.searchtab:
			case R.id.searchimg:
				changeView(0);
				break;
			case R.id.metab:
			case R.id.meimg:
				changeView(1);
				break;
		}
	}
	//-------Tab
	private void resTab() {
		// TODO Auto-generated method stub
		Tabsearch.setBackgroundColor(TabNotSelectColor);
		Tabme.setBackgroundColor(TabNotSelectColor);
		
		Ibsearch.setBackgroundColor(TabNotSelectColor);
		Ibme.setBackgroundColor(TabNotSelectColor);
		
		Ibsearch.setImageDrawable(getResources().getDrawable(R.drawable.ruler32));
		Ibme.setImageDrawable(getResources().getDrawable(R.drawable.id32));
	}
	
	public void changeView(int tab){
		resTab();
		mViewPager.setCurrentItem(tab, true);
		switch(tab){
		case 0:
			toSearch();
			break;
		case 1:
			toMe();
			break;
		}
	}
	
	public void toSearch(){
		Tabsearch.setBackgroundColor(TabSelectColor);
		Ibsearch.setBackgroundColor(TabSelectColor);
		Ibsearch.setImageDrawable(getResources().getDrawable(R.drawable.ruler_click32));
		topBar.setTitle(choosePro);
	}
	
	public void toMe(){
		Tabme.setBackgroundColor(TabSelectColor);
		Ibme.setBackgroundColor(TabSelectColor);
		Ibme.setImageDrawable(getResources().getDrawable(R.drawable.id_click32));
		topBar.setTitle(meInfo);
	}
	//-------Dialog Window
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event){
		if (keyCode == KeyEvent.KEYCODE_BACK ){
			// 创建退出对话框
			AlertDialog isExit = new AlertDialog.Builder(this)
			.setTitle("系统提示")
			.setMessage("确定要退出吗?")
			.setPositiveButton("确定", listener)
			.setNegativeButton("取消", listener)
			.create();
			isExit.show();
		}
		return false;
	}
	/**监听对话框里面的button点击事件*/
	DialogInterface.OnClickListener listener = new DialogInterface.OnClickListener(){
		public void onClick(DialogInterface dialog, int which){
			switch (which){
			case AlertDialog.BUTTON_POSITIVE:// "确认"按钮退出程序
				finish();
				break;
			case AlertDialog.BUTTON_NEGATIVE:// "取消"第二个按钮取消对话框
				break;
			default:
				break;
			}
		}
	};
}
