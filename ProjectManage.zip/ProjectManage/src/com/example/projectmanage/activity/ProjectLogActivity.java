package com.example.projectmanage.activity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

public class ProjectLogActivity extends Activity implements OnClickListener, OnItemClickListener, OnScrollListener {

	private ListView lv;
	private SimpleAdapter sa;
	private List<Map<String,Object>> dataList;
	
	private ImageButton backImageButton;
	
	private LinearLayout manLL , proLL ;
	private TextView manTV , proTV;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_project_log);
		
		//init layout,tv
		manLL = (LinearLayout) findViewById(R.id.manlogLL);
		proLL = (LinearLayout) findViewById(R.id.prologLL);
		manTV = (TextView) findViewById(R.id.manlogTV);
		proTV = (TextView) findViewById(R.id.prologTV);
		manLL.setOnClickListener(this);
		proLL.setOnClickListener(this);
		manTV.setOnClickListener(this);
		proLL.setOnClickListener(this);
		//color change
		manTV.setTextColor(getResources().getColor(R.color.darkblue));
		
		initList();
		
		backImageButton = (ImageButton) findViewById(R.id.back);
		backImageButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				finish();
			}
		});
	}
	
	public void initList(){
		Handler handler = new Handler();
		lv=(ListView) findViewById(R.id.logLV);
		handler.post(new Runnable() {
			@Override
			public void run() {
				//ListView
				dataList =new ArrayList<Map<String, Object>>();
				sa=new SimpleAdapter(
				ProjectLogActivity.this, getData(),R.layout.item_log,//MainActivity.this
				new String[]{"date","log"}, 
				new int[]{R.id.dateTV,R.id.logTV});
				lv.setAdapter(sa);
			}
		});
		lv.setOnItemClickListener(this);
		lv.setOnScrollListener(this);
	}
	
	private List<Map<String,Object>> getData(){
			Map<String,Object> map1 = new HashMap<String,Object>();
			map1.put("date", "2016-4-11 15:29");
			map1.put("log", "增加增加增加增加增加增加增加增加增加增加增加增加增加增加增加增加增加增加增加增加增加增加增加增加增加增加增加增加增加增加");
			Map<String,Object> map2 = new HashMap<String,Object>();
			map2.put("date", "2016-4-11 16:29");
			map2.put("log", "减少");
			dataList.add(map1);
			dataList.add(map2);
		return dataList;
	}
	
	@Override
	public void onClick(View view) {
		resTab();
		switch (view.getId()) {
		case R.id.manlogLL:
		case R.id.manlogTV:
			initList();
			manTV.setTextColor(getResources().getColor(R.color.darkblue));
			break;
		case R.id.prologLL:
		case R.id.prologTV:
			initList();
			proTV.setTextColor(getResources().getColor(R.color.darkblue));
			break;
		}
		
	}
	
	public void resTab(){
		manTV.setTextColor(getResources().getColor(R.color.black));
		proTV.setTextColor(getResources().getColor(R.color.black));
	}
	
	@Override
	public void onScroll(AbsListView arg0, int arg1, int arg2, int arg3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onScrollStateChanged(AbsListView arg0, int arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
		//复制Log
	}
	
}
