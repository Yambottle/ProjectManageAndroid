package com.example.projectmanage.test;

import java.util.Map;


import com.example.projectmanage.entity.User;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class TestResp {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String json = "{\"data\":{\"list\":[{\"utp\":{\"id\":1,\"username\":\"test1\",\"projectname\":\"project1\",\"permission\":\"1\"},\"project\":{\"id\":1,\"name\":\"project1\",\"map\":\"111\",\"creator\":\"test1\",\"date\":\"111\",\"machinecost\":\"1111\",\"peoplecost\":\"1111\",\"materialcost\":\"1111\",\"othercost\":\"1111\",\"valuation\":\"111\",\"allcost\":\"4444\",\"contractId\":\"1\"}},{\"utp\":{\"id\":2,\"username\":\"test1\",\"projectname\":\"project2\",\"permission\":\"1\"},\"project\":{\"id\":2,\"name\":\"project2\",\"map\":\"222\",\"creator\":\"test1\",\"date\":\"2\",\"machinecost\":\"2\",\"peoplecost\":\"2\",\"materialcost\":\"2\",\"othercost\":\"2\",\"valuation\":\"21\",\"allcost\":\"8\",\"contractId\":\"1\"}}],\"user\":[{\"id\":1,\"name\":\"test1\",\"turename\":\"�����ʺ�\",\"pwd\":\"1234\",\"phone\":\"15820034791\",\"date\":\"\",\"remark\":\"111\",\"authority\":\"1\"}]},\"code\":\"00000\",\"msg\":\"��½�ɹ�\"}";
		TestResp tr = new TestResp();
		tr.readResp(json);
	}

	public void readResp(String json){//����resp������Ϣ:resp->(data->(list(list)->utp,project),user),code,msg
		Gson gson = new Gson();
		Map<String,Object> jsonMap = gson.fromJson(json, new TypeToken<Map<String,Object>>() {}.getType());
		//respString
			String dataString = (String) jsonMap.get("data");
			String message = (String) jsonMap.get("msg");
			String code = (String) jsonMap.get("code");
			//dataString
			Map<String,Object> dataMap = gson.fromJson(dataString, new TypeToken<Map<String,Object>>() {}.getType());
			User user = gson.fromJson((String)dataMap.get("user"), User.class);
			System.out.println(user.getName());
	}
	public void post(Map map) {
//		nameValuePairs = new ArrayList<NameValuePair>();
//		nameValuePairs.add(new BasicNameValuePair(key, userJasonString));
		
	}
}
