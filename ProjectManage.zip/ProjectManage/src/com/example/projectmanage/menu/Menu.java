package com.example.projectmanage.menu;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

import com.example.projectmanage.activity.R;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.widget.FrameLayout;
import android.widget.ImageView;

public class Menu extends FrameLayout {
	public static final String TAG = "Menu";

	private static final int DEFAULT_EXPAND_DURATION = 400;
	private static final boolean DEFAULT_CLOSE_ON_CLICK = true;
	private static final float DEFAULT_TOTAL_SPACING_DEGREE = 180f;
	private static final int DEFAULT_DISTANCE = 200;

	private int expandDuration = DEFAULT_EXPAND_DURATION;
	private boolean closeOnClick = DEFAULT_CLOSE_ON_CLICK;
	private float totalSpacingDegree = DEFAULT_TOTAL_SPACING_DEGREE;
	private int distance = DEFAULT_DISTANCE;

	private ImageView imgMain;

	private Animation mainRotateRight;
	private Animation mainRotateLeft;

	private boolean rotated = false;
	private AtomicBoolean plusAnimationActive = new AtomicBoolean(false);
	private List<MenuItem> menuItems = new ArrayList<MenuItem>();

	private int measureDiff;

	private Map<View, MenuItem> viewToItemMap = new HashMap<View, MenuItem>();
	private InternalSatelliteOnClickListener internalItemClickListener;
	private SateliteClickedListener itemClickedListener;

	public Menu(Context context) {
		super(context);
		init(context, null, 0);
	}

	public Menu(Context context, AttributeSet attrs) {
		super(context, attrs);
		init(context, attrs, 0);
	}

	public Menu(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		init(context, attrs, defStyle);
	}

	private void init(Context context, AttributeSet attrs, int defStyle) {
		inflate(context, R.layout.sat_main, this);
		imgMain = (ImageView) findViewById(R.id.img_main);
		if (attrs != null) {
			TypedArray typedArray = context.obtainStyledAttributes(attrs,
					R.styleable.Menu, defStyle, 0);
			expandDuration = typedArray.getInt(R.styleable.Menu_expandDuration,
					DEFAULT_EXPAND_DURATION);
			closeOnClick = typedArray.getBoolean(R.styleable.Menu_closeOnClick,
					DEFAULT_CLOSE_ON_CLICK);
			totalSpacingDegree = typedArray.getFloat(
					R.styleable.Menu_totalSpacingDegree,
					DEFAULT_TOTAL_SPACING_DEGREE);
			distance = typedArray.getDimensionPixelSize(
					R.styleable.Menu_distance, DEFAULT_DISTANCE);
			typedArray.recycle();
		}
		mainRotateLeft = AnimationCreator.createMainButtonAnimation(context);
		mainRotateRight = AnimationCreator
				.createMainButtonInverseAnimation(context);
		AnimationListener plusAnimationListener = new AnimationListener() {

			@Override
			public void onAnimationStart(Animation animation) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onAnimationRepeat(Animation animation) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onAnimationEnd(Animation animation) {
				// TODO Auto-generated method stub
				plusAnimationActive.set(false);
			}
		};

		mainRotateLeft.setAnimationListener(plusAnimationListener);
		mainRotateRight.setAnimationListener(plusAnimationListener);

		imgMain.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				Menu.this.onClick();
			}
		});

		internalItemClickListener = new InternalSatelliteOnClickListener(this);

	}

	private void onClick() {
		if (plusAnimationActive.compareAndSet(false, true)) {
			if (!rotated) {
				Log.i(TAG, "mainRotateLeft");
				imgMain.startAnimation(mainRotateLeft);
				for (MenuItem item : menuItems) {
					item.getView().startAnimation(item.getOutAnimation());
				}
				
			} else {
				Log.i(TAG, "mainRotateRight");
				imgMain.startAnimation(mainRotateRight);
				for (MenuItem item : menuItems) {
					item.getView().startAnimation(item.getInAnimation());
				}
			}
			rotated = !rotated;
		}
	}

	/**
	 * 添加菜单选项
	 * 
	 * @param items
	 */
	public void addItems(List<MenuItem> items) {
		menuItems.addAll(items);
		this.removeView(imgMain);
		float[] degrees = getDegrees(items.size());
		for (int i = 0; i < items.size(); i++) {
			MenuItem menuItem = items.get(i);
			int finalX = AnimationCreator.getTranslateX(distance, degrees[i]);
			int finalY = AnimationCreator.getTranslateY(distance, degrees[i]);
			ImageView itemView = (ImageView) LayoutInflater.from(getContext())
					.inflate(R.layout.sat_item, this, false);
			ImageView cloneView = (ImageView) LayoutInflater.from(getContext())
					.inflate(R.layout.sat_item, this, false);
			itemView.setTag(menuItem.getId());
			cloneView.setTag(menuItem.getId());
			cloneView.setOnClickListener(internalItemClickListener);
			if (menuItem.getImgResourceId() > 0) {
				itemView.setImageResource(menuItem.getImgResourceId());
				cloneView.setImageResource(menuItem.getImgResourceId());
			} else {
				itemView.setImageDrawable(menuItem.getImgDrawable());
				cloneView.setImageDrawable(menuItem.getImgDrawable());
			}
			itemView.setVisibility(View.VISIBLE); // 这句很重要

			FrameLayout.LayoutParams params = getLayoutParams(cloneView);
			params.rightMargin = finalX;
			params.bottomMargin = finalY;
			cloneView.setLayoutParams(params);

			Animation outAnimation = AnimationCreator.createItemOutAnimation(
					getContext(), i, expandDuration, finalX, finalY);
			Animation inAnimation = AnimationCreator.createItemInAnimation(
					getContext(), i, expandDuration, finalX, finalY);
			Animation clickAnimation = AnimationCreator
					.createItemClickAnimation(getContext());

			menuItem.setFinalX(finalX);
			menuItem.setFinalY(finalY);
			menuItem.setView(itemView);
			menuItem.setCloneView(cloneView);
			menuItem.setOutAnimation(outAnimation);
			menuItem.setInAnimation(inAnimation);
			menuItem.setClickAnimation(clickAnimation);

			outAnimation.setAnimationListener(new SatelliteAnimationListener(
					itemView, false, viewToItemMap));
			inAnimation.setAnimationListener(new SatelliteAnimationListener(
					itemView, true, viewToItemMap));
			clickAnimation
					.setAnimationListener(new SatelliteItemClickAnimationListener(
							this, menuItem.getId()));

			this.addView(itemView);
			this.addView(cloneView);

			viewToItemMap.put(itemView, menuItem);
			viewToItemMap.put(cloneView, menuItem);

		}
		this.addView(imgMain);

	}

	public void resetItems() {
		if (menuItems.size() > 0) {
			List<MenuItem> items = new ArrayList<MenuItem>(menuItems);
			menuItems.clear();
			this.removeAllViews();
			addItems(items);
		}
	}

	/**
	 * 获取不同位置的角度
	 * 
	 * @param count
	 * @return
	 */
	private float[] getDegrees(int count) {
		float[] degrees = new float[count];
		if (count == 1) {
			degrees[0] = 0f;
		} else {
			float average = totalSpacingDegree / (count - 1);
			for (int i = 0; i < count; i++) {
				degrees[i] = average * i;
			}
		}
		return degrees;
	}

	/**
	 * Menu扩充的大小
	 */
	private void recalculateMeasureDiff() {
		int itemWidth = 0;
		if (menuItems.size() > 0) {
			itemWidth = menuItems.get(0).getView().getWidth();
		}
		measureDiff = Float.valueOf(distance * 0.2f).intValue() + itemWidth;
	}

	/*
	 * 绘制Menu的大小
	 * 
	 * @see android.widget.FrameLayout#onMeasure(int, int)
	 */
	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);
		recalculateMeasureDiff();
		int totalWidth = imgMain.getWidth() + distance * 2 + measureDiff;
		int totalHeight = imgMain.getHeight() + distance + measureDiff;
		this.setMeasuredDimension(totalWidth, totalHeight);
	}

	private static FrameLayout.LayoutParams getLayoutParams(View view) {
		return (FrameLayout.LayoutParams) view.getLayoutParams();
	}

	/**
	 * Expand the menu items.
	 */
	public void expand() {
		openItems();
	}

	/**
	 * Collapse the menu items
	 */
	public void close() {
		closeItems();
	}

	private void openItems() {
		if (plusAnimationActive.compareAndSet(false, true)) {
			if (!rotated) {
				imgMain.startAnimation(mainRotateLeft);
				for (MenuItem item : menuItems) {
					item.getView().startAnimation(item.getOutAnimation());
				}
			}
			rotated = !rotated;
		}
	}

	private void closeItems() {
		if (plusAnimationActive.compareAndSet(false, true)) {
			if (rotated) {
				imgMain.startAnimation(mainRotateRight);
				for (MenuItem item : menuItems) {
					item.getView().startAnimation(item.getInAnimation());
				}
			}
			rotated = !rotated;
		}
	}

	/**
	 * The listener class for item click event.
	 * 
	 * @author Siyamed SINIR
	 */
	public interface SateliteClickedListener {
		/**
		 * When an item is clicked, informs with the id of the item, which is
		 * given while adding the items.
		 * 
		 * @param id
		 *            The id of the item.
		 */
		public void eventOccured(int id);
	}

	private static class SatelliteItemClickAnimationListener implements
			Animation.AnimationListener {
		private WeakReference<Menu> menuRef;
		private int tag;

		public SatelliteItemClickAnimationListener(Menu menu, int tag) {
			this.menuRef = new WeakReference<Menu>(menu);
			this.tag = tag;
		}

		@Override
		public void onAnimationEnd(Animation animation) {
		}

		@Override
		public void onAnimationRepeat(Animation animation) {
		}

		@Override
		public void onAnimationStart(Animation animation) {
			Menu menu = menuRef.get();
			if (menu != null && menu.closeOnClick) {
				menu.close();
				if (menu.itemClickedListener != null) {
					menu.itemClickedListener.eventOccured(tag);
				}
			}
		}
	}

	private static class SatelliteAnimationListener implements
			Animation.AnimationListener {

		private WeakReference<View> viewRef;
		private boolean isInAnimation;
		private Map<View, MenuItem> viewToItemMap;

		SatelliteAnimationListener(View view, boolean isInAnimation,
				Map<View, MenuItem> viewToItemMap) {
			this.viewRef = new WeakReference<View>(view);
			this.isInAnimation = isInAnimation;
			this.viewToItemMap = viewToItemMap;
		}

		@Override
		public void onAnimationStart(Animation animation) {
			// TODO Auto-generated method stub
			if (viewRef != null) {
				View view = viewRef.get();
				if (view != null) {
					MenuItem item = viewToItemMap.get(view);
					if (isInAnimation) {
						item.getView().setVisibility(View.VISIBLE);
						item.getCloneView().setVisibility(View.GONE);
					} else {
						item.getView().setVisibility(View.VISIBLE);
						item.getCloneView().setVisibility(View.GONE);
					}
					int[] viewLocation = new int[2];
					int[] cloneLocation = new int[2];
					item.getView().getLocationInWindow(viewLocation);
					item.getCloneView().getLocationInWindow(cloneLocation);
					Log.i(TAG, "start-------" + "[" + viewLocation[0] + ","
							+ viewLocation[1] + "]");
					Log.i(TAG, "start-------" + "[" + cloneLocation[0] + ","
							+ cloneLocation[1] + "]");
				}
			}
		}

		@Override
		public void onAnimationEnd(Animation animation) {
			// TODO Auto-generated method stub
			if (viewRef != null) {
				View view = viewRef.get();
				if (view != null) {
					MenuItem item = viewToItemMap.get(view);
					if (isInAnimation) {
						item.getView().setVisibility(View.GONE);
						item.getCloneView().setVisibility(View.GONE);
					} else {
						item.getView().setVisibility(View.GONE);
						item.getCloneView().setVisibility(View.VISIBLE);
					}
					int[] viewLocation = new int[2];
					int[] cloneLocation = new int[2];
					item.getView().getLocationInWindow(viewLocation);
					item.getCloneView().getLocationInWindow(cloneLocation);
					Log.i(TAG, "end-------" + "[" + viewLocation[0] + ","
							+ viewLocation[1] + "]");
					Log.i(TAG, "end-------" + "[" + cloneLocation[0] + ","
							+ cloneLocation[1] + "]");
				}
			}
		}

		@Override
		public void onAnimationRepeat(Animation animation) {
			// TODO Auto-generated method stub

		}

	}

	public Map<View, MenuItem> getViewToItemMap() {
		return viewToItemMap;
	}

	private static class InternalSatelliteOnClickListener implements
			View.OnClickListener {
		private WeakReference<Menu> menuRef;

		public InternalSatelliteOnClickListener(Menu menu) {
			this.menuRef = new WeakReference<Menu>(menu);
		}

		@Override
		public void onClick(View v) {
			Menu menu = menuRef.get();
			if (menu != null) {
				MenuItem menuItem = menu.getViewToItemMap().get(v);
				v.startAnimation(menuItem.getClickAnimation());
			}
		}
	}

	/**
	 * Sets the click listener for satellite items.
	 * 
	 * @param itemClickedListener
	 */
	public void setOnItemClickedListener(
			SateliteClickedListener itemClickedListener) {
		this.itemClickedListener = itemClickedListener;
	}

}
