package com.example.projectmanage.map;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;
import com.baidu.location.LocationClientOption.LocationMode;
import com.baidu.location.b.l;
import com.baidu.mapapi.SDKInitializer;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.BaiduMap.OnMapStatusChangeListener;
import com.baidu.mapapi.map.MapStatus;
import com.baidu.mapapi.map.MapStatusUpdate;
import com.baidu.mapapi.map.MapStatusUpdateFactory;
import com.baidu.mapapi.map.MapView;
import com.baidu.mapapi.map.MyLocationData;
import com.baidu.mapapi.map.Polyline;
import com.baidu.mapapi.map.PolylineOptions;
import com.baidu.mapapi.map.UiSettings;
import com.baidu.mapapi.map.BaiduMap.OnMapTouchListener;
import com.baidu.mapapi.model.LatLng;
import com.example.projectmanage.activity.FunctionActivity;
import com.example.projectmanage.activity.R;
import com.example.projectmanage.common.Parameter;
import com.example.projectmanage.http.AccessNetwork;
import com.google.gson.Gson;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Point;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class CreateProjectActivity extends Activity implements 

OnMapTouchListener,OnMapStatusChangeListener,BDLocationListener {
	
	private MapView mMapView;
    private BaiduMap mBaiduMap;
    private UiSettings mUiSettings;
    
    private LinearLayout buttongroup, choosepoint;
    
    private ImageView pointView;
    private FrameLayout mapparentFrameLayout;
    
    private ImageButton startButton, resetButton, clearButton, saveImageButton, backImageButton;
    private Button saveButton;
    
    private EditText proEditText;
    
    public LocationClient mLocClient;
    private int isFirstLoc = 0;
    
    public ArrayList<Polyline> polylines;
    public ArrayList<PolylineOptions> polyoptions;
    public Polyline dottedPolyLine;
    private Point point1, point2, point3;
    boolean drawFlag = false;
    
    private Map<String, Object> proDataMap;
    private String proname;
    private String url =Parameter.url+ "project.do?method=save";
    private String prokey = "project";
    private String mapkey = "map";
    private String pointkey = "center";
    private List<NameValuePair> nameValuePairs;
	private Gson gson;
    
	Intent intent ;
	
    @Override
    protected void onCreate(Bundle savedInstanceState){
    	super.onCreate(savedInstanceState);

    	intent = getIntent();
    	
    	requestWindowFeature(Window.FEATURE_NO_TITLE);

    	SDKInitializer.initialize(getApplicationContext());
    	setContentView(R.layout.activity_create_project);
    	mapparentFrameLayout = (FrameLayout) findViewById(R.id.mapparent);//
    	backImageButton = (ImageButton) findViewById(R.id.back);
    	saveButton = (Button) findViewById(R.id.save);
    	proEditText = (EditText) findViewById(R.id.proname);
    	initMapView();
    	initLocation();
    	initEvents();
    	mBaiduMap.setOnMapTouchListener(this);
    	polylines = new ArrayList<Polyline>();//save lines
    	polyoptions = new ArrayList<PolylineOptions>();
    	
    	proDataMap = new HashMap<String, Object>();//save info:point,lines
    	nameValuePairs = new ArrayList<NameValuePair>();
		gson = new Gson();
    }
    
    public MapView initMapView(){
    	//remove widget
    	mMapView = (MapView) findViewById(R.id.bmapView);
    	mMapView.removeViewAt(1);//logo
    	mMapView.showZoomControls(false);//zoom
    	//init map
    	mBaiduMap = mMapView.getMap();
    	mUiSettings = mBaiduMap.getUiSettings();
    	mUiSettings.setCompassEnabled(false);//compass
    	mUiSettings.setOverlookingGesturesEnabled(false);
    	//init point
    	choosepoint = (LinearLayout) findViewById(R.id.choosepoint);
    	pointView = (ImageView) findViewById(R.id.locpoint);
    	saveImageButton = (ImageButton) findViewById(R.id.savepoint);
    	//init draw
    	buttongroup = (LinearLayout) findViewById(R.id.buttongroup);
    	buttongroup.setVisibility(View.GONE);
    	startButton = (ImageButton) findViewById(R.id.draw);
    	resetButton = (ImageButton) findViewById(R.id.reset);
    	clearButton = (ImageButton) findViewById(R.id.clear);
    	//定义地图状态
    	LatLng ll = new LatLng(36.072982329734174, 120.38889101891933);
        MapStatusUpdate msu = MapStatusUpdateFactory.newLatLngZoom(ll, 13);
        mBaiduMap.setMapStatus(msu);
        
    	return mMapView;
    }
    
    private void initLocation(){
    	// 开启定位图层
        mBaiduMap.setMyLocationEnabled(true);
        mLocClient = new LocationClient(this);
        mLocClient.registerLocationListener(this);
        mBaiduMap.setOnMapStatusChangeListener(this);
        LocationClientOption option = new LocationClientOption();
        option.setLocationMode(LocationMode.Hight_Accuracy);//可选，默认高精度，设置定位模式，高精度，低功耗，仅设备
        option.setCoorType("bd09ll");//可选，默认gcj02，设置返回的定位结果坐标系
        int span=1000;
        option.setScanSpan(span);//可选，默认0，即仅定位一次，设置发起定位请求的间隔需要大于等于1000ms才是有效的
        option.setIsNeedAddress(true);//可选，设置是否需要地址信息，默认不需要
        option.setOpenGps(true);//可选，默认false,设置是否使用gps
        option.setIsNeedLocationDescribe(true);//可选，默认false，设置是否需要位置语义化结果，可以在BDLocation.getLocationDescribe里得到，结果类似于“在北京天安门附近”
        option.setIsNeedLocationPoiList(true);//可选，默认false，设置是否需要POI结果，可以在BDLocation.getPoiList里得到
        mLocClient.setLocOption(option);
        mLocClient.start();
    }
    
    private void initEvents(){
    	saveImageButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				choosepoint.setVisibility(View.GONE);
				pointView.setVisibility(View.GONE);
				buttongroup.setVisibility(View.VISIBLE);
				mLocClient.unRegisterLocationListener(CreateProjectActivity.this);
		        mLocClient.stop();
		        mBaiduMap.setMyLocationEnabled(false);
		        nameValuePairs.add(new BasicNameValuePair(pointkey, gson.toJson(putPoint())));
		        mUiSettings.setOverlookingGesturesEnabled(true);
		        mUiSettings.setCompassEnabled(true);
			}
		});
    	startButton.setOnClickListener(new OnClickListener() {
    		public void onClick(View v) {
    			if(drawFlag){
    				startButton.setImageDrawable(getResources().getDrawable(R.drawable.paintbrush72));
    				mUiSettings.setAllGesturesEnabled(true);
        			drawFlag = false;
    			}else{
    				startButton.setImageDrawable(getResources().getDrawable(R.drawable.check72));
    				mUiSettings.setAllGesturesEnabled(false);
        			drawFlag = true;
    			}
    		}
    	});
    	resetButton.setOnClickListener(new OnClickListener() {
    		public void onClick(View v) {
    			if(!polylines.isEmpty() && !polyoptions.isEmpty()){
    				polylines.get(polylines.size()-1).remove();
    				polylines.remove(polylines.get(polylines.size()-1));
    				
    				polyoptions.remove(polyoptions.get(polyoptions.size()-1));
    			}
    		}
    	});
    	clearButton.setOnClickListener(new OnClickListener() {
    		public void onClick(View v) {
    			mBaiduMap.clear();
    			polylines.clear();
    			polyoptions.clear();
    		}
    	});
    	backImageButton.setOnClickListener(new OnClickListener() {
			public void onClick(View arg0) {
				finish();	
			}
		});
    	saveButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View view) {
				proname = proEditText.getText().toString().trim();
				proDataMap.put("name",proname);
				proDataMap.put("creator", CreateProjectActivity.this.getSharedPreferences(Parameter.SP_NAME, Context.MODE_PRIVATE).getString("name", ""));
				Handler h = new Handler(){
					@Override
					public void handleMessage(Message msg) {//------------
						
						Map<String , Object> pro = new HashMap<String, Object>();
						pro.put("name", proname);
						pro.put("allcost", "0");
						pro.put("creator", "test1");
						Map<String, Object> utppro = new HashMap<String, Object>();
						utppro.put("project", pro);
						ArrayList<Map<String, Object>> proList = (ArrayList<Map<String, Object>>)intent.getSerializableExtra("utp_pro_list");
						proList.add(utppro);
						
						Map<String, Object> userMap = new HashMap<String , Object>();
						userMap.put("name", "test1");
						userMap.put("truename", "测试帐号");
						userMap.put("pwd", "1234");
						userMap.put("phone", "15820034791");
						
						Map<String , Object> data = new HashMap<String , Object>();
						data.put("list", proList);
						data.put("user", userMap);
						
						Bundle bundle = new Bundle();
						bundle.putString("data", new Gson().toJson(data));
						
						Intent intent = new Intent();
						intent.putExtras(bundle);
						intent.setClass(CreateProjectActivity.this, FunctionActivity.class);
						CreateProjectActivity.this.startActivity(intent);
						finish();
					}
				};
				nameValuePairs.add(new BasicNameValuePair(prokey, gson.toJson(proDataMap)));
				nameValuePairs.add(new BasicNameValuePair(mapkey, gson.toJson(polyoptions)));
				new Thread(new AccessNetwork(url,nameValuePairs, h)).start();// TODO Auto-generated method stub
				saveButton.setClickable(false);
			}
		});
    }
    
    @Override
    public void onReceiveLocation(BDLocation location) {
        // map view 销毁后不在处理新接收的位置
        if (location == null || mMapView == null) {
            return;
        }
        MyLocationData locData = new MyLocationData.Builder()
                .accuracy(location.getRadius())
                        // 此处设置开发者获取到的方向信息，顺时针0-360
                .direction(100).latitude(location.getLatitude())
                .longitude(location.getLongitude()).build();
        mBaiduMap.setMyLocationData(locData);
        if (isFirstLoc < 3) {
            isFirstLoc++;
            LatLng ll = new LatLng(location.getLatitude(), location.getLongitude());
            MapStatusUpdate msu = MapStatusUpdateFactory.newLatLngZoom(ll, 13);
            mBaiduMap.animateMapStatus(msu);
        }
    }
    
    //save point
    public LatLng putPoint(){
    	int position[] = new int[2];
    	//pointView.getLocationInWindow(position);
    	mapparentFrameLayout.getLocationOnScreen(position);
    	Point proPoint = new Point(position[0], position[1]);
    	LatLng proLatLng = coorConvert(proPoint);
    	return proLatLng;
    }
    
    //draw
  	@Override
  	public void onTouch(MotionEvent event) {
  		
  		if(event.getAction() == MotionEvent.ACTION_DOWN){
  			point1 = getPointXY(event);
  			if (getCurrentFocus() != null && getCurrentFocus().getWindowToken() != null) {
            	hideSoftWin();
            }
  		}else if(event.getAction() == MotionEvent.ACTION_MOVE){
  			point3 = getPointXY(event);
  			if(drawFlag){
  				drawDottedLine(point1, point3);
  			}
  		}else if(event.getAction() == MotionEvent.ACTION_UP){
  			point2 = getPointXY(event);
  			if(drawFlag){
  				drawLine(point1, point2);
  				if(dottedPolyLine != null)
  					dottedPolyLine.remove();
  			}
  		}
  	}
  	
  	public LatLng coorConvert(Point point){
  		return mBaiduMap.getProjection().fromScreenLocation(point);
  	}
  	
  	public Point getPointXY(MotionEvent event){
  		Point point = new Point();
  		point.x = (int) event.getX();
  		point.y = (int) event.getY();
  		return point;
  	}
  	
  	public void drawLine(Point point1, Point point2){
  		List<LatLng> points = new ArrayList<LatLng>();
          points.add(coorConvert(point1));
          points.add(coorConvert(point2));
          PolylineOptions PolylineOptions = new PolylineOptions().width(10)
                  .color(0xAAFF0000).points(points);
          Polyline mPolyline = (Polyline) mBaiduMap.addOverlay(PolylineOptions);
          polylines.add(mPolyline);
          polyoptions.add(PolylineOptions);
  	}
  	
  	public void drawDottedLine(Point point1, Point point3){
  		if(dottedPolyLine != null){
  			dottedPolyLine.remove();
  		}
  		List<LatLng> points = new ArrayList<LatLng>();
          points.add(coorConvert(point1));
          points.add(coorConvert(point3));
          PolylineOptions PolylineOptions = new PolylineOptions().width(10)
                  .color(0xAAFF0000).points(points);
          dottedPolyLine = (Polyline) mBaiduMap.addOverlay(PolylineOptions);
          dottedPolyLine.setDottedLine(true);
  	}
  	
  	//map status
  	@Override
  	public void onMapStatusChange(MapStatus arg0) {
  		// TODO Auto-generated method stub
  		
  	}

  	@Override
  	public void onMapStatusChangeFinish(MapStatus arg0) {
  		// TODO Auto-generated method stub
  		
  	}

  	@Override
  	public void onMapStatusChangeStart(MapStatus arg0) {
  		// TODO Auto-generated method stub
  	}
    
    @Override
    protected void onPause() {
        super.onPause();
        mMapView.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mMapView.onResume();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mMapView.onDestroy();
    }
    
	@Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            if (getCurrentFocus() != null && getCurrentFocus().getWindowToken() != null) {
            	hideSoftWin();
            }
        }
        return super.onTouchEvent(event);
    }
	
	public void hideSoftWin(){
		InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);  
        imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
	}
}
