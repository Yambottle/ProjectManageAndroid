package com.example.projectmanage.map;

import com.baidu.mapapi.SDKInitializer;

import android.app.Application;

public class MapInitialization extends Application {
	@Override	public void onCreate() {
		super.onCreate();
		SDKInitializer.initialize(this);
	}
}
