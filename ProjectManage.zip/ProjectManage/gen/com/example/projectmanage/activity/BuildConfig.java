/** Automatically generated file. DO NOT MODIFY */
package com.example.projectmanage.activity;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}